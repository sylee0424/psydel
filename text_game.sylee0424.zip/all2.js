﻿var actz = {

    nxt: {
        f: function() {
            var app = document.getElementsByClassName("pages" + pages);
            pages = pages + 1;
            if (parseInt((Object.keys(fncs).length - 1) / 3) < pages) {
                pages = 0;
            }
            var app2 = document.getElementsByClassName("pages" + pages);
            for (var i = 0; i < app.length; i++) {
                app[i].style.visibility = "hidden";
            }
            for (var i = 0; i < app2.length; i++) {
                app2[i].style.visibility = "visible";
            }
        },
        name: "Next_Page",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAGGSURBVGhD7ZrBDsMgDEPH/v+ft7USUrsVsBOHAhrXUYj9cOCw9PqMxwIjZSEppSnlZA7PrfpZRRxr34WsMNYSMnPec+3NsI8ispTjU9i3jIxSMJPXY83NjIzQ0ZAaTkJmovJda5PI3fcMQmOr8UfIDFSuaoSI3EUFpXFJZPQOVjoxMJHeVBgaRSKjUqnllyLSiwpLo0pkNCqtbkoTiaZiodEkMgqVFg1ISOkRZ3Wu9ij0rAkdLcQR5tXKzEX3hoT0oOKhQR0t1BnG7dZcZk8XEVUH89KgiPTuYAwNWkhEVhQ0TEJYp1o5uPrdsoc7I7kQi7OWb0rGmIRYHEPJWNc2CVFkRUnDlJEswupcjYxnTSkR9F5R03ARUd8rHhpuIZasRNCQCPE6qSIrz0jtXomiISHidVRBVCYEyUokDakQi7OWb6RPFPS5ke+VaBpSImxWlDTkQhhS6rny9os4jcxhhcqFsAWo5ocIqTkeQeOfEeQ4XDkfRSOcyLHwSBH7ffXZYIk/nr0Bj86jMw2qxo0AAAAASUVORK5CYII="
    },

    prv: {
        f: function() {
            var app = document.getElementsByClassName("pages" + pages);
            pages = pages - 1;
            if (0 > pages) {
                pages = parseInt((Object.keys(fncs).length - 1) / 3);
            }
            var app2 = document.getElementsByClassName("pages" + pages);
            for (var i = 0; i < app.length; i++) {
                app[i].style.visibility = "hidden";
            }
            for (var i = 0; i < app2.length; i++) {
                app2[i].style.visibility = "visible";
            }
        },
        name: "Previous_Page",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAIAAACRXR/mAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAFTSURBVFhH7dfbDoMgEIRh3/+l21pJPAC7s7MDIU29NB5+PhXa7bXktqmqtu8mu5rkQkeTsEwwvmuTquxHs2oqCVhWa8WsXlMeLKW1YpbdlATjtR5Zx/zX3ElMjWRWb65SzWGarKuHBIzJskkkYIKs+tXJg4WzEAzkGPs7yGb1rp4Ei2XhDPiRzYGlspwHcU8LzV6BrChA9PjbLIMPgnhdiFPKagFmcUPnztoXMS4LPIteJaEsetB11udSyJCwgxLfFAfmZ2Womr92ELBwFvII8qukk5Wn4sBiWRwV8cPVylJREWCBrAxVFKybpaWKgqFZeaoQWDtrBFUIDMpSUeFgjaxxVDiYn6WlAsGeWaOpQDAnawQVAnbLmkOFgFlZ46hcsDNrJpUL1s0aTWWDlaz5VDZYN6sOnbOn5Db/nMwp6N1lT/pnoc+gaC0Fdr5bc+aC0F3eG3dL3MAvkngAAAAASUVORK5CYII="
    },

    cls: {
        f: function() {
            document.getElementsByClassName("obtn")[0].style.visibility = "visible";
            for (var i = 0; i < document.getElementsByClassName("btnz").length; i++) {
                document.getElementsByClassName("btnz")[i].style.visibility = "hidden";
            }
        },
        name: "Close_Button_Tab",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAABBdEVYdENvbW1lbnQAQ1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJSkcgSlBFRyB2ODApLCBxdWFsaXR5ID0gOTAKfVTa3QAABLlJREFUaEOtWolO60AQS6GI///aQgv0yRHe5zWzmdkklVBz7DGee12Wp3wej0e7u9/v+urP9ff3d3v28/Pz/Pr66u5xg+fVj47Fta6Pa3/v6y4cEG1KYMuyPC+Xy5P3OkcBYEO93wNCAWBf/PHjytP1F77kN4RUUFjoer2uC+qiDkA3+fj4WPeoWoR7UvO4p/KgQFxHYzogupm6Fp6/vr42ABGYz8/PdS2Coju6MrYsE4ElCCqPYHydTuEuPF9y8svLSwPDZ5G53bIzFsFcznfhHRTW1fEEtzoghFdAXExB6DXfe1DSEvqdxcnIjdUDeM1vrtnNVd/GgMgSkVX4jBriolBINTZUINc8leXfGjNdjFAQfPtiEJYT1a0wTsFFGqpmLwa2W3zLG/iuswhvIByDmwNd+C0t0UVHgR4BgzeM1hw9d+9oMUKNcCLBaMaqbIYNtHBpzKkLqCtXFIUxKnwk16oQT7OYuAeEpkgFQXAKAO9n91Blvr29rZbUOF2zFgoYBKloKLKOzoOAUQeg6VgzUmZtdfNoHtdd1Hc1h1c3U7NzDoDph3GIvajJGYt4IqBF/mQtz+WZlvw9hIoE04wIK72/v3dWnwHDWOEczZRrnEc5f2YDT5Owis6n6UdanVUauwq2R11l95aZNaW6SeSGUbx5RpyJSSYhTyQtRnARnSUUzJZQVbDVcaPeDvO1n3NPas2+9ltREwdtQvNZ/1UVWBNLVifw3lshb63WGPE/+p13pFo0Z+JoFlxUJxATXpO6Q5iayFvxqAprPEQd8azQlTqhaXbUw7U2noB4OOIE7WrVCjOBmoHL6gQ95na7dfWpqyMUlMdT+qL7oJ/fz7CGAhzVCe0IcK1dQ1fM3WwKgAN1MoCfDcItBplYJyhP1L+FFtFYAQBPb37qO9Kbjfo17dO0K9Br95SuIA4db/BilM2yWNg6z7BiK5ujbUjGm/0njRKho9jZK7jPc5aEdQxeUOXNUiDEpwvCX5nrj4LR8w+uRyfJjDcrAWG8ME7ODPaI7PAAr/BmJSBddvilT8+s7F6fUHS9u8h4sxQI0x60ogenoy4VcQRuaSfittqpFAg145X8rBghIKWecK0HKCc1ojNUCkRZFt0MApzRpmzxWZ7NvNZ1Lq+5Wq/31ootVpJani2m5AC8KKu8rWn04MJ9JQ4y3gnA+EfiQd2psgfnRbwZM1rX/XIg3Wmv6/h5gsJqXM2kcHVpbRxV+SH5MOP/1fPEEfIh481WmslbDz2CzphdxyrvpH7trlXhzjLerMWyc1r+W0QVzNZ5ogvK35/yZty2wpu1GJlxpwycnicYjFqZZ6xe4c0aie0mj+4z4bd4J/95jxmxapWMN1vXGy062mQP73SUN4v6OpWvAVEwOoCF6wzeaS9vVnatjhuS3xy28vwM73QGbzYV7O3s+9tDsQhV60R0AMOzo7xZOf1qq8xNPbCP8k60CoDt4c3KBTFqHD1z7eWdzuDNyi2KMhceM1Ha1TpR5Z0wB9lrL28GMGpZPfB1WUt7e52gxWsP76TnfY2jKm/GzMl4U9n+tPEKIromGOecopNatlb0Pqszkes725KeED3zuOX2CB7NGdUZjNWENPoXkX+e13+IueJjyAAAAABJRU5ErkJggg=="
    },

    opn: {
        f: function() {
            document.getElementsByClassName("obtn")[0].style.visibility = "hidden";
            for (var i = 0; i < document.getElementsByClassName("pages" + pages).length; i++) {
                document.getElementsByClassName("pages"+pages)[i].style.visibility = "visible";
            }
            for (i = 0; i < document.getElementsByClassName("acts").length; i++) {
                document.getElementsByClassName("acts")[i].style.visibility = "visible";
            }
        },
        name: "Open_Button_Tab",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAIAAACRXR/mAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAACiSURBVFhH7ZjtCoAgEAR9/5fuA6KIoHbOiKLx9+ot456WbXjlaGVXLRj1xesztQXYBbA6EgKM7KXaIuikJa1zAh09HISL0N9ptUXQSUtaF91IAH2lE4MD6FHJxG3uxEdrBsW0FUBaJdKSFiFAtGZLWoQA0S7Zqt3zSaHaytqC3PyWJ8CkJa0f/vmQTd+0nvKEm7Sk5dvpoQtIKG56SCqXTCaO2xprhNlIdLEAAAAASUVORK5CYII="
    }

};

var fncs = {
    cnt: {
        f: function(e) {
            if (!e) {
                e = document.body;
            }
            if (e.tagName && e.tagName != "#text") {
                for (var i = 0; i < e.childNodes.length; i++) {
                    fncs.cnt(e.childNodes[i]);
                }
            }
            c++;
        },
        name: "Count_Nodes",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAIAAACRXR/mAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAEOSURBVFhH7ZdZEoQwCERz/0s7blkqMdggpKKDX1M1iJ0HtBiWKa8wpapFQVZQvQ5MOrK0kK8HdFkwTKcFo9o6/bO9pWoLcQCf00rAOVW6js21c1n3NJ3WPaMc8V1aRr6Q0gpf1aa+kOrKXmxclmhqODeh5u5F7FNt7WoWWpUvsGUZ2VUPJWoQY3xBQuv56J0Onpaq+KPN7LQiE2IA31xEi+k7vrp6vgDRspi+8mOQmCGq5V8pqy0xdfrCC5DTymkh2XOvuKy6jFMUsRJB17T8F6m+vLe4shC70vctnBbyypfTEhuErSwk+6VBIDfKaSHZ/0yW4hLBo8uKHhaMLs3DBJ37/uDngY9zWiCoPewHEtjBnuwCL4YAAAAASUVORK5CYII="
    },

    lnk: {
        f: function(element) {
            var i;
            if (!element) {
                element = document.body;
            }
            if (element.nodeName == "#text" && !(element.nodeName == "#comment" || element.tagName)) {
                var nv = element.nodeValue;
                var ids = new Array();
                var at = nv.split(/h{0,1}ttps{0,1}:\/\/[a-zA-Z0-9\/\?\!\@\#\$\%\^\&\*\_\-\+\=\\:\.\,]+/g);
                var ss = nv.match(/h{0,1}ttps{0,1}:\/\/[a-zA-Z0-9\/\?\!\@\#\$\%\^\&\*\_\-\+\=\\:\.\,]+/g);
                var aq = new Array();
                var id = 0;
                ids[0] = at[0].length;
                aq[0] = element;
                if (ss) {
                    for (var i = 0; i < ss.length; i++) {
                        ids[i + 1] = ids[i] + ss[i].length + at[i + 1].length;
                    }
                }
                if (element.parentNode.tagName != "SCRIPT" && ss) {
                    for (i = 0; i < at.length - 1; i++) {
                        if (i == 0) {
                            aq[1] = aq[0].splitText(ids[0]);
                            if (at.length - 1 == 1) {
                                aq[1] = aq[1].splitText(ss[0].length);
                                aq[1].parentNode.removeChild(aq[1].previousSibling);
                            }
                        } else {
                            aq[i + 1] = aq[i].splitText(ids[i] - ids[i - 1]);
                            aq[i] = aq[i].splitText(ss[i - 1].length);
                            aq[i + 1].parentNode.removeChild(aq[i + 1].previousSibling);
                        }
                        var a = document.createElement("a");
                        a.setAttribute("target", "_blank");
                        a.setAttribute("href", ss[i].replace(/(h?)ttp(s?):\/\/([a-zA-Z0-9\/\?\!\@\#\$\%\^\&\*\_\-\+\=\|\\:\.\,]*)/g, "http$2://$3"));
                        a.appendChild(document.createTextNode(ss[i]));
                        aq[i + 1].parentNode.insertBefore(a, aq[i + 1]);
                    }
                }
            } else {
                for (i = 0; i < element.childNodes.length; i++) {
                    i = fncs.lnk.f(element.childNodes[i]);
                }
            }
            if (aq) {
                return tls.gcn.f(aq[aq.length - 1]);
            } else {
                return tls.gcn.f(element);
            }
        },
        name: "ttp://_Make_Link",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAGaSURBVGhD7VeBqsMwCHx5///P2zIQrDVGrcoIFgbbUo3encaM1+f5O+D5PyCHbwqdyK8x2Yw0I0kItLSSgHW7PZ+RMcYSHWlNCyn18dRnCSNPg9SAM+isxW0K45hlTRrhph+8Tn9rAqfv3BiZG8Am+Ps0lNbw+nyvggWcTIm0PAhbbUITmSzAh0oHAsuQlTj9gjxWdQEBY+RAerQ+Kq48t2K3UrpC2uvHaxcqLW8QEXZhiVTIR0r4Iq3qlikFZgUmrEYi5PHEBystCzPcu/g/3JJpp9vNW5Y4LonsHK8Q222I27JVMlqWLong0cIy/+xGEsoKBMftB6BY9hcPRC0SXFDUtpwRjMIOZS7RJzZ4ULWycWMkYrTgamAlLSvr6nNEKuasIo1KJuxkxwHtulhU8Or7CO773LSLJZMRnMWn6mTnik+6V1BGKmSZIq2JJG65FVJLS8Qii4h3VdKaGwGqqyssnCHcWVIhLXUiEahl+jhGWp1Ipkw8vpsRD2qZNs1IJroe382IB7VMm2YkE12P72bEg1qmzTGMvAEtK+dZydFd9QAAAABJRU5ErkJggg=="
    },

    alts: {
        f: function() {
            document.location.href = "https://hitomi.la/index-korean-1.html";
        },
        name: "Move_To_hitomi",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAPuSURBVHhe7ZrfTuJAGMV5Lh9lbyU8g97sbnbRFdja4U/1GUzWRJMN94aEGy8k3voG3om4eOeeMrQM9A89SETlTCaknZ7O9Pv1fNNpaOlFpTCBUmGlhC+CRZhAsASLIEBI5SwGVrXerNbC+nO+VuutA9RG+5fXqflB3Zw0mqeNJn7Dit26CdB+dIxqBYE99LsVVq99etw+8TuBCYJm0GmFtd0OWqitTtO0mp4xDd/UPHPY8Ks1/8eR//3Q/zapXw9Qj3PrUkH+6ThqR+FqaahSmIBgFUY1HAqWYBEECGmes25ubi4uLs5UIgKZsG5vb3u93sPDA/Fo/ezSTFiXl5fPz8+fPXwuvkxYsB7X0xaoBYu4yYIlWAQBQrqis0aj0fn5+f7+/pdJwQZ20UiM/AGlq8C6uroql8tg5Hnen0nBBnbRiEMfEELRS6ZhAQe47O3t3d/fu4NgF404dH19nTF4t1KqdIte2Fp0ax6Rg4VEg30AJQ7FpmG8i0MQZORj2qXfmZ3SjrlDB9iyG0vK09O/x8e0fJ91FfewUVjIOKBxPbUAC4fQAllaxPmXXhRWOql0whuFBeNgesq/9RBgvs+CZeCkSYkS0sYTumJaYp9FDa7SPT0+Z74rd2QHFjYnpZB7MyLk0jDpmgVnYRTrvgxY0bWGgdoY43hcZ6ExCmqWXGG401Ybue1gdl7SR07nxs6WTs/L8j15/I1hxRN8HGIarPmoIZ2c5ra6McftObBmgXcrq3uLg5VMw6SzkIbuE8C5P24wS2C5AUXSBVgu9wWTpk3wURq+JhE5WOub4F/vLAbW3Nz1Vs7CmmB3d9edv5NLBwgKLB2SsNw0W5izksZZMOkSZ82mtZTlBTF1cc5Cx3ZRCl7JRal9+ym2KE2BFdKKH1ezx2NshMJpOPdMiDlOn4XmzeYsexfAC/axrzt4JUSxrztozCZF3MB3K6WdZSNBomH+su839u0Hu3qRfre3eQMXtqKzNnCl72BIwSJugmCtAxb+Xh2Px0RPWyDNdBYWAf1+fwsIECHm/X0/GAz097378YK+olnThyFEN9shlbOI+yxYDKzu365qQQL6tJtZOhDarZfKWYQFBEuwCAKEVM4SLIIAIZWzBIsgQEjlLMEiCBBSOUuwCAKEVM4SLIIAIZWzBIsgQEjlLMEiCBBSOUuwCAKEVM4SLIIAIZWzBIsgQEjlLMEiCBBSOUuwCAKEVM4SLIIAIZWzBIsgQEjlLMEiCBBSOUuwCAKEVM4SLIIAIZWzBIsgQEjlLMEiCBBSOUuwCAKEVM4SLIIAIZWzBIsgQEjlLMEiCBBSOUuwCAKEVM4SLIIAIZWzCFj/AaFsmgx6uLduAAAAAElFTkSuQmCC"
    },

    led: {
        f: function() {
            var br = document.getElementById("view_content").getElementsByTagName("div");
            for (var i = 0; i < br.length; i++) {
                br[i].style.display = "inline"
            }
        },
        name: "Blink_Line_Fix",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAJ3SURBVHhe7ZZhcoMgFAY9Vw7keTyNl8lhUlBBjMSwKZnpdNYfHWM/n49lQYeHRzOBoTlp8CEsIIGwhAUIgKhmCQsQAFHNEhYgAKKaJSxAAEQ1S1iAAIhqlrAAARDVLGEBAiCqWcICBEBUs4QFCICoZgkLEABRzRIWIACimiUsQABENUtYgACIapawAAEQ1SxhAQIgqlnCAgRAVLOEBQiAqGYJCxAAUc0SFiAAopr1RVj36TbOoP7b6DzepvvbVIdAh86pWfmR8zh0GWUjrMbYBdQOnX8Mq8NcLyXaKLSlLnv6plnBnH29hQcNy3Ebx20Zrs8Of5Nf+fRwZ73/IhIxzLn8tiLjxWkMjyt+r2uVFX/EBvt1XjEr9BOOYmc6DC39Z5uonVY5+acSmVmteGZS8j42UK54VjyNI961nn/YebjzAGudhucN/LAEsszpJA2wslCWUeVh1osfl2G1WH39tBTv1Hme6bNZy6COM1n8OsHaVuITq1OR7YHn69UBlRfPrJqLX8NinccBvNjgl342xeL5S5lXrcOx+xjn/PJFWRaPm1BZfb2xGOUTK1S8d+dNb8O8Sw7jlL6zikGUPeGXZNrLl214n5PitfGb77q+nTfBwgS63dDhk6FbLy+XYccn/KNSf9ysv0VaWGA+hCUsQABENUtYgACIapawAAEQ1SxhAQIgqlnCAgRAVLOEBQiAqGYJCxAAUc0SFiAAopolLEAARDVLWIAAiGqWsAABENUsYQECIKpZwgIEQFSzhAUIgKhmCQsQAFHNEhYgAKKaJSxAAEQ1S1iAAIhqlrAAARDVLGEBAiCqWcICBEBUs4QFCICoZgFYP1gVHwXKh5cqAAAAAElFTkSuQmCC"
    },

    rtl: {
        f: function() {
            var br = document.getElementById("view_content").getElementsByTagName("div");
            for (var i = 0; i < br.length; i++) {
                br[i].style.display = "block"
            }
        },
        name: "Return_Blink_Line",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAMjSURBVHhe7ZoxcvIwEIXlnAX+gskJ4ARMGqq0dFAmDR0lHY0p83dpU9EEnyA5QYYi5i7OSrKN7WQGv5BZi+SpYDSeZ1v6/Fa2lo2yLDNs7QhctZNRZQkQFuADwiIsgAAgpbMICyAASOkswgIIAFI6i7AAAoCUziIsgAAgpbMICyAASOkswgIIAFI6i7AAAoCUziIsgAAgpbMICyAASOkswgIIAFI6i7AAAoA0KGcdNqN5AgxeWxoUrHLyyTwabQ7aLE7eL0xY44fs5a53cvDagm5giXOO8SbBF7k2Wu/z6ft4lN/CX2W3duZvhyWTlbadZA9jP9Vk3t8vpe5J2tL8f63Ov3dza56eXTSme3N7Y60mnpts7SW6WNz0nOUNJJikFaSE1fYtXuTcxot4WDNLSUtUnpVtwkuaQ6a8sOnB6t29ZFk6WCFTzGnVWBkbnlG0GqSZ9sKmB8u5whF7NNMyjPoDc7/OPxeS9X0tDK3eRuJ0ZZbFcm/DeGoe1Tl5U/vlosOWlrE3i+PhbGeHIsd8x3VN0e9wlO7WEWtK279TlcOw/cBCVBIW8FQIi7AAAoCUziIsgAAgpbMuCVYyV97gAXCa0ktxVhBMLwRWYyt9hjvOObUbWI0UXlqm//JcsvXRRrbMRYQeWXWa/NPeSO9m9tFWdsb2wDCWdIvfNPuuPVjTFAqr+nQJtf21HiyfXfiUQNjNKiAKWs2DX6QdHLIqQwVkemHYMvl3/a/xR8Xh+el6kudS/YLzZ5N/MvfXavbPDPr1JbjB6m8n/2zExW4hqwTpMQwraUCFODtxi8CTf/JafF8E8xdi4LDO+Sr6+XP1FvifH7v6FQkLQE5YhAUQAKR0FmEBBABpUM5i5R/w5EopK/8Aaqz8q8Bi5V8r57DyrxUmVv61wuRFLZN/tSuy8o+Vf9/PzLHyDwjPC5IG9QUfOjfCAp4QYREWQACQ0lmEBRAApHQWYQEEACmdRVgAAUBKZxEWQACQ0lmEBRAApHQWYQEEACmdRVgAAUBKZxEWQACQ0lmEBRAApHQWYQEEACmdRVgAAUBKZxEWQACQ0lkArA9MJatAph9IyQAAAABJRU5ErkJggg=="
    },

    hab: {
        f: function() {
            var i = 0;
            var b;
            var galleryId = location.href.split("/")[location.href.split("/").length - 1].split(".")[0];
            var scripts = document.getElementsByTagName('script');
            i = scripts.length;
            while (i--) {
                scripts[i].parentNode.removeChild(scripts[i]);
            }
            scripts = document.getElementsByTagName('noscript');
            i = scripts.length;
            while (i--) {
                scripts[i].parentNode.removeChild(scripts[i]);
            }
            scripts = document.getElementsByTagName('iframe');
            i = scripts.length;
            while (i--) {
                scripts[i].parentNode.removeChild(scripts[i]);
            }
            var scr = document.createElement('script');
            scr.src = 'https://hitomi.la/galleries/' + galleryId + '.js';
            document.body.appendChild(scr);
            divs = document.getElementsByTagName('style');
            i = divs.length;
            while (i--) {
                divs[i].parentNode.removeChild(divs[i]);
            }
            /*document.setAttribute("ontouchstart" , "event.stopImmediatePropagation();");
            document.setAttribute("onmousedown" , "event.stopImmediatePropagation();");
            document.setAttribute("onclick" , "event.stopImmediatePropagation();");*/
            document.body.setAttribute("ontouchstart" , "event.stopImmediatePropagation();");
            document.body.setAttribute("onmousedown" , "event.stopImmediatePropagation();");
            document.body.setAttribute("onclink" , "event.stopImmediatePropagation();");
            if (document.getElementsByClassName("page-container").length != 0&&document.getElementsByClassName("page-container")[0].getElementsByTagName) {
                divs = document.getElementsByClassName("page-container")[0].getElementsByTagName("li");
                i = divs.length;
                while (i--) {
                    if (divs[i].innerHTML == location.href.split("-")[location.href.split("-").length - 1].split(".")[0]) {
                        divs[i].setAttribute("style", "color:#ff00ff");
                    }
                }
            }
        },
        name: "hitomi_Ad_Block",
        image: "data:image/png;base64,aaa"
    },

    hid: {
        f: function() {
            var num1 = Number(prompt("max", "-1"));
            var num2 = Number(prompt("min", "0"));
            var a = prompt("a or b", "b"); // a or b
            var galleryId = location.href.split("/")[location.href.split("/").length - 1].split(".")[0];
            if (location.href.indexOf("/reader/") != -1 || location.href.indexOf("/galleries/") != -1) {
                var i = galleryinfo.length;
                if (i > num1 && num1 != -1) {
                    i = num1;
                }
                var k = 0;
                if (a == "a") {
                    document.getElementsByTagName("head")[0].innerHTML = "";
                    document.getElementsByTagName("body")[0].innerHTML = "";
                    while ((i--) - num2) {
                        var img = document.createElement("img");
                        img.src = "https://hitomi.la/galleries/" + galleryId + "/" + galleryinfo[i - num2].name;
                        document.body.insertBefore(img, document.body.firstChild);
                    }
                } else {
                    while ((i--) - num2) {
                        var m = "";
                        if ((i + 1) / 10 < 1) {
                            m = m + "0";
                        }
                        if ((i + 1) / 100 < 1) {
                            m = m + "0";
                        }
                        var hrf = document.createElement("a");
                        hrf.name = "hrf";
                        document.body.appendChild(hrf);
                        hrf = document.getElementsByName("hrf")[0];
                        hrf.href = "https://" + document.getElementsByTagName("img")[0].src.split(".hitomi.la/")[0].split("//")[1] + ".hitomi.la/galleries/" + galleryId + "/" + galleryinfo[i].name;
                        hrf.download = "hitomi_" + galleryId + "_" + m + (i + 1) + ".jpg";
                        hrf.name = "href";
                        if (hrf.click) {
                            hrf.click();
                        } else if (document.createEvent) {
                            var eventObj = document.createEvent('MouseEvents');
                            eventObj.initEvent('click', true, true);
                            hrf.dispatchEvent(eventObj);
                        }
                    }
                }
            } else {
                alert("갤러리/리더 화면이 아닙니다.");
            }
        },
        name: "hitomi_Image_Download",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAWJLR0QecgogKwAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxNC0xMC0xOVQyMTozMDozNyswMjowMF1ZuNsAAAAldEVYdGRhdGU6bW9kaWZ5ADIwMTQtMTAtMTlUMjE6MzA6MzcrMDI6MDAsBABnAAADX0lEQVRoQ+2YP0wTURzHv/enNoW2VG1LAEshUQJEB1mcUBcHB00kDsawuOjsREyIiTEYMcRBBgcd1MRJIzFao4MmriYiYSCKgRjRQBRBoBRo766+d6XlrELL3e8lhNxbmt67e+/3+X1/v9/73UlZNrANhkQB0tp2pOAK3TAA5htJkiDLcuG6YWRhGLr5X5JkKMra3MjgW8euJAXxeDyIx+qgst90Oo2vE9+haRrjyqK2tgYtzfvANsTk1A+MfBwtGE8BsuYWhz4xmBLRSBg3e6/gwd1buNHTjZ2hKhOCz7UfaEbvxQvo77uKzrOnwXQDZUyTgXA/yLKEQMAPf2UFAn4/JPbfYCBNu4JoT8/i2/07mB8axO6shoPhIHwsvKhgSEFyov5r2qHqEOp8O6Alk5h8lUBk+B262vbiWCxCJosAkFUcpoSu6SxHdEwll7DCcoVlObT5OejJBfhUBQ3BCjDRSIYwEL+/EqdOHkfnmQ7EDx+FFms0K1legrkVDUPT89CJqj9Z1eIJHa/fYyZ6dZSFTNHIzP3GxMN7YBJhXJdxO/EGo7NJE2RLVa1S8eGpCqHmRAcazp1Hqmk/RmYWyNQwC00pA+zOz8zM4npfPy5dvoau7h48efoCvlg95ECQpwrLDaLkWDVQGEhyMYXEy9d4PPAcjwae4f2HYbs+Kes5YSA8sRVWmVRVhaqof7UrZVm2yZsEgNCGTLk8pCC8HeE9Fu+vlpdXzObRHIyNVzU+p+u5s4V6kJVfbpjX60VrSxM8LJxSqSV8+jyGTCZj9lvV0TAaG+LmWfJz+hfGxr8UWCjKLykI97/BPM6F4EVJUZSCsRxG13mrmOvJrC3+lgGhDhM765EoUrxxrhVZf4h4KRUGsp6xHFIECGnVshMSVM8IU8QNLZsSuaG1kePcqmUzrMwuiOIDnXuOOFCg+NFtk+wuCGFUkCzlKkLiRsJFXEUInUmylHsgkriRcJFtkyOOQ6tUp1uu052+/pKAODaC4D2eNLS4OhspZJ2jUjKvOBlI/usIVydvJLWxG4UpGYh1k3yoWUPO+hlIxCchISDlJjjlfUJAikNLtBrcIWQg+dywGu20mm1GMTIQvik3/H/GW6+JgiM5RzbjufXudQroGIQCgmIN0tCiMMjuGn8A/O2d15PLg+EAAAAASUVORK5CYII="
    },

    fde: {
        f: function(element) {
            if (!element) {
                element = document.documentElement;
            }
            if (element.attributes) {
                if (element.id != "img") {
                    element.removeAttribute("ondragstart");
                }
                element.removeAttribute("onselectstart");
                element.removeAttribute("oncontextmenu");
            }
            for (i = 0; i < element.childNodes.length; i++) {
                i = fncs.fde.f(element.childNodes[i]);
            }
            return tls.gcn.f(element);
        },
        name: "Force_Drag_Enable"
    },

    hlb: {
        f: function() {
            var d = 0;
            var divs = document.getElementsByTagName('a');
            var i = divs.length;
            while (i--) {
                var k = divs[i].getAttribute("href");
                if (k && divs[i].id != "dl-button" && divs[i].parentNode.parentNode.getAttribute("class") != "simplePagerNav") {
                    divs[i].setAttribute("onclick", "tls.tss.f(" + i + ",0,'" + k + "');");
                    if (divs[i].parentNode.parentNode.parentNode.getAttribute("class") == "page-container") {
                        divs[i].setAttribute("onclick", "location.href = 'https://hitomi.la" + k + "';");
                    }
                    if (divs[i].parentNode.parentNode.parentNode.getAttribute("class") != "page-container" && divs[i].parentNode.tagName != "DIV" && divs[i].href != "/") {
                        if (k.indexOf("galleries") != -1) {
                            var b = k.split("galleries");
                            divs[i].insertBefore(document.createElement("span"), divs[i].firstChild);
                            j = divs[i].firstChild;
                            j.innerHTML = "(R) ";
                            j.setAttribute("onclick", "tls.tss.f(" + i + ",2,'" + k + "'); event.stopPropagation();");
                        }
                        if (k.indexOf("-all-") != -1) {
                            b = k.split("-all-");
                            divs[i].insertBefore(document.createElement("span"), divs[i].firstChild);
                            j = divs[i].firstChild;
                            j.innerHTML = "(K) ";
                            j.setAttribute("onclick", "tls.tss.f(" + i + ",1,'" + k + "'); event.stopPropagation();");
                        }
                        d = 0;
                    } else {
                        d = 1;
                        divs[i].outerHTML = "<span" + divs[i].outerHTML.substring(2, divs[i].outerHTML.length - 2) + "span>";
                    }
                    var inp = document.createElement("input");
                    var inq = document.createElement("label");
                    var tx = document.createTextNode("N");
                    inp.type = "checkbox";
                    inq.setAttribute("style", "display:inline");
                    if (d == 1 || divs[i].parentNode.parentNode.parentNode.parentNode.class == "page-content") {
                        inq.setAttribute("style", "display:none");
                    }
                    inp.name = "input-" + i;
                    inp.setAttribute("onclick", "event.stopPropagation();");
                    inp.setAttribute("style", "vertical-align:middle");
                    inq.setAttribute("onclick", "tls.kxx.f(" + i + "); event.stopPropagation();");
                    inq.appendChild(tx);
                    inq.appendChild(inp);
                    divs[i].insertBefore(inq, divs[i].firstChild);
                    divs[i].removeAttribute("href");
                }
            }
            divs = document.getElementsByClassName("page-content")[0].getElementsByTagName("label");
            i = divs.length;
            while (i--) {
                divs[i].setAttribute("style", "display:none");
            }
        },
        name: "hitomi_Link_Change"
    },

    mab: {
        f: function() {
            var i = document.getElementsByTagName("iframe");
            var j = i.length;
            while (j--) {
                i[j].width = "0px";
                i[j].height = "0px";
                i[j].removeAttribute("src");
            }
            i = document.getElementById("responsive-banner");
            i.style.visibility = "hidden";
        },
        name: "mab"
    }

};

var tls = {

    sfg: {
        f: function(flag_) {
            flag = flag_;
            offy = event.y;
            offx = event.x;
        },
        name: "sfg"
    },

    drg: {
        f: function() {
            var img = document.getElementById("img");
            if (!flag) return;
            var top = Number(img.style.top.replace('px', '')) + event.y - offy;
            var left = Number(img.style.left.replace('px', '')) + event.x - offx;
            img.style.top = top + "px";
            img.style.left = left + 'px';
            offy = event.y;
            offx = event.x;
        },
        name: "drg"
    },

    tgl: {
        f: function(element, bool) {
            if (bool) {
                element.style.backgroundColor = "#ffffff"
            } else {
                element.style.backgroundColor = "gold"
            }
        },
        name: "Toggle_Buttons"
    },

    fev: {
        f: function(element, event) {
            if (document.createEventObject) {
                var evt = document.createEventObject();
                return element.tls.fev('on' + event, evt);
            } else {
                var evt = document.createEvent("HTMLEvents");
                evt.initEvent(event, true, true);
                return !(element.dispatchEvent(evt));
            }
        },
        name: "Fire_Event"
    },

    clc: {
        f: function(hrf) {
            if (hrf.click) {
                hrf.click();
            } else if (document.createEvent) {
                var eventObj = document.createEvent('MouseEvents');
                eventObj.initEvent('click', true, true);
                hrf.dispatchEvent(eventObj);
            }
        },
        name: "Emulate_Click_Event"
    },

    gcn: {
        f: function(node) {
            return Array.prototype.indexOf.call(node.parentNode.childNodes, node);
        },
        name: "Get_Child_Number"
    },

    tss: {
        f: function(i, j, k) {
            var url;
            if (j == 0) {
                url = "https://hitomi.la" + k;
            } else if (j == 1) {
                url = "https://hitomi.la" + k.split("-all-")[0] + "-korean-" + k.split("-all-")[1];
            } else {
                url = "https://hitomi.la" + k.split("galleries")[0] + "reader" + k.split("galleries")[1] + "#1";
            }
            if (document.getElementsByName("input-" + i)[0].checked == "1") {
                window.open(url)
            } else {
                location.href = url;
            }
        },
        name: "hitomi_Click_Action"
    },

    kxx: {
        f: function(i) {
            if (document.getElementsByName("input-" + i)[0].getAttribute('checked') == '1') {
                document.getElementsByName("input-" + i)[0].setAttribute('checked', '0');
            } else {
                document.getElementsByName("input-" + i)[0].setAttribute('checked', '1');
            }
        },
        name: "Check_Set"
    },
    gck: {
        f: function (cName) {
            cName = cName + '=';
            var cookieData = document.cookie;
            var start = cookieData.indexOf(cName);
            var cValue = '';
            if(start != -1){
                start += cName.length;
                var end = cookieData.indexOf(';', start);
                if(end == -1)end = cookieData.length;
                cValue = cookieData.substring(start, end);
            }
            return unescape(cValue);
        },
        name: "Get_Cookie"
    }
};

var app;

var flag = false;

var offy = null,
    offx = null;

var cks = true;

var pages = 0;

var i = 0;

var size = {
    width: window.innerWidth || document.body.clientWidth,
    height: window.innerHeight || document.body.clientHeight
}

for (var s in fncs) {
    app = document.createElement("div");
    app.setAttribute("onclick", "fncs." + s + ".f();");
    app.setAttribute("onmousedown", "tls.tgl.f(this,false);");
    app.setAttribute("onmouseup", "tls.tgl.f(this,true);");
    app.className = "pages" + parseInt(i / 3) + " btnz";
    app.setAttribute("style", "font-size:10px; visibility:hidden; border:5px solid #000000; position:fixed; top:" + (100 * (2 * (i % 3) + 2) / 11) + "%; left:0px; width:60px; height:60px; background-color:#ffffff; color:#000000; display:inline word-break:break-all; word-wrap:break-word;");
    if (fncs[s].image!=undefined) {
        var asp =document.createElement("img");
        asp.setAttribute("src",fncs[s].image);
        asp.setAttribute("height","100%");
        asp.setAttribute("width","100%");
        app.appendChild(asp);
    }
    else if (fncs[s].name!=undefined) {
        app.appendChild(document.createTextNode(fncs[s].name));
    }
    else {
        app.appendChild(document.createTextNode(s));
    }
    document.body.appendChild(app);
    i++;
}

i = 0;

for (s in actz) {
    if (s == "opn") {
        continue;
        var v=s;
    }
    app = document.createElement("div");
    app.setAttribute("onmousedown", "tls.tgl.f(this,false);");
    app.setAttribute("onmouseup", "tls.tgl.f(this,true);");
    app.setAttribute("onclick", "actz." + s + ".f();");
    app.className = "acts btnz";
    if (i == 0) {
        k = 4;
    } 
    else if (i == 1) {
        k = 0;
    } 
    else {
        k = 5;
    }
    app.setAttribute("style", "font-size:10px; visibility:hidden; border:5px solid #000000; position:fixed; top:" + (100 * (2 * k) / 11) + "%; left:0px; width:60px; height:60px; background-color:#ffffff; color:#000000; display:inline word-break:break-all; word-wrap:break-word;");
    if (actz[s].image!=undefined) {
        var asp =document.createElement("img");
        asp.setAttribute("src",actz[s].image);
        asp.setAttribute("height","100%");
        asp.setAttribute("width","100%");
        app.appendChild(asp);
    }
    else if (actz[s].name!=undefined) {
        app.appendChild(document.createTextNode(actz[s].name));
    }
    else {
        app.appendChild(document.createTextNode(s));
    }
    document.body.appendChild(app);
    i++;
}

app = document.createElement("div");
app.setAttribute("onclick", "if (cks) {actz."+s+".f();}; cks=true;");
app.setAttribute("onmousedown", "tls.tgl.f(this,false); tls.sfg.f(true);");
app.setAttribute("ondragstart", "cks=false; return cks;");
app.setAttribute("onmousemove", "tls.drg.f();");
app.setAttribute("onmouseup", "tls.tgl.f(this,true); tls.sfg.f(false);");
app.className = "obtn";
app.setAttribute("id", "img");
app.setAttribute("style", "font-size:10px; opacity:0.5; visibility:visible; position:fixed; top:" + (size.height * 0.75) + "px; left:0px; width:80px; border:5px solid #000000; height:80px; background-color:#ffffff; color:#000000; display:inline word-break:break-all; word-wrap:break-word;");
if (actz[s].image!=undefined) {
    var asp =document.createElement("img");
    asp.setAttribute("height","100%");
    asp.setAttribute("width","100%");
    asp.setAttribute("src",actz[s].image);
    app.appendChild(asp);
}
else if (actz[s].name!=undefined) {
    app.appendChild(document.createTextNode(actz[s].name));
}
else {
    app.appendChild(document.createTextNode(s));
}
document.body.appendChild(app);

if (location.href.indexOf("hitomi") != -1) {
    fncs.hab.f();
    fncs.hlb.f();
}

if (location.href.indexOf("marumaru") != -1 || location.href.indexOf("wasabisyrup") != -1) {
    fncs.mab.f();
}

window.onresize=function () { document.getElementsByClassName("obtn")[0].style.top=(size.height * 0.75) + "px"; };
