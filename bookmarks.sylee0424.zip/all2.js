var a={name:"",path:""};

a.name=document.getElementByTagName("title").innerHTML;
a.path=document.location.href;

a;