﻿var actz = {

    nxt: {
        f: function() {
            var app = document.getElementsByClassName("pages" + pages);
            pages = pages + 1;
            if (parseInt((Object.keys(fncs).length - 1) / 3) < pages) {
                pages = 0;
            }
            var app2 = document.getElementsByClassName("pages" + pages);
            for (var i = 0; i < app.length; i++) {
                app[i].style.visibility = "hidden";
            }
            for (var i = 0; i < app2.length; i++) {
                app2[i].style.visibility = "visible";
            }
        },
        name: "Next_Page",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAIAAACRXR/mAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAFTSURBVFhH7dfbDoMgEIRh3/+l21pJPAC7s7MDIU29NB5+PhXa7bXktqmqtu8mu5rkQkeTsEwwvmuTquxHs2oqCVhWa8WsXlMeLKW1YpbdlATjtR5Zx/zX3ElMjWRWb65SzWGarKuHBIzJskkkYIKs+tXJg4WzEAzkGPs7yGb1rp4Ei2XhDPiRzYGlspwHcU8LzV6BrChA9PjbLIMPgnhdiFPKagFmcUPnztoXMS4LPIteJaEsetB11udSyJCwgxLfFAfmZ2Womr92ELBwFvII8qukk5Wn4sBiWRwV8cPVylJREWCBrAxVFKybpaWKgqFZeaoQWDtrBFUIDMpSUeFgjaxxVDiYn6WlAsGeWaOpQDAnawQVAnbLmkOFgFlZ46hcsDNrJpUL1s0aTWWDlaz5VDZYN6sOnbOn5Db/nMwp6N1lT/pnoc+gaC0Fdr5bc+aC0F3eG3dL3MAvkngAAAAASUVORK5CYII="
    },

    prv: {
        f: function() {
            var app = document.getElementsByClassName("pages" + pages);
            pages = pages - 1;
            if (0 > pages) {
                pages = parseInt((Object.keys(fncs).length - 1) / 3);
            }
            var app2 = document.getElementsByClassName("pages" + pages);
            for (var i = 0; i < app.length; i++) {
                app[i].style.visibility = "hidden";
            }
            for (var i = 0; i < app2.length; i++) {
                app2[i].style.visibility = "visible";
            }
        },
        name: "Previous_Page",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAGGSURBVGhD7ZrBDsMgDEPH/v+ft7USUrsVsBOHAhrXUYj9cOCw9PqMxwIjZSEppSnlZA7PrfpZRRxr34WsMNYSMnPec+3NsI8ispTjU9i3jIxSMJPXY83NjIzQ0ZAaTkJmovJda5PI3fcMQmOr8UfIDFSuaoSI3EUFpXFJZPQOVjoxMJHeVBgaRSKjUqnllyLSiwpLo0pkNCqtbkoTiaZiodEkMgqVFg1ISOkRZ3Wu9ij0rAkdLcQR5tXKzEX3hoT0oOKhQR0t1BnG7dZcZk8XEVUH89KgiPTuYAwNWkhEVhQ0TEJYp1o5uPrdsoc7I7kQi7OWb0rGmIRYHEPJWNc2CVFkRUnDlJEswupcjYxnTSkR9F5R03ARUd8rHhpuIZasRNCQCPE6qSIrz0jtXomiISHidVRBVCYEyUokDakQi7OWb6RPFPS5ke+VaBpSImxWlDTkQhhS6rny9os4jcxhhcqFsAWo5ocIqTkeQeOfEeQ4XDkfRSOcyLHwSBH7ffXZYIk/nr0Bj86jMw2qxo0AAAAASUVORK5CYII="
    },

    cls: {
        f: function() {
            document.getElementsByClassName("offbutton")[0].style.visibility = "visible";
            for (var i = 0; i < document.getElementsByClassName("button").length; i++) {
                document.getElementsByClassName("button")[i].style.visibility = "hidden";
            }
        },
        name: "Close_Button_Tab"
    },

    opn: {
        f: function() {
            document.getElementsByClassName("offbutton")[0].style.visibility = "hidden";
            for (var i = 0; i < document.getElementsByClassName("pages" + pages).length; i++) {
                document.getElementsByClassName("pages0")[i].style.visibility = "visible";
            }
            for (i = 0; i < document.getElementsByClassName("acts").length; i++) {
                document.getElementsByClassName("acts")[i].style.visibility = "visible";
            }
        },
        name: "Open_Button_Tab"
    }

};

var fncs = {
    cnt: {
        f: function(e) {
            if (!e) {
                e = document.body;
            }
            if (e.tagName && e.tagName != "#text") {
                for (var i = 0; i < e.childNodes.length; i++) {
                    fncs.cnt(e.childNodes[i]);
                }
            }
            c++;
        },
        name: "Count_Nodes"
    },

    lnk: {
        f: function(element) {
            var i;
            if (!element) {
                element = document.body;
            }
            if (element.nodeName == "#text" && !(element.nodeName == "#comment" || element.tagName)) {
                var nv = element.nodeValue;
                var ids = new Array();
                var at = nv.split(/h{0,1}ttps{0,1}:\/\/[a-zA-Z0-9\/\?\!\@\#\$\%\^\&\*\_\-\+\=\\:\.\,]+/g);
                var ss = nv.match(/h{0,1}ttps{0,1}:\/\/[a-zA-Z0-9\/\?\!\@\#\$\%\^\&\*\_\-\+\=\\:\.\,]+/g);
                var aq = new Array();
                var id = 0;
                ids[0] = at[0].length;
                aq[0] = element;
                if (ss) {
                    for (var i = 0; i < ss.length; i++) {
                        ids[i + 1] = ids[i] + ss[i].length + at[i + 1].length;
                    }
                }
                if (element.parentNode.tagName != "SCRIPT" && ss) {
                    for (i = 0; i < at.length - 1; i++) {
                        if (i == 0) {
                            aq[1] = aq[0].splitText(ids[0]);
                            if (at.length - 1 == 1) {
                                aq[1] = aq[1].splitText(ss[0].length);
                                aq[1].parentNode.removeChild(aq[1].previousSibling);
                            }
                        } else {
                            aq[i + 1] = aq[i].splitText(ids[i] - ids[i - 1]);
                            aq[i] = aq[i].splitText(ss[i - 1].length);
                            aq[i + 1].parentNode.removeChild(aq[i + 1].previousSibling);
                        }
                        var a = document.createElement("a");
                        a.setAttribute("target", "_blank");
                        a.setAttribute("href", ss[i].replace(/(h?)ttp(s?):\/\/([a-zA-Z0-9\/\?\!\@\#\$\%\^\&\*\_\-\+\=\|\\:\.\,]*)/g, "http$2://$3"));
                        a.appendChild(document.createTextNode(ss[i]));
                        aq[i + 1].parentNode.insertBefore(a, aq[i + 1]);
                    }
                }
            } else {
                for (i = 0; i < element.childNodes.length; i++) {
                    i = fncs.lnk.f(element.childNodes[i]);
                }
            }
            if (aq) {
                return tls.gcn.f(aq[aq.length - 1]);
            } else {
                return tls.gcn.f(element);
            }
        },
        name: "ttp://_Make_Link"
    },

    alts: {
        f: function() {
            document.location.href = "https://hitomi.la/index-korean-1.html";
        },
        name: "Move_To_hitomi"
    },

    led: {
        f: function() {
            var br = document.getElementById("view_content").getElementsByTagName("div");
            for (var i = 0; i < br.length; i++) {
                br[i].style.display = "inline"
            }
        },
        name: "Blink_Line_Fix"
    },

    rtl: {
        f: function() {
            var br = document.getElementById("view_content").getElementsByTagName("div");
            for (var i = 0; i < br.length; i++) {
                br[i].style.display = "block"
            }
        },
        name: "Return_Blink_Line"
    },

    hab: {
        f: function() {
            var i = 0;
            var b;
            var galleryId = location.href.split("/")[location.href.split("/").length - 1].split(".")[0];
            var scripts = document.getElementsByTagName('script');
            i = scripts.length;
            while (i--) {
                scripts[i].parentNode.removeChild(scripts[i]);
            }
            scripts = document.getElementsByTagName('noscript');
            i = scripts.length;
            while (i--) {
                scripts[i].parentNode.removeChild(scripts[i]);
            }
            scripts = document.getElementsByTagName('iframe');
            i = scripts.length;
            while (i--) {
                scripts[i].parentNode.removeChild(scripts[i]);
            }
            var scr = document.createElement('script');
            scr.src = 'https://hitomi.la/galleries/' + galleryId + '.js';
            document.body.appendChild(scr);
            divs = document.getElementsByTagName('style');
            i = divs.length;
            while (i--) {
                divs[i].parentNode.removeChild(divs[i]);
            }
            document.ontouchstart = "event.stopImmediatePropagation();";
            document.onmousedown = "event.stopImmediatePropagation(); return false;";
            document.onclick = "event.stopImmediatePropagation(); return false;";
            document.body.ontouchstart = "event.stopImmediatePropagation();";
            document.body.onmousedown = "event.stopImmediatePropagation();";
            window.onbeforeunload = "event.stopImmediatePropagation();";
            if (document.getElementsByClassName("page-container").length != 0) {
                divs = document.getElementsByClassName("page-container")[0].getElementsByTagName("li");
                i = divs.length;
                while (i--) {
                    if (divs[i].innerHTML == location.href.split("-")[location.href.split("-").length - 1].split(".")[0]) {
                        divs[i].setAttribute("style", "color:#ff00ff");
                    }
                }
            }
        },
        name: "hitomi_Ad_Block"
    },

    hid: {
        f: function() {
            var num1 = Number(prompt("max", "-1"));
            var num2 = Number(prompt("min", "0"));
            var a = prompt("a or b", "b"); // a or b
            var galleryId = location.href.split("/")[location.href.split("/").length - 1].split(".")[0];
            if (location.href.indexOf("/reader/") != -1 || location.href.indexOf("/galleries/") != -1) {
                var i = galleryinfo.length;
                if (i > num1 && num1 != -1) {
                    i = num1;
                }
                var k = 0;
                if (a == "a") {
                    document.getElementsByTagName("head")[0].innerHTML = "";
                    document.getElementsByTagName("body")[0].innerHTML = "";
                    while ((i--) - num2) {
                        var img = document.createElement("img");
                        img.src = "https://hitomi.la/galleries/" + galleryId + "/" + galleryinfo[i - num2].name;
                        document.body.insertBefore(img, document.body.firstChild);
                    }
                } else {
                    while ((i--) - num2) {
                        var m = "";
                        if ((i + 1) / 10 < 1) {
                            m = m + "0";
                        }
                        if ((i + 1) / 100 < 1) {
                            m = m + "0";
                        }
                        var hrf = document.createElement("a");
                        hrf.name = "hrf";
                        document.body.appendChild(hrf);
                        hrf = document.getElementsByName("hrf")[0];
                        hrf.href = "https://" + document.getElementsByTagName("img")[0].src.split(".hitomi.la/")[0].split("//")[1] + ".hitomi.la/galleries/" + galleryId + "/" + galleryinfo[i].name;
                        hrf.download = "hitomi_" + galleryId + "_" + m + (i + 1) + ".jpg";
                        hrf.name = "href";
                        if (hrf.click) {
                            hrf.click();
                        } else if (document.createEvent) {
                            var eventObj = document.createEvent('MouseEvents');
                            eventObj.initEvent('click', true, true);
                            hrf.dispatchEvent(eventObj);
                        }
                    }
                }
            } else {
                alert("갤러리/리더 화면이 아닙니다.");
            }
        },
        name: "hid"
    },

    fde: {
        f: function(element) {
            if (!element) {
                element = document.documentElement;
            }
            if (element.attributes) {
                if (element.id != "img") {
                    element.removeAttribute("ondragstart");
                }
                element.removeAttribute("onselectstart");
                element.removeAttribute("oncontextmenu");
            }
            for (i = 0; i < element.childNodes.length; i++) {
                i = fncs.fde.f(element.childNodes[i]);
            }
            return tls.gcn.f(element);
        },
        name: "fde"
    },

    hlb: {
        f: function() {
            var d = 0;
            var divs = document.getElementsByTagName('a');
            var i = divs.length;
            while (i--) {
                var k = divs[i].getAttribute("href");
                if (k && divs[i].id != "dl-button" && divs[i].parentNode.parentNode.getAttribute("class") != "simplePagerNav") {
                    divs[i].setAttribute("onclick", "tls.tss.f(" + i + ",0,'" + k + "');");
                    if (divs[i].parentNode.parentNode.parentNode.getAttribute("class") == "page-container") {
                        divs[i].setAttribute("onclick", "location.href = 'https://hitomi.la" + k + "';");
                    }
                    if (divs[i].parentNode.parentNode.parentNode.getAttribute("class") != "page-container" && divs[i].parentNode.tagName != "DIV" && divs[i].href != "/") {
                        if (k.indexOf("galleries") != -1) {
                            var b = k.split("galleries");
                            divs[i].insertBefore(document.createElement("span"), divs[i].firstChild);
                            j = divs[i].firstChild;
                            j.innerHTML = "(R) ";
                            j.setAttribute("onclick", "tls.tss.f(" + i + ",2,'" + k + "'); event.stopPropagation();");
                        }
                        if (k.indexOf("-all-") != -1) {
                            b = k.split("-all-");
                            divs[i].insertBefore(document.createElement("span"), divs[i].firstChild);
                            j = divs[i].firstChild;
                            j.innerHTML = "(K) ";
                            j.setAttribute("onclick", "tls.tss.f(" + i + ",1,'" + k + "'); event.stopPropagation();");
                        }
                        d = 0;
                    } else {
                        d = 1;
                        divs[i].outerHTML = "<span" + divs[i].outerHTML.substring(2, divs[i].outerHTML.length - 2) + "span>";
                    }
                    var inp = document.createElement("input");
                    var inq = document.createElement("label");
                    var tx = document.createTextNode("N");
                    inp.type = "checkbox";
                    inq.setAttribute("style", "display:inline");
                    if (d == 1 || divs[i].parentNode.parentNode.parentNode.parentNode.class == "page-content") {
                        inq.setAttribute("style", "display:none");
                    }
                    inp.name = "input-" + i;
                    inp.setAttribute("onclick", "event.stopPropagation();");
                    inp.setAttribute("style", "vertical-align:middle");
                    inq.setAttribute("onclick", "tls.kxx.f(" + i + "); event.stopPropagation();");
                    inq.appendChild(tx);
                    inq.appendChild(inp);
                    divs[i].insertBefore(inq, divs[i].firstChild);
                    divs[i].removeAttribute("href");
                }
            }
            divs = document.getElementsByClassName("page-content")[0].getElementsByTagName("label");
            i = divs.length;
            while (i--) {
                divs[i].setAttribute("style", "display:none");
            }
        },
        name: "hitomi_Link_Change"
    },

    mab: {
        f: function() {
            var i = document.getElementsByTagName("iframe");
            var j = i.length;
            while (j--) {
                i[j].width = "0px";
                i[j].height = "0px";
                i[j].removeAttribute("src");
            }
            i = document.getElementById("responsive-banner");
            i.style.visibility = "hidden";
        },
        name: "mab"
    }

};

var tls = {

    sfg: {
        f: function(flag_) {
            flag = flag_;
            offy = event.y;
            offx = event.x;
        },
        name: "sfg"
    },

    drg: {
        f: function() {
            var img = document.getElementById("img");
            if (!flag) return;
            var top = Number(img.style.top.replace('px', '')) + event.y - offy;
            var left = Number(img.style.left.replace('px', '')) + event.x - offx;
            img.style.top = top + "px";
            img.style.left = left + 'px';
            offy = event.y;
            offx = event.x;
        },
        name: "drg"
    },

    tgl: {
        f: function(element, bool) {
            if (bool) {
                element.style.backgroundColor = "#ffffff"
            } else {
                element.style.backgroundColor = "gold"
            }
        },
        name: "Toggle_Buttons"
    },

    fev: {
        f: function(element, event) {
            if (document.createEventObject) {
                var evt = document.createEventObject();
                return element.tls.fev('on' + event, evt);
            } else {
                var evt = document.createEvent("HTMLEvents");
                evt.initEvent(event, true, true);
                return !(element.dispatchEvent(evt));
            }
        },
        name: "Fire_Event"
    },

    clc: {
        f: function(hrf) {
            if (hrf.click) {
                hrf.click();
            } else if (document.createEvent) {
                var eventObj = document.createEvent('MouseEvents');
                eventObj.initEvent('click', true, true);
                hrf.dispatchEvent(eventObj);
            }
        },
        name: "Emulate_Click_Event"
    },

    gcn: {
        f: function(node) {
            return Array.prototype.indexOf.call(node.parentNode.childNodes, node);
        },
        name: "Get_Child_Number"
    },

    tss: {
        f: function(i, j, k) {
            var url;
            if (j == 0) {
                url = "https://hitomi.la" + k;
            } else if (j == 1) {
                url = "https://hitomi.la" + k.split("-all-")[0] + "-korean-" + k.split("-all-")[1];
            } else {
                url = "https://hitomi.la" + k.split("galleries")[0] + "reader" + k.split("galleries")[1] + "#1";
            }
            if (document.getElementsByName("input-" + i)[0].checked == "1") {
                window.open(url)
            } else {
                location.href = url;
            }
        },
        name: "hitomi_Click_Action"
    },

    kxx: {
        f: function(i) {
            if (document.getElementsByName("input-" + i)[0].getAttribute('checked') == '1') {
                document.getElementsByName("input-" + i)[0].setAttribute('checked', '0');
            } else {
                document.getElementsByName("input-" + i)[0].setAttribute('checked', '1');
            }
        },
        name: "Check_Set"
    }

};

var app;

var flag = false;

var offy = null,
    offx = null;

var cks = true;

var pages = 0;

var i = 0;

var size = {
    width: window.innerWidth || document.body.clientWidth,
    height: window.innerHeight || document.body.clientHeight
}

for (var s in fncs) {
    app = document.createElement("div");
    app.setAttribute("onclick", "fncs." + s + ".f();");
    app.setAttribute("onmousedown", "tls.tgl.f(this,false);");
    app.setAttribute("onmouseup", "tls.tgl.f(this,true);");
    app.className = "pages" + parseInt(i / 3) + " button";
    app.setAttribute("style", "font-size:auto; visibility:hidden; border:5px solid #000000; position:fixed; top:" + (100 * (2 * (i % 3) + 2) / 11) + "%; left:0px; width:60px; height:60px; background-color:#ffffff; color:#000000; display:inline word-break:break-all; word-wrap:break-word;");
    if (fncs[s].image!=undefined) {
        var asp =document.createElement("img");
        asp.setAttribute("src",fncs[s].image);
        asp.setAttribute("height","100%");
        asp.setAttribute("width","100%");
        app.appendChild(asp);
    }
    if (fncs[s].name!=undefined) {
        app.appendChild(document.createTextNode(fncs[s].name));
    }
    else {
        app.appendChild(document.createTextNode(s));
    }
    document.body.appendChild(app);
    i++;
}

i = 0;

for (s in actz) {
    if (s == "opn") {
        continue;
        var v=s;
    }
    app = document.createElement("div");
    app.setAttribute("onmousedown", "tls.tgl.f(this,false);");
    app.setAttribute("onmouseup", "tls.tgl.f(this,true);");
    app.setAttribute("onclick", "actz." + s + ".f();");
    app.className = "acts button";
    if (i == 0) {
        k = 0;
    } else if (i == 1) {
        k = 4;
    } else {
        k = 5;
    }
    app.setAttribute("style", "font-size:auto; visibility:hidden; border:5px solid #000000; position:fixed; top:" + (100 * (2 * k) / 11) + "%; left:0px; width:60px; height:60px; background-color:#ffffff; color:#000000; display:inline word-break:break-all; word-wrap:break-word;");
    if (actz[s].image!=undefined) {
        var asp =document.createElement("img");
        asp.setAttribute("src",actz[s].image);
        asp.setAttribute("height","100%");
        asp.setAttribute("width","100%");
        app.appendChild(asp);
    }
    else if (actz[s].name!=undefined) {
        app.appendChild(document.createTextNode(actz[s].name));
    }
    else {
        app.appendChild(document.createTextNode(s));
    }
    document.body.appendChild(app);
    i++;
}

app = document.createElement("div");
app.setAttribute("onclick", "if (cks) {actz."+s+".f();}; cks=true;");
app.setAttribute("onmousedown", "tls.tgl.f(this,false); tls.sfg.f(true);");
app.setAttribute("ondragstart", "cks=false; return cks;");
app.setAttribute("onmousemove", "tls.drg.f();");
app.setAttribute("onmouseup", "tls.tgl.f(this,true); tls.sfg.f(false);");
app.className = "offbutton";
app.setAttribute("id", "img");
app.setAttribute("style", "font-size:auto; opacity:0.5; visibility:visible; position:fixed; top:" + (size.height * 0.75) + "px; left:0px; width:80px; border:5px solid #000000; height:80px; background-color:#ffffff; color:#000000; display:inline word-break:break-all; word-wrap:break-word;");
if (actz[s].image!=undefined) {
    var asp =document.createElement("img");
    asp.setAttribute("height","100%");
    asp.setAttribute("width","100%");
    asp.setAttribute("src",actz[s].image);
    app.appendChild(asp);
}
else if (actz[s].name!=undefined) {
    app.appendChild(document.createTextNode(actz[s].name));
}
else {
    app.appendChild(document.createTextNode(s));
}
document.body.appendChild(app);

if (location.href.indexOf("hitomi") != -1) {
    fncs.hab.f();
    fncs.hlb.f();
}

if (location.href.indexOf("marumaru") != -1 || location.href.indexOf("wasabisyrup") != -1) {
    fncs.mab.f();
}