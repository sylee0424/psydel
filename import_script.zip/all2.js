﻿var actz = {

    nxt: function() {
        var app = document.getElementsByClassName("pages" + pages);
        pages = pages + 1;
        if (parseInt((strs.length - 1) / 3) < pages) {
            pages = 0;
        }
        var app2 = document.getElementsByClassName("pages" + pages);
        for (var i = 0; i < app.length; i++) {
            app[i].style.visibility = "hidden";
        }
        for (var i = 0; i < app2.length; i++) {
            app2[i].style.visibility = "visible";
        }
    },

    prv: function() {
        var app = document.getElementsByClassName("pages" + pages);
        pages = pages - 1;
        if (0 > pages) {
            pages = parseInt((strs.length - 1) / 3);
        }
        var app2 = document.getElementsByClassName("pages" + pages);
        for (var i = 0; i < app.length; i++) {
            app[i].style.visibility = "hidden";
        }
        for (var i = 0; i < app2.length; i++) {
            app2[i].style.visibility = "visible";
        }
    },

    cls: function() {
        document.getElementsByClassName("offbutton")[0].style.visibility = "visible";
        for (var i = 0; i < document.getElementsByClassName("button").length; i++) {
            document.getElementsByClassName("button")[i].style.visibility = "hidden";
        }
    },

    opn: function() {
        document.getElementsByClassName("offbutton")[0].style.visibility = "hidden";
        for (var i = 0; i < document.getElementsByClassName("pages" + pages).length; i++) {
            document.getElementsByClassName("pages0")[i].style.visibility = "visible";
        }
        for (i = 0; i < document.getElementsByClassName("acts").length; i++) {
            document.getElementsByClassName("acts")[i].style.visibility = "visible";
        }
    }

};

var fncs = {
    cnt: function(e) {
        if (!e) {
            e = document.body;
        }
        if (e.tagName && e.tagName != "#text") {
            for (var i = 0; i < e.childNodes.length; i++) {
                fncs.cnt(e.childNodes[i]);
            }
        }
        c++;
    },

    lnk: function(element) {
        /*
        at[0]ss[0]at[1]ss[1]at[2]ss[2]at[3]ss[3]at[4]ss[4]at[5]
        -----aaaaa-----aaaaa-----aaaaa-----aaaaa-----aaaaa-----
             ids[0]    ids[1]    ids[2]    ids[3]    ids[4]
        └───────────────────────element───────────────────────┘
        */
        var i;
        if (!element) {
            element = document.body;
        }
        if (element.nodeName == "#text" && !(element.nodeName == "#comment" || element.tagName)) {
            var nv = element.nodeValue;
            var ids = new Array();
            var at = nv.split(/h{0,1}ttps{0,1}:\/\/[a-zA-Z0-9\/\?\!\@\#\$\%\^\&\*\_\-\+\=\\:\.\,]+/g);
            var ss = nv.match(/h{0,1}ttps{0,1}:\/\/[a-zA-Z0-9\/\?\!\@\#\$\%\^\&\*\_\-\+\=\\:\.\,]+/g);
            var aq = new Array();
            var id = 0;
            ids[0] = at[0].length;
            aq[0] = element;
            if (ss) {
                for (var i = 0; i < ss.length; i++) {
                    ids[i + 1] = ids[i] + ss[i].length + at[i + 1].length;
                }
            }
            if (element.parentNode.tagName != "SCRIPT" && ss) {
                for (i = 0; i < at.length - 1; i++) {
                    if (i == 0) {
                        aq[1] = aq[0].splitText(ids[0]);
                        if (at.length - 1 == 1) {
                            aq[1] = aq[1].splitText(ss[0].length);
                            aq[1].parentNode.removeChild(aq[1].previousSibling);
                        }
                    } else {
                        aq[i + 1] = aq[i].splitText(ids[i] - ids[i - 1]);
                        aq[i] = aq[i].splitText(ss[i - 1].length);
                        aq[i + 1].parentNode.removeChild(aq[i + 1].previousSibling);
                    }
                    var a = document.createElement("a");
                    a.setAttribute("target", "_blank");
                    a.setAttribute("href", ss[i].replace(/(h?)ttp(s?):\/\/([a-zA-Z0-9\/\?\!\@\#\$\%\^\&\*\_\-\+\=\|\\:\.\,]*)/g, "http$2://$3"));
                    a.appendChild(document.createTextNode(ss[i]));
                    aq[i + 1].parentNode.insertBefore(a, aq[i + 1]);
                }
            }
        } else {
            console.log(element.childNodes);
            for (i = 0; i < element.childNodes.length; i++) {
                i = fncs.lnk(element.childNodes[i]);
            }
        }
        if (aq) {
            return getChildNumber(aq[aq.length - 1]);
        } else {
            return getChildNumber(element);
        }
    },

    alts: function() {
        document.location.href = "https://hitomi.la/index-korean-1.html";
    },

    led: function() {
        var br = document.getElementById("view_content").getElementsByTagName("div");
        for (var i = 0; i < br.length; i++) {
            br[i].style.display = "inline"
        }
    },

    rtl: function() {
        var br = document.getElementById("view_content").getElementsByTagName("div");
        for (var i = 0; i < br.length; i++) {
            br[i].style.display = "block"
        }
    },

    hab: function() {
        var i = 0;
        var b;
        var galleryId = location.href.split("/")[location.href.split("/").length - 1].split(".")[0];
        var scripts = document.getElementsByTagName('script');
        i = scripts.length;
        while (i--) {
            scripts[i].parentNode.removeChild(scripts[i]);
        }
        scripts = document.getElementsByTagName('noscript');
        i = scripts.length;
        while (i--) {
            scripts[i].parentNode.removeChild(scripts[i]);
        }
        scripts = document.getElementsByTagName('iframe');
        i = scripts.length;
        while (i--) {
            scripts[i].parentNode.removeChild(scripts[i]);
        }
        var scr = document.createElement('script');
        scr.src = 'https://hitomi.la/galleries/' + galleryId + '.js';
        document.body.appendChild(scr);
        divs = document.getElementsByTagName('style');
        i = divs.length;
        while (i--) {
            divs[i].parentNode.removeChild(divs[i]);
        }
        if (document.getElementsByClassName("page-container").length != 0) {
            divs = document.getElementsByClassName("page-container")[0].getElementsByTagName("li");
            i = divs.length;
            while (i--) {
                if (divs[i].innerHTML == location.href.split("-")[location.href.split("-").length - 1].split(".")[0]) {
                    divs[i].setAttribute("style", "color:#ff00ff");
                }
            }
        }

        var scr = document.createElement("script");
        var inn = document.createTextNode(tss.valueOf());
        scr.type = "text/javascript";
        scr.appendChild(inn);
        document.body.appendChild(scr);

        scr = document.createElement("script");
        inn = document.createTextNode(kxx.valueOf());
        scr.type = "text/javascript";
        scr.appendChild(inn);
        document.body.appendChild(scr);
        document.ontouchstart = "event.stopImmediatePropagation();";
        document.body.ontouchstart = "event.stopImmediatePropagation();";
        document.body.onmousedown = "event.stopImmediatePropagation();";
        window.onbeforeunload = "event.stopImmediatePropagation();";
    },

    hid: function() {
        var num1 = Number(prompt("max", "-1"));
        var num2 = Number(prompt("min", "0"));
        var a = prompt("a or b", "b"); // a or b
        var galleryId = location.href.split("/")[location.href.split("/").length - 1].split(".")[0];
        if (location.href.indexOf("/reader/") != -1 || location.href.indexOf("/galleries/") != -1) {
            var i = galleryinfo.length;
            if (i > num1 && num1 != -1) {
                i = num1;
            }
            var k = 0;
            if (a == "a") {
                document.getElementsByTagName("head")[0].innerHTML = "";
                document.getElementsByTagName("body")[0].innerHTML = "";
                while ((i--) - num2) {
                    var img = document.createElement("img");
                    img.src = "https://hitomi.la/galleries/" + galleryId + "/" + galleryinfo[i - num2].name;
                    document.body.insertBefore(img, document.body.firstChild);
                }
            } else {
                while ((i--) - num2) {
                    var m = "";
                    if ((i + 1) / 10 < 1) {
                        m = m + "0";
                    }
                    if ((i + 1) / 100 < 1) {
                        m = m + "0";
                    }
                    var hrf = document.createElement("a");
                    hrf.name = "hrf";
                    document.body.appendChild(hrf);
                    hrf = document.getElementsByName("hrf")[0];
                    hrf.href = "https://" + document.getElementsByTagName("img")[0].src.split(".hitomi.la/")[0].split("//")[1] + ".hitomi.la/galleries/" + galleryId + "/" + galleryinfo[i].name;
                    hrf.download = "hitomi_" + galleryId + "_" + m + (i + 1) + ".jpg";
                    hrf.name = "href";
                    if (hrf.click) {
                        hrf.click();
                    } else if (document.createEvent) {
                        var eventObj = document.createEvent('MouseEvents');
                        eventObj.initEvent('click', true, true);
                        hrf.dispatchEvent(eventObj);
                    }
                }
            }
        } else {
            alert("갤러리/리더 화면이 아닙니다.");
        }
    },

    fde: function(element) {
        if (!element) {
            element = document.documentElement;
        }
        if (element.attributes) {
            if (element.id != "img") {
                element.removeAttribute("ondragstart");
            }
            element.removeAttribute("onselectstart");
            element.removeAttribute("oncontextmenu");
        }
        for (i = 0; i < element.childNodes.length; i++) {
            i = fncs.fde(element.childNodes[i]);
        }
        return getChildNumber(element);
    },

    hlb: function() {
        var d = 0;
        var divs = document.getElementsByTagName('a');
        var i = divs.length;
        while (i--) {
            var k = divs[i].getAttribute("href");
            if (k && divs[i].id != "dl-button" && divs[i].parentNode.parentNode.getAttribute("class") != "simplePagerNav") {
                divs[i].setAttribute("onclick", "tss(" + i + ",0,'" + k + "');");
                if (divs[i].parentNode.parentNode.parentNode.getAttribute("class") == "page-container") {
                    divs[i].setAttribute("onclick", "location.href = 'https://hitomi.la" + k + "';");
                }
                if (divs[i].parentNode.parentNode.parentNode.getAttribute("class") != "page-container" && divs[i].parentNode.tagName != "DIV" && divs[i].href != "/") {
                    if (k.indexOf("galleries") != -1) {
                        var b = k.split("galleries");
                        divs[i].insertBefore(document.createElement("span"), divs[i].firstChild);
                        j = divs[i].firstChild;
                        j.innerHTML = "(R) ";
                        j.setAttribute("onclick", "tss(" + i + ",2,'" + k + "'); event.stopPropagation();");
                    }
                    if (k.indexOf("-all-") != -1) {
                        b = k.split("-all-");
                        divs[i].insertBefore(document.createElement("span"), divs[i].firstChild);
                        j = divs[i].firstChild;
                        j.innerHTML = "(K) ";
                        j.setAttribute("onclick", "tss(" + i + ",1,'" + k + "'); event.stopPropagation();");
                    }
                    d = 0;
                } else {
                    d = 1;
                    divs[i].outerHTML = "<span" + divs[i].outerHTML.substring(2, divs[i].outerHTML.length - 2) + "span>";
                }
                var inp = document.createElement("input");
                var inq = document.createElement("label");
                var tx = document.createTextNode("N");
                inp.type = "checkbox";
                inq.setAttribute("style", "display:inline");
                if (d == 1 || divs[i].parentNode.parentNode.parentNode.parentNode.class == "page-content") {
                    inq.setAttribute("style", "display:none");
                }
                inp.name = "input-" + i;
                inp.setAttribute("onclick", "event.stopPropagation();");
                inp.setAttribute("style", "vertical-align:middle");
                inq.setAttribute("onclick", "kxx(" + i + "); event.stopPropagation();");
                inq.appendChild(tx);
                inq.appendChild(inp);
                divs[i].insertBefore(inq, divs[i].firstChild);
                divs[i].removeAttribute("href");
            }
        }
        divs = document.getElementsByClassName("page-content")[0].getElementsByTagName("label");
        i = divs.length;
        while (i--) {
            divs[i].setAttribute("style", "display:none");
        }
    }

};

var app;
var i=0;
for (var s in fncs) {
    app = document.createElement("div");
    app.setAttribute("onclick", "fncs." + s + "();");
    app.setAttribute("onmousedown", "toggle(this,false)");
    app.setAttribute("onmouseup", "toggle(this,true)");
    app.className = "pages" + parseInt(i / 3) + " button";
    app.setAttribute("style", "visibility:hidden; border:5px solid #000000; position:fixed; top:" + (100 * (2 * (i % 3) + 2) / 11) + "%; left:0px; width:60px; height:60px; background-color:#ffffff; color:#000000; display:inline");
    app.appendChild(document.createTextNode(s));
    document.body.appendChild(app);
    i++;
}

i=0;
  
for (s in actz) {
    if (i==Object.keys(actz).length - 1) {
        break;
    }
    app = document.createElement("div");
    app.setAttribute("onmousedown", "toggle(this,false)");
    app.setAttribute("onmouseup", "toggle(this,true)");
    app.setAttribute("onclick", "actz." + s + "();");
    app.className = "acts button";
    if (i == 0) {
        k = 0;
    } else if (i == 1) {
        k = 4;
    } else {
        k = 5;
    }
    app.setAttribute("style", "visibility:hidden; border:5px solid #000000; position:fixed; top:" + (100 * (2 * k) / 11) + "%; left:0px; width:60px; height:60px; background-color:#ffffff; color:#000000; display:inline");
    app.appendChild(document.createTextNode(s));
    document.body.appendChild(app);
    i++;
}

var size = {
    width: window.innerWidth || document.body.clientWidth,
    height: window.innerHeight || document.body.clientHeight
}

var diva = document.createElement("div");
diva.setAttribute("onclick", "if (cks) {actz.opn();}; cks=true;");
diva.setAttribute("onmousedown", "toggle(this,false); setFlag(true);");
diva.setAttribute("ondragstart", "cks=false; return false;");
diva.setAttribute("onmousemove", "dragImg()");
diva.setAttribute("onmouseup", "toggle(this,true); setFlag(false);");
diva.className = "offbutton";
diva.setAttribute("id", "img");
diva.setAttribute("style", "opacity:0.5; visibility:visible; position:fixed; top:" + (size.height * 0.75) + "px; left:0px; width:80px; border:5px solid #000000; height:80px; background-color:#ffffff; color:#000000; display:inline");
diva.appendChild(document.createTextNode("opn"));
document.body.appendChild(diva);
var flag = false;
var offy = null,
    offx = null;
var cks = true;

function setFlag(flag_) {
    flag = flag_;
    offy = event.y;
    offx = event.x;
}

function dragImg() {
    var img = document.getElementById("img");
    if (!flag) return;
    var top = Number(img.style.top.replace('px', '')) + event.y - offy;
    var left = Number(img.style.left.replace('px', '')) + event.x - offx;
    img.style.top = top + "px";
    img.style.left = left + 'px';
    offy = event.y;
    offx = event.x;
}

var pages = 0;

if (location.href.indexOf("hitomi") != -1) {
    fncs.hab();
    fncs.hlb();
}

function toggle(element, bool) {
    if (bool) {
        element.style.backgroundColor = "#ffffff"
    } else {
        element.style.backgroundColor = "gold"
    }
}

function fireEvent(element, event) {
    if (document.createEventObject) {
        var evt = document.createEventObject();
        return element.fireEvent('on' + event, evt);
    } else {
        var evt = document.createEvent("HTMLEvents");
        evt.initEvent(event, true, true);
        return !(element.dispatchEvent(evt));
    }
}

function clc(hrf) {
    if (hrf.click) {
        hrf.click();
    } else if (document.createEvent) {
        var eventObj = document.createEvent('MouseEvents');
        eventObj.initEvent('click', true, true);
        hrf.dispatchEvent(eventObj);
    }
}

function getChildNumber(node) {
    return Array.prototype.indexOf.call(node.parentNode.childNodes, node);
}

function tss(i, j, k) {
    var url;
    if (j == 0) {
        url = "https://hitomi.la" + k;
    } else if (j == 1) {
        url = "https://hitomi.la" + k.split("-all-")[0] + "-korean-" + k.split("-all-")[1];
    } else {
        url = "https://hitomi.la" + k.split("galleries")[0] + "reader" + k.split("galleries")[1] + "#1";
    }
    if (document.getElementsByName("input-" + i)[0].checked == "1") {
        window.open(url)
    } else {
        location.href = url;
    }
}

function kxx(i) {
    if (document.getElementsByName("input-" + i)[0].getAttribute('checked') == '1') {
        document.getElementsByName("input-" + i)[0].setAttribute('checked', '0');
    } else {
        document.getElementsByName("input-" + i)[0].setAttribute('checked', '1');
    }
}

function getMethod(obj) {
    var methods = [];
    for (var m in obj) {
        if (typeof obj[m] == "function" && obj.hasOwnProperty(m)) {
            methods.push(m);
        }
    }
    return methods;
}