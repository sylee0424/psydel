function setbookmark() {
	var req = new XMLHttpRequest();
	req.open('GET', geturl("bmk.json"), false);
	req.onreadystatechange = function (aEvt) {
		if (req.readyState == 4&&req.status == 200) {
			jsn=JSON.parse(req.responseText);
			for (var s in jsn) {
				chrome.bookmarks.create({'parentId': bookmarkBar.id,'title': jsn[s].name,'url': jsn[s].path});
			}
		}
	};
	req.send(null);
}

function addbookmark() {
	chrome.tabs.executeScript({file:geturl("all2.js")},function (result) {
		var req = new XMLHttpRequest();
		req.open('GET', geturl("bmk.json"), false);
		req.onreadystatechange = function (aEvt) {
			if (req.readyState == 4&&req.status == 200) {
				jsn=JSON.parse(req.responseText);
				jsn[""+Object.keys(jsn).length]=result;
				var a=document.createElement("a");
				a.href=encodeURI(JSON.stringify(jsn));
				a.download=geturl("bmk.json");
				document.body.appendChild(a);
				if (a.click) {
					a.click();
				} else if (document.createEvent) {
					var eventObj = document.createEvent('MouseEvents');
					eventObj.initEvent('click', true, true);
					a.dispatchEvent(eventObj);
				}
			}
		};
		req.send(null);
	});
}
var jsn;
var geturl=chrome.extension.getURL||chrome.runtime.getURL;

function clc(){
	document.getElementById("b1").addEventListener("click", function(){setbookmark()});
	document.getElementById("b2").addEventListener("click", function(){addbookmark()});
	document.removeEventListener("click",clc );
}

document.addEventListener("click",clc );


//chrome.bookmarks.create({'parentId': bookmarkBar.id,'title': 'Extensions doc','url': 'http://code.google.com/chrome/extensions'});