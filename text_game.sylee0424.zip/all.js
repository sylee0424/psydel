// function tab {

var intv=null;
/*
Object.prototype.toString= function () {
	var ret="{\n";
	for (var s in this) {
		if (typeof this[s] == "object"&&i<3) {
			ret+=s+": "+this[s].toString()+"\n";
		}
		else if (typeof this[s] == "object"&&i>=3) {
			ret+=s+": {too deep object}\n";
		}
		else if (typeof this[s] == "array") {
			ret+=s+": [";
			for (var t in this[s]) {
				ret+="\""+this[s][t].toString() +"\",";
			}
			ret=ret.substring(0,ret.length);
			ret+="]\n";
		}
		else {
			ret+=s+": "+this[s].toString() +"\n";
		}
	}
	return ret+"}";
}
*/
if (!console) {
	var console={
		text:"",
		log: function () {
			if (arguments[0]) {
				this.text+="\n"+arguments[0].toString();
			}
			else {
				this.text+="\n"+arguments[0];
			}
		}
	}
}

function Equipment()
{
	var req = new Object();
	var i=0;
	req.id="000001";
	req.type="sword";
	req.limit={ };
	req.damage=1;
	req.effect={ };
	req.descrption="normal sword";
	req.value=100;
	if (arguments[0]&&eqs[arguments[0]])
	{
		req=eqs[arguments[0]];
	}
	for (var s in req)
	{
		if (i<arguments.length&&arguments[i])
		{
			req[s]=arguments[i];
			i++;
		}
	}
    return req;
}

function OpenDG(map)
{
	if (intv) {
		clearInterval(intv);
		intv=null;
	}
	document.getElementById("upstairs").setAttribute("disabled","true");
	document.getElementById("downstairs").setAttribute("disabled","true");
	map.width=dg[map.id].width;
	map.height=dg[map.id].height;
	map.align=dg[map.id].align;
	map.data=dg[map.id].data;
	map.cells=createCells(Number(map.width),Number(map.height));
	makestair(map.data.tile.upstair,map.data.tile.downstair);
	if (map.align=="up") {
		map.loc.x=map.data.tile.downstair.x;
		map.loc.y=map.data.tile.downstair.y;
	}
	else if (map.align=="down") {
		map.loc.x=map.data.tile.upstair.x;
		map.loc.y=map.data.tile.upstair.y;
	}
	else {
		map.loc.x=Math.floor(Math.random()*map.width);
		map.loc.y=Math.floor(Math.random()*map.height);
	}
	viewmap();
	for (var s in map.cells[map.loc.x][map.loc.y].around)
	{
		if (map.cells[map.loc.x][map.loc.y].connected[s]) {
			document.getElementById(""+(map.loc.x-(s=="left")+(s=="right")+""+(map.loc.y-(s=="down")+(s=="up")))).setAttribute("onclick","go_to('"+s+"');");
		}
	}
}

/*
7 �� �� �� �� �� �� �� �� �� ��
6 �� �� �� �� �� �� �� �� �� ��
5 �� �� �� �� �� �� �� �� �� ��
4 �� �� �� �� �� �� �� �� �� ��
3 �� �� �� �� �� �� �� �� �� ��
2 �� �� �� �� �� �� �� �� �� ��
1 �� �� �� �� �� �� �� �� �� ��
0 �� �� �� �� �� �� �� �� �� ��
ij0 1 2 3 4 5 6 7 8 9
*/

function viewmap()
{
	var a=document.getElementById("maptable");
	a.removeChild(a.firstChild);
	var b=document.createElement("tbody");
	b.appendChild(document.createTextNode(" "));
	for (var i=0;i<map.height;i++)
	{
		var c=document.createElement("tr");
		c.setAttribute("style","height:30px");
		for (var j=0;j<map.width;j++)
		{
			var d=document.createElement("td");
			d.setAttribute("style","text-align:center; width:30px; border-collapse:collapse; border-spacing:0px; border-top:"+Number(!(map.cells[j][i].connected.up))+"px solid black;"+"border-bottom:"+Number(!(map.cells[j][i].connected.down))+"px solid black;"+"border-left:"+Number(!(map.cells[j][i].connected.left))+"px solid black;"+"border-right:"+Number(!(map.cells[j][i].connected.right))+"px solid black;");
			d.id=""+j+""+i;
			c.appendChild(d);
		}
		b.insertBefore(c,b.firstChild);
	}
	b.removeChild(b.lastChild);
	a.appendChild(b);
	document.body.appendChild(a);
	for (var i=0;i<map.height;i++)
	{
		for (var j=0;j<map.width;j++)
		{
			mapstat(j,i);
		}
	}
}

function createCells(width,height)
{
	var a=new Array(width);
	for (var i=0;i<width;i++)
	{
		a[i]=new Array(height);
		for (var j=0;j<height;j++)
		{
			a[i][j]=acell();
		}
	}
	for (i=0;i<width;i++)
	{
		for (var j=0;j<height;j++)
		{
			if (j!=height-1)
			{
				a[i][j].around.up=a[i][j+1];
			}
			if (j!=0)
			{
				a[i][j].around.down=a[i][j-1];
			}
			if (i!=0)
			{
				a[i][j].around.left=a[i-1][j];
			}
			if (i!=width-1)
			{
				a[i][j].around.right=a[i+1][j];
			}
			a[i][j].loc.x=i;
			a[i][j].loc.y=j;
		}
	}
	var b=a[Math.floor(Math.random()*width)][Math.floor(Math.random()*height)];
	var c=new Array();
	var d=new Array();
	for (var s in b.around)
	{
		if (b.around[s].connected.up==false&&b.around[s].connected.down==false&&b.around[s].connected.left==false&&b.around[s].connected.right==false)
		{
			c.push(b.around[s]);
			d.push(s);
		}
	}
	i=width*height-1;
	while (i--)
	{
		var j=Math.floor(Math.random()*c.length);
		c[j].around[inv(d[j])].connected[d[j]]=true;
		c[j].connected[inv(d[j])]=true;
		for (s in c[j].around)
		{
			if (c[j].around[s].connected.up==false&&c[j].around[s].connected.down==false&&c[j].around[s].connected.left==false&&c[j].around[s].connected.right==false)
			{
				c.push(c[j].around[s]);
				d.push(s);
			}
		}
		var k=a[Number(c[j].loc.x)][Number(c[j].loc.y)];
		j=c.length;
		while (j--)
		{
			if (c[j]==k)
			{
				c.splice(j,1);
				d.splice(j,1);
			}
		}
	}
	return a;
}

function inv(s)
{
	if (s=="up")
	{
		s="down";
	}
	else if (s=="down")
	{
		s="up";
	}
	else if (s=="left")
	{
		s="right";
	}
	else if (s=="right")
	{
		s="left";
	}
	return s;
}

function acell()
{
	var cell={
		around:{},
		connected:{up:false,down:false,left:false,right:false},
		status:{},
		loc:{x:-1,y:-1}
	}
	return cell;
}

function go_to(s)
{
	if (dg[s]) {
		map.id=s;
		OpenDG(map);
	}
	else if (world[s]) {
		
	}
	else if (s=="upper"&&map.loc.x!=-1) {
		document.getElementById("upstairs").setAttribute("disabled","true");
		document.getElementById("downstairs").setAttribute("disabled","true");
		if (map.floor+1>=map.data.max&&map.align=="up") {
			if (!confirm("next floor is dungeon boss room\nhave you go forward?")) {
				return undefined;
			}
		}
		if (intv) {
			clearInterval(intv);
			intv=null;
		}
		map.floor++;
		store.x=map.data.tile.upstair.x;
		store.y=map.data.tile.upstair.y;
		map.cells=createCells(Number(map.width),Number(map.height));
		makestair(map.data.tile.upstair,null);
		viewmap();
		for (var s in map.cells[map.loc.x][map.loc.y].around)
		{
			if (map.cells[map.loc.x][map.loc.y].connected[s]) {
				document.getElementById(""+(map.loc.x-(s=="left")+(s=="right")+""+(map.loc.y-(s=="down")+(s=="up")))).setAttribute("onclick","go_to('"+s+"');");
			}
		}
	}
	else if (s=="lower"&&map.loc.x!=-1) {
		document.getElementById("upstairs").setAttribute("disabled","true");
		document.getElementById("downstairs").setAttribute("disabled","true");
		if (map.floor-1<=map.data.min&&map.align=="down") {
			if (!confirm("next floor is dungeon boss room\nhave you go forward?")) {
				return undefined;
			}
		}
		if (intv) {
			clearInterval(intv);
			intv=null;
		}
		map.floor--;
		store.x=map.data.tile.downstair.x;
		store.y=map.data.tile.downstair.y;
		map.cells=createCells(Number(map.width),Number(map.height));
		makestair(null,map.data.tile.downstair);
		viewmap();
		for (var s in map.cells[map.loc.x][map.loc.y].around)
			{
			if (map.cells[map.loc.x][map.loc.y].connected[s]) {
				document.getElementById(""+(map.loc.x-(s=="left")+(s=="right")+""+(map.loc.y-(s=="down")+(s=="up")))).setAttribute("onclick","go_to('"+s+"');");
			}
		}
	
	}
	else if (map.loc.x!=-1) {
		if (map.cells[map.loc.x][map.loc.y].connected[s]) {
			document.getElementById("upstairs").setAttribute("disabled","true");
			document.getElementById("downstairs").setAttribute("disabled","true");
			for (var t in map.cells[map.loc.x][map.loc.y].around) {
				console.log(""+(map.loc.x-(t.indexOf("left")!=-1)+(t.indexOf("right")!=-1))+""+(map.loc.y-(t.indexOf("down")!=-1)+(t.indexOf("up")!=-1)));
				document.getElementById(""+(map.loc.x-(t.indexOf("left")!=-1)+(t.indexOf("right")!=-1))+""+(map.loc.y-(t.indexOf("down")!=-1)+(t.indexOf("up")!=-1))).removeAttribute("onclick");
			}
			if (intv) {
				clearInterval(intv);
				intv=null;
			}
			var a=map.cells[map.loc.x][map.loc.y].around[s].loc.x;
			map.loc.y=map.cells[map.loc.x][map.loc.y].around[s].loc.y;
			map.loc.x=a;
			viewmap();
			for (var s in map.cells[map.loc.x][map.loc.y].around)
			{
				if (map.cells[map.loc.x][map.loc.y].connected[s]) {
					console.log(""+(map.loc.x-(s=="left")+(s=="right")+""+(map.loc.y-(s=="down")+(s=="up"))));
					document.getElementById(""+(map.loc.x-(s=="left")+(s=="right")+""+(map.loc.y-(s=="down")+(s=="up")))).setAttribute("onclick","go_to('"+s+"');");
				}
			}
		}
	}
	else {
		alert("error! check destination")
	}
}

function mapstat(x,y) {
	if (x==map.loc.x&&y==map.loc.y) {
		setback(document.getElementById(""+x+""+y),"pl");
		for (var s in map.cells[map.loc.x][map.loc.y].status) {
			intv=setInterval("blink("+map.loc.x+","+map.loc.y+");",500);
			if (s=="us") {
				document.getElementById("upstairs").setAttribute("disabled","false");
			}
			else if (s=="ds") {
				document.getElementById("downstairs").setAttribute("disabled","false");
			}
			break;
		}
	}
	else if (map.cells[x][y].status.us) {
		console.log(x);
		console.log(y);
		setback(document.getElementById(""+x+""+y),"us");
	}
	else if (map.cells[x][y].status.ds) {
		setback(document.getElementById(""+x+""+y),"ds");
	}
}

function blink(x,y) {
	document.getElementById(""+x+""+y).removeChild(document.getElementById(""+x+""+y).firstChild);
	if (bls) {
		setback(document.getElementById(""+x+""+y),"pl");
		bls=!bls;
	}
	else {
		for (var s in map.cells[x][y].status) {
			var a=s;
			break;
		}
		setback(document.getElementById(""+x+""+y),a);
		bls=!bls;
	}
}

function setback(a,b) {
	if (typeof back[b]!="undefined") {
		if (typeof back[b].image!="undefined") {
			var img=document.createElement("img");
			img.setAttribute("style","width:100%; height:100%;");
			img.setAttribute("src",back[b].image);
			a.appendChild(img);
		}
		else {
			console.log(back[b].text);
			a.appendChild(document.createTextNode(back[b].text));
		}
	}
}

function makestair(up,down) {
	console.log(up);
	console.log(down);
	if (up) {
		if (map.data.tile.downstair.x!=-1) {
			map.data.tile.upstair.x=Math.floor(Math.random()*map.width);
			map.data.tile.upstair.y=Math.floor(Math.random()*map.height);
			map.cells[map.data.tile.upstair.x][map.data.tile.upstair.y].status.us=true;
		}
		else {
			map.data.tile.upstair.x=Math.floor(Math.random()*map.width);
			if (map.data.tile.upstair.x==map.data.tile.downstair.x) {
				map.data.tile.upstair=(map.data.tile.downstair.y+1+Math.floor(Math.random()*(map.height-1)))%map.height;
			}
			else {
				map.data.tile.upstair.y=Math.floor(Math.random()*map.height);
			}
			map.cells[map.data.tile.upstair.x][map.data.tile.upstair.y].status.us=true;
		}
	}
	else {
		if (map.data.tile.upstair) {
			map.data.tile.upstair.x=store.x;
			map.data.tile.upstair.y=store.y;
			map.cells[map.data.tile.upstair.x][map.data.tile.upstair.y].status.us=true;
		}
		else {
			console.log(up);
		}
	}
	if (down) {
		if (map.data.tile.upstair.x!=-1) {
			map.data.tile.downstair.x=Math.floor(Math.random()*map.width);
			map.data.tile.downstair.y=Math.floor(Math.random()*map.height);
			map.cells[map.data.tile.downstair.x][map.data.tile.downstair.y].status.ds=true;
		}
		else {
			map.data.tile.downstair.x=Math.floor(Math.random()*map.width);
			if (map.data.tile.downstair.x==map.data.tile.upstair.x) {
				map.data.tile.downstair=(map.data.tile.upstair.y+1+Math.floor(Math.random()*(map.height-1)))%map.height;
			}
			else {
				map.data.tile.downstair.y=Math.floor(Math.random()*map.height);
			}
			map.cells[map.data.tile.downstair.x][map.data.tile.downstair.y].status.ds=true;
		}
	}
	else {
		if (map.data.tile.downstair) {
			map.data.tile.downstair.x=store.x;
			map.data.tile.downstair.y=store.y;
			map.cells[map.data.tile.downstair.x][map.data.tile.downstair.y].status.ds=true;
		}
		else {
			console.log(down);
		}
	}
} 

// } object tab
var map = {
	width:0,
	height:0,
	floor:0,
	id:"none",
	cells:[],
	align:"none",
	data:{},
	loc:{x:-1,y:-1}
};

var dg = {
	none: {
		width:9,
		height:9,
		align:"up",
		data: {
			max:3,
			min:0,
			type:[1,2,3],
			tile:{upstair:{x:-1,y:-1},downstair:{x:-1,y:-1},monster:[{x:-1,y:-1}]}
		}
	}
};

var eqs = {
	"000001": {
		id:"000001",
		type:"sword",
		limit: {},
		damage:1,
		effect: {},
		description: "normal sword",
		value:100
	}
};

var world = {
	home: {
		dg: {
			none:true
		}
	}
};

var back = {
	pl: {
		text:"@"
	},
	us: {
		text:"u"
	},
	ds: {
		text:"d"
	}
};

var store = {
	x:-1,
	y:-1
}

// global variable tab

var bls=true;