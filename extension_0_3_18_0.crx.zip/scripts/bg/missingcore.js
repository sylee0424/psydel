if (navigator.vendor.indexOf("Opera") != -1) {
	document.getElementById("singlefile-core-link").href = "https://addons.opera.com/fr/extensions/details/singlefile-core";
}
