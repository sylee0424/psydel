﻿window.Action_Bar_Function = {

	Action_Bar_Function_1: {
		f: function() {
			history.back();
		},
		u: function() {
			console.log("u");
		},
		d: function() {
			console.log("d");
		},
		l: function() {
			console.log("l");
		},
		r: function() {
			window.postMessage({
				type: "moveto",
				dir: "left",
				des: "back"
			}, location.href);
		},
		lt: function() {
			scroll(0, 0);
		},
		name: "Go_back"
	},

	Action_Bar_Function_2: {
		f: function() {
			history.forward();
		},
		u: function() {
			console.log("u");
		},
		d: function() {
			console.log("d");
		},
		l: function() {
			console.log("l");
		},
		r: function() {
			console.log("r");
		},
		lt: function() {
			scroll(0, document.body.scrollHeight);
		},
		name: "Go_forward"
	},

	Action_Bar_Function_3: {
		f: function() {
			document.getElementById("sidebar").classList.toggle("__hided");
		},
		u: function() {
			console.log("u");
		},
		d: function() {
			console.log("d");
		},
		l: function() {
			console.log("l");
		},
		r: function() {
			console.log("r");
		},
		lt: function() {
			console.log("lt");
		},
		name: "Toggle_Button_Tab"
	},

	Action_Bar_Function_4: {
		f: function() {
			window.postMessage({
				type: "dataurl",
				des: "back"
			}, location.href);
		},
		u: function() {
			console.log("u");
		},
		d: function() {
			console.log("d");
		},
		l: function() {
			console.log("l");
		},
		r: function() {
			console.log("r");
		},
		lt: function() {
			console.log("lt");
		},
		name: "Close_This_Tab."
	},

	Action_Bar_Function_5: {
		f: function() {
			document.getElementById("bmkmain").classList.remove("__hided");
			document.getElementById("actionbar").classList.add("__hided");
			window.postMessage({
				type: "check",
				bmk: Bookmark_Original
			}, location.href);
		},
		u: function() {
			window.postMessage({
				type: "create",
				option: {active:true},
				des: "back"
			}, location.href);
		},
		d: function() {
			console.log("d");
		},
		l: function() {
			window.postMessage({
				type: "changeto",
				dir: "right",
				des: "back"
			}, location.href);
		},
		r: function() {
			window.postMessage({
				type: "changeto",
				dir: "left",
				des: "back"
			}, location.href);
		},
		lt: function() {
			Bookmark_User_Functions.Add_Bookmark.f.call(this);
		},
		name: "Open_Bookmark"
	},

	Action_Bar_Function_6: {
		f: function() {
			var a = document.getElementById("tabbar");
			document.body.style.marginTop = (50*Number(a.classList.contains("__hided")))+"px";
			window.postMessage({
				type: "tabbartoggle",
				toggle: a.classList.contains("__hided"),
				des: "back"
			}, location.href);
			a.classList.toggle("__hided")
		},
		u: function() {
			console.log("u");
		},
		d: function() {
			console.log("d");
		},
		l: function() {
			console.log("l");
		},
		r: function() {
			console.log("r");
		},
		lt: function() {
			console.log("lt");
		},
		name: "Open_Tab_Bar"
	},

	Action_Bar_Function_7: {
		f: function() {
			location.reload(true);
		},
		u: function() {
			console.log("u");
		},
		d: function() {
			console.log("d");
		},
		l: function() {
			console.log("l");
		},
		r: function() {
			console.log("r");
		},
		lt: function() {
			console.log("lt");
		},
		name: "Reload_Tab"
	},

	Action_Bar_Function_8: {
		f: function() {
			scroll(0, 0);
		},
		u: function() {
			console.log("u");
		},
		d: function() {
			console.log("d");
		},
		l: function() {
			console.log("l");
		},
		r: function() {
			console.log("r");
		},
		lt: function() {
			console.log("lt");
		},
		name: "Go_Up"
	},

	Action_Bar_Function_9: {
		f: function() {
			scroll(0, document.body.scrollHeight);
		},
		u: function() {
			console.log("u");
		},
		d: function() {
			console.log("d");
		},
		l: function() {
			window.postMessage({
				type: "moveto",
				dir: "right",
				des: "back"
			}, location.href);
		},
		r: function() {
			console.log("r");
		},
		lt: function() {
			console.log("lt");
		},
		name: "Go_Down"
	}

};

window.Extension_User_Functions = {

	Change_Broken_Link: {
		f: function(element) {
			var i;
			if (!element) {
				element = document.body;
			}
			if (element.nodeName == "#text") {
				var urlreplace = /h?ttp(s?):\/\/([\S]*)/g;
				var nv = element.nodeValue;
				var ids = new Array();
				var at = nv.split(urlreplace);
				var ss = nv.match(urlreplace);
				var aq = new Array();
				var id = 0;
				ids[0] = at[0].length;
				aq[0] = element;
				if (ss) {
					for (var i = 0; i < ss.length; i++) {
						ids[i + 1] = ids[i] + ss[i].length + at[i + 1].length;
					}
				}
				if (element.parentNode.tagName != "SCRIPT" && ss) {
					for (i = 0; i < at.length - 1; i++) {
						if (i == 0) {
							aq[1] = aq[0].splitText(ids[0]);
							if (at.length - 1 == 1) {
								aq[1] = aq[1].splitText(ss[0].length);
								aq[1].parentNode.removeChild(aq[1].previousSibling);
							}
						} else {
							aq[i + 1] = aq[i].splitText(ids[i] - ids[i - 1]);
							aq[i] = aq[i].splitText(ss[i - 1].length);
							aq[i + 1].parentNode.removeChild(aq[i + 1].previousSibling);
						}
						var a = document.createElement("a");
						a.setAttribute("target", "_blank");
						a.setAttribute("href", ss[i].replace(urlreplace,"http$1://$2"));
						a.appendChild(document.createTextNode(ss[i]));
						aq[i + 1].parentNode.insertBefore(a, aq[i + 1]);
					}
				}
			} else {
				for (i = 0; i < element.childNodes.length; i++) {
					i = Extension_User_Functions.Change_Broken_Link.f(element.childNodes[i]);
				}
			}
			if (aq) {
				return Extension_Tool_Functions.Get_Chils_Index.f(aq[aq.length - 1]);
			} else {
				return Extension_Tool_Functions.Get_Chils_Index.f(element);
			}
		},
		name: "ttp://_Make_Link",
		image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAA" +
			"AeP4ixAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADs" +
			"IAAA7CARUoSoAAAAGaSURBVGhD7VeBqsMwCHx5///P2zIQrDVGrcoIFgbbUo" +
			"3encaM1+f5O+D5PyCHbwqdyK8x2Yw0I0kItLSSgHW7PZ+RMcYSHWlNCyn18d" +
			"RnCSNPg9SAM+isxW0K45hlTRrhph+8Tn9rAqfv3BiZG8Am+Ps0lNbw+nyvgg" +
			"WcTIm0PAhbbUITmSzAh0oHAsuQlTj9gjxWdQEBY+RAerQ+Kq48t2K3UrpC2u" +
			"vHaxcqLW8QEXZhiVTIR0r4Iq3qlikFZgUmrEYi5PHEBystCzPcu/g/3JJpp9" +
			"vNW5Y4LonsHK8Q222I27JVMlqWLong0cIy/+xGEsoKBMftB6BY9hcPRC0SXF" +
			"DUtpwRjMIOZS7RJzZ4ULWycWMkYrTgamAlLSvr6nNEKuasIo1KJuxkxwHtul" +
			"hU8Or7CO773LSLJZMRnMWn6mTnik+6V1BGKmSZIq2JJG65FVJLS8Qii4h3Vd" +
			"KaGwGqqyssnCHcWVIhLXUiEahl+jhGWp1Ipkw8vpsRD2qZNs1IJroe382IB7" +
			"VMm2YkE12P72bEg1qmzTGMvAEtK+dZydFd9QAAAABJRU5ErkJggg=="
	},

	Inject_Temporal_Script: {
		f: function() {
			eval(prompt("", ""));
		},
		name: "Inject_Temporal_Script"
	},

	Blink_Line_Fix: {
		f: function() {
			var br = document.getElementById("view_content").getElementsByTagName("div");
			for (var i = 0; i < br.length; i++) {
				br[i].style.display = "inline"
			}
		},
		name: "Blink_Line_Fix",
		image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAA" +
			"D/gAIDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADs" +
			"MAAA7DAcdvqGQAAAJ3SURBVHhe7ZZhcoMgFAY9Vw7keTyNl8lhUlBBjMSwKZ" +
			"npdNYfHWM/n49lQYeHRzOBoTlp8CEsIIGwhAUIgKhmCQsQAFHNEhYgAKKaJS" +
			"xAAEQ1S1iAAIhqlrAAARDVLGEBAiCqWcICBEBUs4QFCICoZgkLEABRzRIWIA" +
			"CimiUsQABENUtYgACIapawAAEQ1SxhAQIgqlnCAgRAVLOEBQiAqGYJCxAAUc" +
			"0SFiAAopr1RVj36TbOoP7b6DzepvvbVIdAh86pWfmR8zh0GWUjrMbYBdQOnX" +
			"8Mq8NcLyXaKLSlLnv6plnBnH29hQcNy3Ebx20Zrs8Of5Nf+fRwZ73/IhIxzL" +
			"n8tiLjxWkMjyt+r2uVFX/EBvt1XjEr9BOOYmc6DC39Z5uonVY5+acSmVmteG" +
			"ZS8j42UK54VjyNI961nn/YebjzAGudhucN/LAEsszpJA2wslCWUeVh1osfl2" +
			"G1WH39tBTv1Hme6bNZy6COM1n8OsHaVuITq1OR7YHn69UBlRfPrJqLX8Ninc" +
			"cBvNjgl342xeL5S5lXrcOx+xjn/PJFWRaPm1BZfb2xGOUTK1S8d+dNb8O8Sw" +
			"7jlL6zikGUPeGXZNrLl214n5PitfGb77q+nTfBwgS63dDhk6FbLy+XYccn/K" +
			"NSf9ysv0VaWGA+hCUsQABENUtYgACIapawAAEQ1SxhAQIgqlnCAgRAVLOEBQ" +
			"iAqGYJCxAAUc0SFiAAopolLEAARDVLWIAAiGqWsAABENUsYQECIKpZwgIEQF" +
			"SzhAUIgKhmCQsQAFHNEhYgAKKaJSxAAEQ1S1iAAIhqlrAAARDVLGEBAiCqWc" +
			"ICBEBUs4QFCICoZgFYP1gVHwXKh5cqAAAAAElFTkSuQmCC"
	},

	Return_Blink_Line: {
		f: function() {
			var br = document.getElementById("view_content").getElementsByTagName("div");
			for (var i = 0; i < br.length; i++) {
				br[i].style.display = "block"
			}
		},
		name: "Return_Blink_Line",
		image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAA" +
			"D/gAIDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADs" +
			"MAAA7DAcdvqGQAAAMjSURBVHhe7ZoxcvIwEIXlnAX+gskJ4ARMGqq0dFAmDR" +
			"0lHY0p83dpU9EEnyA5QYYi5i7OSrKN7WQGv5BZi+SpYDSeZ1v6/Fa2lo2yLD" +
			"Ns7QhctZNRZQkQFuADwiIsgAAgpbMICyAASOkswgIIAFI6i7AAAoCUziIsgA" +
			"AgpbMICyAASOkswgIIAFI6i7AAAoCUziIsgAAgpbMICyAASOkswgIIAFI6i7" +
			"AAAoA0KGcdNqN5AgxeWxoUrHLyyTwabQ7aLE7eL0xY44fs5a53cvDagm5giX" +
			"OO8SbBF7k2Wu/z6ft4lN/CX2W3duZvhyWTlbadZA9jP9Vk3t8vpe5J2tL8f6" +
			"3Ov3dza56eXTSme3N7Y60mnpts7SW6WNz0nOUNJJikFaSE1fYtXuTcxot4WD" +
			"NLSUtUnpVtwkuaQ6a8sOnB6t29ZFk6WCFTzGnVWBkbnlG0GqSZ9sKmB8u5wh" +
			"F7NNMyjPoDc7/OPxeS9X0tDK3eRuJ0ZZbFcm/DeGoe1Tl5U/vlosOWlrE3i+" +
			"PhbGeHIsd8x3VN0e9wlO7WEWtK279TlcOw/cBCVBIW8FQIi7AAAoCUziIsgA" +
			"AgpbMuCVYyV97gAXCa0ktxVhBMLwRWYyt9hjvOObUbWI0UXlqm//JcsvXRRr" +
			"bMRYQeWXWa/NPeSO9m9tFWdsb2wDCWdIvfNPuuPVjTFAqr+nQJtf21HiyfXf" +
			"iUQNjNKiAKWs2DX6QdHLIqQwVkemHYMvl3/a/xR8Xh+el6kudS/YLzZ5N/Mv" +
			"fXavbPDPr1JbjB6m8n/2zExW4hqwTpMQwraUCFODtxi8CTf/JafF8E8xdi4L" +
			"DO+Sr6+XP1FvifH7v6FQkLQE5YhAUQAKR0FmEBBABpUM5i5R/w5EopK/8Aaq" +
			"z8q8Bi5V8r57DyrxUmVv61wuRFLZN/tSuy8o+Vf9/PzLHyDwjPC5IG9QUfOj" +
			"fCAp4QYREWQACQ0lmEBRAApHQWYQEEACmdRVgAAUBKZxEWQACQ0lmEBRAApH" +
			"QWYQEEACmdRVgAAUBKZxEWQACQ0lmEBRAApHQWYQEEACmdRVgAAUBKZxEWQA" +
			"CQ0lkArA9MJatAph9IyQAAAABJRU5ErkJggg=="
	},

	hitomi_Image_Downloader: {
		f: function() {
			var num1 = Number(prompt("max", "-1"));
			var num2 = Number(prompt("min", "0"));
			var galleryId = location.href.split("/")[location.href.split("/").length - 1].split(".")[0];
			if (location.href.indexOf("/reader/") != -1 || location.href.indexOf("/galleries/") != -1) {
				var i = galleryinfo.length;
				if (i > num1 && num1 != -1) {
					i = num1;
				}
				var k = 0;
				var key=document.getElementsByTagName("img")[0].src.split(".hitomi.la/")[0].split("//")[1] + ".hitomi.la/galleries/";
				if (!confirm("download?")) {
					document.getElementsByTagName("head")[0].innerHTML = "";
					document.body.innerHTML = "";
					var arr=[];
					while ((i--) - num2) {
						arr.unshift("https://" + key + galleryId + "/" + galleryinfo[i - num2].name);
					}
					Extension_Tool_Functions.hitomi_Image_Sequential.f(arr);
				} 
				else {
					while ((i--) - num2) {
						var m = "";
						if ((i + 1) / 10 < 1) {
							m = m + "0";
						}
						if ((i + 1) / 100 < 1) {
							m = m + "0";
						}
						var hrf = document.createElement("a");
						hrf.name = "hrf";
						document.body.appendChild(hrf);
						hrf = document.getElementsByName("hrf")[0];
						hrf.href = "https://" + key + galleryId + "/" + galleryinfo[i].name;
						hrf.download = "hitomi_" + galleryId + "_" + m + (i + 1) + ".jpg";
						hrf.name = "href";
						if (hrf.click) {
							hrf.click();
						} else if (document.createEvent) {
							var eventObj = document.createEvent('MouseEvents');
							eventObj.initEvent('click', true, true);
							hrf.dispatchEvent(eventObj);
						}
					}
				}
			} else {
				alert("갤러리/리더 화면이 아닙니다.");
			}
		},
		name: "hitomi_Image_Downloader",
		image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAA" +
			"AeP4ixAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JQAAgIMAAPn/AACA6Q" +
			"AAdTAAAOpgAAA6mAAAF2+SX8VGAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAW" +
			"JLR0QecgogKwAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxNC0xMC0xOVQyMTozMD" +
			"ozNyswMjowMF1ZuNsAAAAldEVYdGRhdGU6bW9kaWZ5ADIwMTQtMTAtMTlUMj" +
			"E6MzA6MzcrMDI6MDAsBABnAAADX0lEQVRoQ+2YP0wTURzHv/enNoW2VG1LAE" +
			"shUQJEB1mcUBcHB00kDsawuOjsREyIiTEYMcRBBgcd1MRJIzFao4MmriYiYS" +
			"CKgRjRQBRBoBRo766+d6XlrELL3e8lhNxbmt67e+/3+X1/v9/73UlZNrANhk" +
			"QB0tp2pOAK3TAA5htJkiDLcuG6YWRhGLr5X5JkKMra3MjgW8euJAXxeDyIx+" +
			"qgst90Oo2vE9+haRrjyqK2tgYtzfvANsTk1A+MfBwtGE8BsuYWhz4xmBLRSB" +
			"g3e6/gwd1buNHTjZ2hKhOCz7UfaEbvxQvo77uKzrOnwXQDZUyTgXA/yLKEQM" +
			"APf2UFAn4/JPbfYCBNu4JoT8/i2/07mB8axO6shoPhIHwsvKhgSEFyov5r2q" +
			"HqEOp8O6Alk5h8lUBk+B262vbiWCxCJosAkFUcpoSu6SxHdEwll7DCcoVlOb" +
			"T5OejJBfhUBQ3BCjDRSIYwEL+/EqdOHkfnmQ7EDx+FFms0K1legrkVDUPT89" +
			"CJqj9Z1eIJHa/fYyZ6dZSFTNHIzP3GxMN7YBJhXJdxO/EGo7NJE2RLVa1S8e" +
			"GpCqHmRAcazp1Hqmk/RmYWyNQwC00pA+zOz8zM4npfPy5dvoau7h48efoCvl" +
			"g95ECQpwrLDaLkWDVQGEhyMYXEy9d4PPAcjwae4f2HYbs+Kes5YSA8sRVWmV" +
			"RVhaqof7UrZVm2yZsEgNCGTLk8pCC8HeE9Fu+vlpdXzObRHIyNVzU+p+u5s4" +
			"V6kJVfbpjX60VrSxM8LJxSqSV8+jyGTCZj9lvV0TAaG+LmWfJz+hfGxr8UWC" +
			"jKLykI97/BPM6F4EVJUZSCsRxG13mrmOvJrC3+lgGhDhM765EoUrxxrhVZf4" +
			"h4KRUGsp6xHFIECGnVshMSVM8IU8QNLZsSuaG1kePcqmUzrMwuiOIDnXuOOF" +
			"Cg+NFtk+wuCGFUkCzlKkLiRsJFXEUInUmylHsgkriRcJFtkyOOQ6tUp1uu05" +
			"2+/pKAODaC4D2eNLS4OhspZJ2jUjKvOBlI/usIVydvJLWxG4UpGYh1k3yoWU" +
			"PO+hlIxCchISDlJjjlfUJAikNLtBrcIWQg+dywGu20mm1GMTIQvik3/H/GW6" +
			"+JgiM5RzbjufXudQroGIQCgmIN0tCiMMjuGn8A/O2d15PLg+EAAAAASUVORK" +
			"5CYII="
	},

	Force_Drag_Enable: {
		f: function(element) {
			if (!element) {
				element = document.documentElement;
			}
			if (element.attributes) {
				if (element.id != "img") {
					element.removeAttribute("ondragstart");
				}
				element.removeAttribute("onselectstart");
				element.removeAttribute("oncontextmenu");
			}
			for (i = 0; i < element.childNodes.length; i++) {
				i = Extension_User_Functions.fde.f(element.childNodes[i]);
			}
			return Extension_Tool_Functions.Get_Chils_Index.f(element);
		},
		name: "Force_Drag_Enable"
	}

};

window.Extension_Tool_Functions = {

	hitomi_Image_Sequential: {
		f: function (imagelist) {
			var __scr=document.createElement("img");
			document.body.appendChild(__scr);
			__scr.addEventListener("load",function () {
				if (imagelist.length) {
					Extension_Tool_Functions.hitomi_Image_Sequential.f(imagelist);
				}
			});
			__scr.addEventListener("error",function () {
				console.log(""+this.src);
				this.src+="#"+new Date().getTime();
			});
			__scr.setAttribute("src",imagelist.shift());
		},
		name:"hitomi_Image_Sequential"
	},

	Tab_Change: {
		f: function() {
			window.postMessage({
				type: "changeto",
				id: Number(this.dataset.id),
				des: "back"
			}, location.href);
		},
		name: "Fake_Scroll_Event"
	},

	Tab_Remove: {
		f: function() {
			window.postMessage({
				type: "closeto",
				id: Number(this.dataset.id),
				index: Number(this.dataset.index),
				des: "back"
			}, location.href);
		},
		name: "Fake_Scroll_Event"
	},

	Fake_Scroll_Event: {
		f: function(event) {
			if (event.altKey) {
				event.preventDefault();
				if (event.which == 3) {
					window.scrolldirection = "u";
				} else if (event.which == 1) {
					window.scrolldirection = "d";
				}
			}
		},
		name: "Fake_Scroll_Event"
	},

	Fake_Scroll_Event_End: {
		f: function(event) {
			delete window.scrolldirection;
		},
		name: "Fake_Scroll_Event_End"
	},

	Emulate_Click_Event: {
		f: function(hrf) {
			if (hrf.click) {
				hrf.click();
			} else if (document.createEvent) {
				var eventObj = document.createEvent('MouseEvents');
				eventObj.initEvent('click', true, true);
				hrf.dispatchEvent(eventObj);
			}
		},
		name: "Emulate_Click_Event"
	},

	Get_Chils_Index: {
		f: function(node) {
			return Array.prototype.indexOf.call(node.parentNode.childNodes, node);
		},
		name: "Get_Child_Number"
	},

	hitomi_Link_Action: {
		f: function() {
			event.stopPropagation();
			var i = this.dataset.index;
			var j = this.dataset.type;
			var k = this.dataset.url;
			var url;
			if (location.protocol == "file:") {
				url = "";
			} else {
				url = "https://hitomi.la";
			}
			if (j == "normal") {
				url += k;
			} else if (j == "korean") {
				url += k.split("-all-")[0] + "-korean-" + k.split("-all-")[1];
			} else if (j == "reader") {
				url += k.split("galleries")[0] + "reader" + k.split("galleries")[1] + "#1";
			}
			if (document.getElementById("input-" + i).checked) {
				window.open(url)
			} else if (location.protocol == "file:") {
				location.hash = url;
			} else {
				location.href = url;
			}
		},
		name: "hitomi_Click_Action"
	},

	Element_Toggle: {
		f: function(event) {
			event.stopPropagation();
			this.classList.toggle("__checked");
			this.checked = this.classList.contains("__checked");
		},
		name: "Element_Toggle"
	},

	utf8_decode: {
		f: function(utftext) {
			var string = "";
			var i = 0;
			var c = c1 = c2 = 0;
			while (i < utftext.length) {
				c = utftext.charCodeAt(i);
				if (c < 128) {
					string += String.fromCharCode(c);
					i++;
				} else if ((c > 191) && (c < 224)) {
					c2 = utftext.charCodeAt(i + 1);
					string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
					i += 2;
				} else {
					c2 = utftext.charCodeAt(i + 1);
					c3 = utftext.charCodeAt(i + 2);
					string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
					i += 3;
				}
			}
			return string;
		},

		name: "utf8_decode"
	},

	Drag_Event_Checker: {
		f: function(event) {
			if (event.touches && event.touches.length > 1) {
				return undefined;
			}
			if (event.which && event.which == 3) {
				return undefined;
			}
			event.preventDefault();
			var eventx = event.clientX || event.changedTouches[0].clientX;
			var eventy = event.clientY || event.changedTouches[0].clientY;
			var nds = document.createElement("div");
			nds.setAttribute("style",
				"visibility:visible; position:fixed; bottom:0%; left:0%; width:100%; height:100%; background-color:#000000; opacity:0;"
			);
			nds.id = "setover";
			nds.setAttribute("data-x", eventx);
			nds.setAttribute("data-y", eventy);
			nds.setAttribute("data-id", this.id);
			document.body.appendChild(nds);
			nds.addEventListener("mouseup", Extension_Tool_Functions.Drag_Event_Checker_Action.f);
			window.setTimeout(Extension_Tool_Functions.Longtab_Event_Checker.f, 350);
		},
		name: "Drag_Event_Checker"
	},

	Remove_Longtab_Event_Checker: {
		f: function() {
			if (document.getElementById("setover")) {
				document.getElementById("setover").parentNode.removeChild(document.getElementById("setover"));
			}
		},
		name: "Drag_Event_Checker"
	},

	Longtab_Event_Checker: {
		f: function() {
			if (document.getElementById("setover")) {
				var a = document.createElement("div");
				a.style = document.getElementById(document.getElementById("setover").dataset.id).getAttribute(
					"style");
				a.setAttribute("data-id", document.getElementById("setover").dataset.id);
				a.id = "ltsde";
				a.appendChild(document.createTextNode("lt"));
				document.body.appendChild(a);
				a.addEventListener("mouseup", Extension_Tool_Functions.Drag_Event_Checker_Action.f);
			}
		},
		name: "Drag_Event_Checker"
	},

	Drag_Event_Checker_Action: {
		f: function(event) {
			var a = 15;
			var aaa = this;
			if (event.changedTouches || this.id == "ltsde") {
				aaa = document.getElementById("setover");
			}
			var eventx = event.clientX || event.changedTouches[0].clientX;
			var eventy = event.clientY || event.changedTouches[0].clientY;
			var movex = eventx - Number(aaa.dataset.x);
			var movey = Number(aaa.dataset.y) - eventy;
			if (Math.abs(movex) < a && Math.abs(movey) < a) {
				if (document.getElementById("ltsde")) {
					Action_Bar_Function[aaa.dataset.id].lt.call(document.getElementById(aaa.dataset.id));
					document.getElementById("ltsde").parentNode.removeChild(document.getElementById("ltsde"));
				} else {
					Action_Bar_Function[aaa.dataset.id].f();
				}
			} else if (movex >= 0 && movey >= 0) {
				if (movey / movex > 3) {
					if (Action_Bar_Function[aaa.dataset.id].u) {
						Action_Bar_Function[aaa.dataset.id].u();
					}
				} else if (movey / movex < 0.3) {
					if (Action_Bar_Function[aaa.dataset.id].r) {
						Action_Bar_Function[aaa.dataset.id].r();
					}
				}
			} else if (movex < 0 && movey >= 0) {
				if (movey / movex < -3) {
					if (Action_Bar_Function[aaa.dataset.id].u) {
						Action_Bar_Function[aaa.dataset.id].u();
					}
				} else if (movey / movex > -0.3) {
					if (Action_Bar_Function[aaa.dataset.id].l) {
						Action_Bar_Function[aaa.dataset.id].l();
					}
				}
			} else if (movex >= 0 && movey < 0) {
				if (movey / movex < -3) {
					if (Action_Bar_Function[aaa.dataset.id].d) {
						Action_Bar_Function[aaa.dataset.id].d();
					}
				} else if (movey / movex > -0.3) {
					if (Action_Bar_Function[aaa.dataset.id].r) {
						Action_Bar_Function[aaa.dataset.id].r();
					}
				}
			} else if (movex < 0 && movey < 0) {
				if (movey / movex > 3) {
					if (Action_Bar_Function[aaa.dataset.id].d) {
						Action_Bar_Function[aaa.dataset.id].d();
					}
				} else if (movey / movex < 0.3) {
					if (Action_Bar_Function[aaa.dataset.id].l) {
						Action_Bar_Function[aaa.dataset.id].l();
					}
				}
			}
			aaa.parentNode.removeChild(aaa);
		},
		name: "Drag_Event_Checker"
	},

	Add_Extension_Interface: {
		f: function() {
			var addlist = [{
					tag: "input",
					id: "getbmk",
					classname: ["__hided"],
					events: [{
						name: "change",
						value: Bookmark_User_Functions.Get_External_Bookmark.f
					}],
					attributes: [{
							name: "accept",
							value: ".json"
						},
						{
							name: "type",
							value: "file"
						}
					]
				},
				{
					tag: "div",
					name: "edit bmks",
					classname: ["__buttons"],
					id: "b1",
					events: [{
						name: "click",
						value: Bookmark_User_Functions.Activate_Bookmark_Edit.f
					}]
				},
				{
					tag: "div",
					name: "add bmk",
					classname: ["__buttons"],
					id: "b2",
					events: [{
						name: "click",
						value: Bookmark_User_Functions.Add_Bookmark.f
					}]
				},
				{
					tag: "div",
					name: "sort bmk",
					classname: ["__buttons"],
					id: "c7",
					events: [{
						name: "click",
						value: Bookmark_User_Functions.Sort_Bookmark.f
					}]
				},
				{
					tag: "div",
					name: "new folder",
					classname: ["__buttons"],
					id: "c4",
					events: [{
						name: "click",
						value: Bookmark_User_Functions.Create_Bookmark_Folder.f
					}]
				},
				{
					tag: "div",
					name: "go up",
					classname: ["__buttons","__disabled"],
					id: "c5",
					events: [{
						name: "click",
						value: Bookmark_User_Functions.Go_To_Upper_Bookmark_Folder.f
					}]
				},
				{
					tag: "div",
					name: "paste bmk",
					classname: ["__buttons"],
					id: "c6",
					classname: ["__hided"],
					events: [{
						name: "click",
						value: Bookmark_User_Functions.Paste_Bookmark.f
					}]
				},
				{
					tag: "div",
					name: "close bmks",
					classname: ["__buttons"],
					id: "b3",
					events: [{
						name: "click",
						value: Bookmark_User_Functions.Hide_Bookmark.f
					}]
				},
				{
					tag: "br"
				},
				{
					tag: "label",
					name: "this tab",
					childs: [{
						tag: "input",
						id: "tab",
						events: [{
							name: "click",
							value: Extension_Tool_Functions.Element_Toggle.f
						}],
						attributes: [{
							name: "type",
							"value": "checkbox"
						}]
					}]
				},
				{
					tag: "div",
					name: "import",
					classname: ["__buttons"],
					id: "c9",
					events: [{
						name: "click",
						value: Bookmark_User_Functions.Import_Bookmark.f
					}]
				},
				{
					tag: "div",
					name: "export",
					classname: ["__buttons"],
					id: "c8",
					events: [{
						name: "click",
						value: Bookmark_User_Functions.Export_Bookmark.f
					}]
				},
				{
					tag: "div",
					name: "root",
					id: "dir",
					attributes: [{
						name: "data-loc",
						value: "root"
					}]
				},
				{
					tag: "div",
					name: "remove",
					id: "c1",
					events: [{
						name: "click",
						value: Bookmark_User_Functions.Remove_Bookmark.f
					}],
					classname: ["__invisibled","__buttons"]
				},
				{
					tag: "div",
					name: "move",
					id: "c2",
					events: [{
						name: "click",
						value: Bookmark_User_Functions.Move_Bookmarks.f
					}],
					classname: ["__invisibled","__buttons"]
				},
				{
					tag: "div",
					name: "end",
					id: "c3",
					events: [{
						name: "click",
						value: Bookmark_User_Functions.Deactivate_Bookmark_Edit.f
					}],
					classname: ["__invisibled","__buttons"]
				},
				{
					tag: "div",
					name: "loading...",
					id: "bmks"
				},
			];
			if (!document.getElementById("bmkmain")) {
				Extension_Tool_Functions.Import_Nodes.f({
					tag: "div",
					id: "bmkmain",
					classname: ["__hided"],
					target: document.body
				});
				for (var i = 0; i < addlist.length; i++) {
					Extension_Tool_Functions.Import_Nodes.f(addlist[i])
				}
			}
			if (!document.getElementById("tabbar")) {
				Extension_Tool_Functions.Import_Nodes.f({
					tag: "div",
					id: "tabbar",
					classname: ["__hided"],
					target: document.body
				});
			}
			if (!document.getElementById("actionbar")) {
				Extension_Tool_Functions.Import_Nodes.f({
					tag: "div",
					id: "actionbar",
					classname: [],
					target: document.body
				});
				for (s in Action_Bar_Function) {
					a = {};
					a.tag = "div";
					a.id = s;
					a.classname = ["__abtn"];
					a.name = Action_Bar_Function[s].name;
					a.events = [{
						name: "mousedown",
						value: Extension_Tool_Functions.Drag_Event_Checker.f
					}, {
						name: "mouseup",
						value: Extension_Tool_Functions.Remove_Longtab_Event_Checker.f
					}, {
						name: "touchstart",
						value: Extension_Tool_Functions.Drag_Event_Checker.f
					}, {
						name: "touchend",
						value: Extension_Tool_Functions.Drag_Event_Checker_Action.f
					}, {
						name: "selectstart",
						value: function(event) {
							event.preventDefault();
						}
					}];
					a.target = document.getElementById("actionbar");
					Extension_Tool_Functions.Import_Nodes.f(a);
				}
			}
			if (!document.getElementById("sidebar")) {
				Extension_Tool_Functions.Import_Nodes.f({
					tag: "div",
					id: "sidebar",
					classname: ["__hided"],
					target: document.body
				});
				for (var s in Extension_User_Functions) {
					var a = {};
					a.tag = "div";
					a.classname = ["__btnz"];
					if (Extension_User_Functions[s].image) {
						a.image=Extension_User_Functions[s].image;
					} else if (Extension_User_Functions[s].name) {
						a.name = Extension_User_Functions[s].name;
					} else {
						a.name = s;
					}
					a.events = [{
						name: "click",
						value: Extension_User_Functions[s].f
					}];
					a.target = document.getElementById("sidebar");
					Extension_Tool_Functions.Import_Nodes.f(a);
				}
				Extension_Tool_Functions.Import_Nodes.f({
					tag: "div",
					id: "sidebarpad",
					classname: ["__extension"],
					target: document.getElementById("sidebar")
				});
			}

			window.postMessage({
				type: "gettab",
				des: "back"
			}, location.href);
		},
		name: "Drag_Event_Checker"
	},

	Import_Nodes: {
		f: function(item) {
			var div = document.createElement(item.tag);
			if (item.classname) {
				for (var i = 0; i < item.classname.length; i++) {
					div.classList.add(item.classname[i]);
				}
			}
			div.classList.toggle("__extension");
			if (item.id) {
				div.id = item.id;
			}
			if (item.image) {
				if (!item.childs) {
					item.childs=[];
				}
				var b = {}
				b.tag = "img"
				b.attributes = [{
					name: "src",
					value: item.image
				}];
				b.classname = ["__innerimage","__extension"];
				item.childs.push(b);
			} else if (item.name) {
				div.appendChild(document.createTextNode(item.name));
			}
			if (item.childs) {
				for (var i = 0; i < item.childs.length; i++) {
					item.childs[i].target = div;
					Extension_Tool_Functions.Import_Nodes.f(item.childs[i]);
				}
			}
			if (item.events) {
				for (var i = 0; i < item.events.length; i++) {
					div.addEventListener(item.events[i].name, item.events[i].value);
				}

			}
			if (item.attributes) {
				for (var i = 0; i < item.attributes.length; i++) {
					div.setAttribute(item.attributes[i].name, item.attributes[i].value);
				}
			}
			if (item.target) {
				item.target.appendChild(div);
			} else {
				document.getElementById("bmkmain").appendChild(div);
			}
		},
		name: "Drag_Event_Checker"
	},

	On_Message: {
		f: function(event) {
			if (event.data.type == "show") {
				if (typeof Bookmark_Original == "undefined") {
					window.Bookmark_Original = JSON.parse(unescape(document.getElementById("bmksdata").innerHTML));
					document.getElementById("bmksdata").parentNode.removeChild(document.getElementById(
						"bmksdata"));
				}
				Bookmark_User_Functions.Show_Bookmark.f("root");
			} else if (event.data.type == "update") {
				window.Bookmark_Original = event.data.bmk;
				Bookmark_User_Functions.Show_Bookmark.f(document.getElementById("dir").dataset.loc);
			} else if (event.data.type == "tabs") {
				if (event.data.tab.type == "toggle") {
					if (!(event.data.tab.toggle)) {
						document.getElementById("tabbar").style.display = "none";
						document.body.style.marginTop = "0px";
					} else {
						document.getElementById("tabbar").style.display = "block";
						document.body.style.marginTop = "50px";
					}
				} else {
					Extension_Tool_Functions.Set_Tab_Bar.f(event.data.tab);
				}
			}
		},
		name: "Drag_Event_Checker"
	},

	Set_Tab_Bar: {
		f: function(tabs) {
			if (!document.head.innerHTML) {
				return;
			}
			var e = document.getElementById("tabbar");
			while (e&&e.firstChild) {
				e.removeChild(e.firstChild);
			}
			for (var i = 0; i < tabs.length; i++) {
				var a = document.createElement("div");
				var b = document.createElement("img");
				var c = document.createElement("span");
				var d = document.createElement("button");
				a.style =
					"border:1px solid #000000; overflow-y:hidden; " +
					"position:relative; width:150px; height:30px; " +
					"display:inline-block;";
				b.style =
					"border:1px solid #000000; position:absolute; " +
					"top:0px; left:0px; width:20px; height:20px;";
				c.style =
					"border:1px solid #000000; background-color:#ffffff; " +
					"position:absolute; top:0px; left:22px; width:100px; " +
					"height:20px; overflow:hidden; text-overflow:ellipsis;";
				d.style =
					"border:1px solid #000000; background-color:#ce3333; " +
					"position:absolute; top:0px; right:0px; width:20px; " +
					"height:20px;";
				if (!(tabs[i].favIconUrl)) {
					b.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAIAAA" +
					"DYYG7QAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAc" +
					"dvqGQAAABDSURBVFhH7c4xAQAwDASh+jf9lcCa4VDA2zGFpJAUkkJSSApJISkkhaSQFJ" +
					"JCUkgKSSEpJIWkkBSSQlJICkkhORbaPoBi5ofwSUznAAAAAElFTkSuQmCC";
				} else {
					b.src = tabs[i].favIconUrl;
				}
				c.appendChild(document.createTextNode(tabs[i].title));
				c.setAttribute("data-id", tabs[i].id);
				d.appendChild(document.createTextNode("X"));
				d.setAttribute("data-id", tabs[i].id);
				d.setAttribute("data-index", tabs[i].index);
				a.appendChild(b);
				a.appendChild(c);
				a.appendChild(d);
				document.getElementById("tabbar").appendChild(a);
				c.addEventListener("click", Extension_Tool_Functions.Tab_Change.f);
				d.addEventListener("click", Extension_Tool_Functions.Tab_Remove.f);
			}
		},
		name: "Set_Tab_Bar"
	},

	hitomi_Ad_Block: {
		f: function() {
			var i = 0;
			var b;
			var galleryId = location.href.split("/")[location.href.split("/").length - 1].split(".")[0];
			var scripts = document.getElementsByTagName('script');
			i = scripts.length;
			while (i--) {
				scripts[i].parentNode.removeChild(scripts[i]);
			}
			scripts = document.getElementsByTagName('noscript');
			i = scripts.length;
			while (i--) {
				scripts[i].parentNode.removeChild(scripts[i]);
			}
			scripts = document.getElementsByTagName('iframe');
			i = scripts.length;
			while (i--) {
				scripts[i].parentNode.removeChild(scripts[i]);
			}
			if (location.href.indexOf("reader") != -1 || location.href.indexOf("galleries") != -1) {
				var scr = document.createElement('script');
				scr.src = 'https://hitomi.la/galleries/' + galleryId + '.js';
				document.body.appendChild(scr);
			}
			divs = document.getElementsByTagName('style');
			i = divs.length;
			while (i--) {
				divs[i].parentNode.removeChild(divs[i]);
			}
			divs = document.getElementsByTagName('div');
			i = divs.length;
			while (i--) {
				divs[i].addEventListener("mousedown", function(event) {
					event.stopImmediatePropagation();
				});
				divs[i].addEventListener("touchstart", function(event) {
					event.stopImmediatePropagation();
				});
				divs[i].addEventListener("click", function(event) {
					event.stopImmediatePropagation();
				});
			}
			document.body.setAttribute("ontouchstart", "event.stopImmediatePropagation();");
			document.body.setAttribute("onmousedown", "event.stopImmediatePropagation();");
			document.body.setAttribute("onclink", "event.stopImmediatePropagation();");
			if (document.getElementsByClassName("page-container").length != 0 && document.getElementsByClassName(
					"page-container")[0].getElementsByTagName) {
				divs = document.getElementsByClassName("page-container")[0].getElementsByTagName("li");
				i = divs.length;
				while (i--) {
					if (divs[i].innerHTML == location.href.split("-")[location.href.split("-").length - 1].split(
							".")[0]) {
						divs[i].setAttribute("style", "color:#ff00ff");
					}
				}
			}
		},
		name: "hitomi_Ad_Block"
	},

	Fake_Scroll_Action: {
		f: function() {
			if (window.scrolldirection == "u") {
				document.documentElement.scrollTop -= 60;
			} else if (window.scrolldirection == "d") {
				document.documentElement.scrollTop += 60;
			}
		},
		name: "Set_Scroll"
	},

	hitomi_Link_Change: {
		f: function() {
			var d = 0;
			var divs = document.getElementsByTagName('a');
			var i = divs.length;
			while (i--) {
				var k = divs[i].getAttribute("href");
				if (k && divs[i].id != "dl-button" && divs[i].parentNode.parentNode.getAttribute("class") !=
					"simplePagerNav") {
					divs[i].dataset.url = k;
					divs[i].dataset.type = "normal";
					divs[i].dataset.index = i;
					divs[i].addEventListener("click", Extension_Tool_Functions.hitomi_Link_Action.f);
					var inp = document.createElement("input");
					var inq = document.createElement("label");
					var tx = document.createTextNode("N");
					inp.type = "checkbox";
					inq.style.display = "inline";
					inp.id = "input-" + i;
					inp.addEventListener("click", Extension_Tool_Functions.Cancel_Event_Bubling.f);
					inp.style["vertical-align"] = "middle";
					inq.addEventListener("click", Extension_Tool_Functions.Element_Toggle.f);
					if (divs[i].parentNode.parentNode.parentNode.getAttribute("class") != "page-container" &&
						divs[i].parentNode.tagName != "DIV" && divs[i].href != "/") {
						if (k.match("galleries")) {
							var j = document.createElement("span");
							divs[i].insertBefore(j, divs[i].firstChild);
							j.innerHTML = "(R) ";
							j.dataset.url = k;
							j.dataset.type = "reader";
							j.dataset.index = i;
							j.addEventListener("click", Extension_Tool_Functions.hitomi_Link_Action.f);
						}
						if (k.match("-all-")) {
							var j = document.createElement("span");
							divs[i].insertBefore(j, divs[i].firstChild);
							j.innerHTML = "(K) ";
							j.dataset.url = k;
							j.dataset.type = "korean";
							j.dataset.index = i;
							j.addEventListener("click", Extension_Tool_Functions.hitomi_Link_Action.f);
						}
					} else {
						var j = document.createElement("span");
						while (divs[i].firstChild) {
							j.appendChild(divs[i].firstChild);
						}
						j.dataset.url = k;
						j.dataset.type = "normal";
						j.dataset.index = i;
						j.addEventListener("click", Extension_Tool_Functions.hitomi_Link_Action.f);
						divs[i].parentNode.insertBefore(j, divs[i]);
						var k = divs[i];
						divs[i] = j;
						k.parentNode.removeChild(k);
						inq.style.display = "none";
					}
					inq.appendChild(tx);
					inq.appendChild(inp);
					divs[i].insertBefore(inq, divs[i].firstChild);
					divs[i].removeAttribute("href");
				}
			}
			divs = document.getElementsByClassName("page-content")[0]
			if (divs) {
				divs = document.getElementsByClassName("page-content")[0].getElementsByTagName("label");
				i = divs.length;
				while (i--) {
					divs[i].setAttribute("style", "display:none");
				}
			}
		},
		name: "hitomi_Link_Change"
	},

	Ruliweb_Ad_Block: {
		f: function() {
			var arr = document.getElementsByTagName("div")
			for (var i = 0; i < arr.length; i++) {
				if (arr[i].className.indexOf("ad_") != -1) {
					arr[i].parentNode.removeChild(arr[i]);
				}
			}
		},
		name: "Ruliweb_Ad_Block"
	},

	Cancel_Event_Bubling: {
		f: function(event) {
			event.stopPropagation();
		},
		name: "Cancel_Event_Bubling"
	}
};

window.Bookmark_User_Functions = {

	Show_Bookmark: {
		f: function(bmkpath,edit) {
			var a = document.getElementById("bmks");
			var e = Number(a.scrollTop);
			while (a.firstChild) {
				a.removeChild(a.firstChild);
			}
			var Bookmark_Pointer = Bookmark_Original;
			bmkpath.split("/").forEach(function (val) {
				Bookmark_Pointer = Bookmark_Pointer[val];
			});
			var lists=Object.keys(Bookmark_Pointer);
			lists.forEach(function (val) {
				var c = document.createElement("input");
				var b = document.createElement("label");
				c.type="checkbox";
				c.dataset.id = val;
				c.id="chk"+val;
				c.classList.add("__hided");
				if (edit) {
					c.classList.remove("__hided");
				}
				b.appendChild(c);
				b.dataset.src = Bookmark_Pointer[val];
				b.dataset.loc = bmkpath;
				if (typeof Bookmark_Pointer[val] == "string") {
					b.classList.add("__link");
				} else if (typeof Bookmark_Pointer[val] == "object") {
					b.classList.add("__folder");
				}
				b.id = val;
				b.appendChild(document.createTextNode(val));
				document.getElementById("bmks").appendChild(b);
				document.getElementById("bmks").appendChild(document.createElement("br"));
				b.addEventListener("mousedown", Bookmark_User_Functions.Bookmark_Click_Action.f);
			});
			a.scrollTop = e;
		},

		name: "Show_Bookmark"
	},

	Add_Bookmark: {
		f: function() {
			if (!this||this.classList.contains("__disabled")) {
				return unefined;
			}
			var aa = window.document;
			var a = {
				name: "",
				path: ""
			};
			a.name = document.getElementsByTagName("title")[0].innerHTML;
			a.path = document.location.href;
			a.name = prompt("bookmark name", a.name);
			a.path = prompt("bookmark path", a.path);
			var Bookmark_Pointer = Bookmark_Original;
			aa.getElementById("dir").dataset.loc.split("/").forEach(function (val) {
				Bookmark_Pointer = Bookmark_Pointer[val];
			});
			if (!Bookmark_Pointer[a.name]) {
				if (!(a.name)) {
					return undefined;
				}
			} else if (confirm("overwrite \"" + a.name + "\" ?")) {
				aa.getElementById(a.name).parentNode.removeChild(aa.getElementById(a.name));
			} else if (!!(a.name = prompt("new name from " + a.name, ""))) {
				while (Bookmark_Pointer[a.name]) {
					if (!!(a.name = prompt("new name from " + a.name, ""))) {

					} else {
						return undefined;
					}
				}
			} else {
				return undefined;
			}
			Bookmark_Pointer[a.name] = a.path;
			Bookmark_User_Functions.Show_Bookmark.f(document.getElementById("dir").dataset.loc);
			window.postMessage({
				type: "setbmk",
				bmk: Bookmark_Original
			}, location.href);
		},

		name: "Add_Bookmark"
	},

	Bookmark_Click_Action: {
		f: function(e) {
			if (!document.getElementById("b1").classList.contains("__disabled") && e.which == 1) {
				if (this.classList.contains("__link")) {
					if (document.getElementById("tab").classList.contains("__checked")) {
						window.open(this.dataset.src, "_self");
					} else {
						window.open(this.dataset.src, "_blank");
					}
				} else if (this.classList.contains("__folder")) {
					var s = document.getElementById("dir").dataset.loc + "/" + this.id;
					document.getElementById("dir").setAttribute("data-loc", s);
					document.getElementById("dir").innerHTML = s;
					Bookmark_User_Functions.Show_Bookmark.f(s);
					if (document.getElementById("c5").classList.contains("__disabled")) {
						document.getElementById("c5").classList.remove("__disabled");
					}
				}
			} else if (e.which == 1) {
				var input=document.getElementById("chk"+this.id);
				Extension_Tool_Functions.Element_Toggle.f.call(input,e);
			} else if (e.which == 3) {
				e.preventDefault();
				if (this.getAttribute("class") == "__link") {
					var a = {};
					a.name = prompt("bookmark name", this.innerText);
					a.path = prompt("bookmark path", this.dataset.src);
					var Bookmark_Pointer = Bookmark_Original;
					document.getElementById("dir").dataset.loc.split("/").forEach(function (val) {
						Bookmark_Pointer = Bookmark_Pointer[val];
					});
					if (!Bookmark_Pointer[a.name]) {
						if (a.name) {
							return undefined;
						}
					} else if (Bookmark_Pointer[a.name] == this.dataset.src) {

					} else if (confirm("overwrite \"" + a.name + "\" ?")) {
						document.getElementById(a.name).parentNode.removeChild(document.getElementById(a.name));
					} else if (!!(a.name = prompt("new name from " + a.name, ""))) {
						while (Bookmark_Pointer[a.name]) {
							if (!!(a.name = prompt("new name from " + a.name, ""))) {

							} else {
								return undefined;
							}
						}
					} else {
						return undefined;
					}
					Bookmark_Pointer[a.name] = a.path;
					delete Bookmark_Pointer[this.innerText];
					Bookmark_User_Functions.Show_Bookmark.f(document.getElementById("dir").dataset.loc,
						document.getElementById("b1").classList.contains("__disabled"));
					window.postMessage({
						type: "setbmk",
						bmk: Bookmark_Original
					}, location.href);
				} else if (this.getAttribute("class") == "__folder") {
					var a = {};
					a.name = prompt("bookmark name", this.innerText);
					var Bookmark_Pointer = Bookmark_Original;
					document.getElementById("dir").dataset.loc.split("/").forEach(function (val) {
						Bookmark_Pointer = Bookmark_Pointer[val];
					});
					if (!Bookmark_Pointer[a.name]) {
						if (a.name) {
							return undefined;
						}
					} else if (Bookmark_Pointer[a.name] == Bookmark_Pointer[this.innerText]) {

					} else if (confirm("overwrite \"" + a.name + "\" ?")) {
						document.getElementById(a.name).parentNode.removeChild(document.getElementById(a.name));
					} else if (!!(a.name = prompt("new name from " + a.name, ""))) {
						while (Bookmark_Pointer[a.name]) {
							if (!!(a.name = prompt("new name from " + a.name, ""))) {

							} else {
								return undefined;
							}
						}
					} else {
						return undefined;
					}
					//Bookmark_User_Functions.Bookmark_Compare.f(Bookmark_Pointer[a.name], Bookmark_Pointer[this.innerText]);
					[Bookmark_Pointer[a.name], Bookmark_Pointer[this.innerText]]=[Bookmark_Pointer[this.innerText],Bookmark_Pointer[a.name]];
					if (!(a.name==this.innerText)) {
						delete Bookmark_Pointer[this.innerText];
					}
					Bookmark_User_Functions.Show_Bookmark.f(document.getElementById("dir").dataset.loc,
						document.getElementById("b1").classList.contains("__disabled"));
					window.postMessage({
						type: "setbmk",
						bmk: Bookmark_Original
					}, location.href);
				}
			} else if (e.which == 2) {
				e.preventDefault();
				if (this.getAttribute("class") == "__link") {
					var Bookmark_Pointer = Bookmark_Original;
					document.getElementById("dir").dataset.loc.split("/").forEach(function (val) {
						Bookmark_Pointer = Bookmark_Pointer[val];
					});
					delete Bookmark_Pointer[this.innerText];
					Bookmark_Pointer[document.getElementsByTagName("title")[0].innerHTML] = location.href;
					Bookmark_User_Functions.Show_Bookmark.f(document.getElementById("dir").dataset.loc,
						document.getElementById("b1").classList.contains("__disabled"));
					window.postMessage({
						type: "setbmk",
						bmk: Bookmark_Original
					}, location.href);
				}
			}
		},

		name: "Bookmark_Click_Action"
	},

	Activate_Bookmark_Edit: {
		f: function() {
			document.getElementById("b1").classList.add("__disabled");
			document.getElementById("b2").classList.add("__disabled");
			document.getElementById("c7").classList.add("__disabled");
			document.getElementById("c1").classList.remove("__invisibled");
			document.getElementById("c2").classList.remove("__invisibled");
			document.getElementById("c3").classList.remove("__invisibled");
			document.getElementById("c4").classList.add("__disabled");
			document.getElementById("c5").classList.add("__disabled");
			for (var s of document.getElementById("bmks").getElementsByTagName("input")) {
				s.classList.remove("__hided");
			}
		},

		name: "Activate_Bookmark_Edit"
	},

	Deactivate_Bookmark_Edit: {
		f: function() {
			document.getElementById("b1").classList.remove("__disabled");
			document.getElementById("b2").classList.remove("__disabled");
			document.getElementById("c1").classList.add("__invisibled");
			document.getElementById("c2").classList.add("__invisibled");
			document.getElementById("c3").classList.add("__invisibled");
			document.getElementById("c4").classList.remove("__disabled");
			document.getElementById("c7").classList.remove("__disabled");
			if (document.getElementById("dir").dataset.loc != "root") {
				document.getElementById("c5").classList.remove("__disabled");
			}
			for (var s of document.getElementById("bmks").getElementsByTagName("input")) {
				s.classList.add("__hided");
			}
		},

		name: "Deactivate_Bookmark_Edit"
	},

	Remove_Bookmark: {
		f: function() {
			var a = document.getElementById("bmks").querySelectorAll("input.__checked");
			var Bookmark_Pointer = Bookmark_Original;
			for (var t of document.getElementById("dir").dataset.loc.split("/")) {
				Bookmark_Pointer = Bookmark_Pointer[t];
			}
			a.forEach(function (val) {
				var c = document.getElementById(val.dataset.id);
				while (!c.tagName||!c.tagName.match(/^br$/i)) {
					c=c.nextSibling;
				}
				c.parentNode.removeChild(c);
				c = document.getElementById(val.dataset.id);
				delete Bookmark_Pointer[val.dataset.id];
				c.parentNode.removeChild(c);
			});
			window.postMessage({
				type: "setbmk",
				bmk: Bookmark_Original
			}, location.href);
		},

		name: "Remove_Bookmark"
	},

	Go_To_Upper_Bookmark_Folder: {
		f: function() {
			var a = document.getElementById("dir").dataset.loc.split("/");
			if (a.length == 2) {
				document.getElementById("c5").classList.add("__disabled")
			}
			var b = "";
			for (var i = 0; i < a.length - 1; i++) {
				if (i == 0) {
					b += a[i];
				} else {
					b += "/" + a[i];
				}
			}
			document.getElementById("dir").setAttribute("data-loc", b);
			document.getElementById("dir").innerHTML = b;
			Bookmark_User_Functions.Show_Bookmark.f(document.getElementById("dir").dataset.loc);
		},

		name: "Go_To_Upper_Bookmark_Folder"
	},

	Create_Bookmark_Folder: {
		f: function() {

			var Bookmark_Pointer = Bookmark_Original;
			for (var t of document.getElementById("dir").dataset.loc.split("/")) {
				Bookmark_Pointer = Bookmark_Pointer[t];
			}
			var a;
			if (!!(a = prompt("folder name", ""))) {
				while (Bookmark_Pointer[a]) {
					if (!!(a = prompt("folder name", ""))) {

					} else {
						return undefined;
					}
				}
			} else {
				return undefined;
			}
			Bookmark_Pointer[a] = {};
			Bookmark_User_Functions.Show_Bookmark.f(document.getElementById("dir").dataset.loc);
			window.postMessage({
				type: "setbmk",
				bmk: Bookmark_Original
			}, location.href);
		},

		name: "Create_Bookmark_Folder"
	},

	Move_Bookmarks: {
		f: function() {
			var a = document.getElementById("bmks").querySelectorAll("input.__checked");
			var Bookmark_Pointer = Bookmark_Original;
			document.getElementById("dir").dataset.loc.split("/").forEach(function (val) {
				Bookmark_Pointer = Bookmark_Pointer[val];
			});
			if (!(window.arr)) {
				window.arr = [];
			}
			a.forEach(function (val) {
				var c = document.getElementById(val.dataset.id);
				while (!c.tagName||!c.tagName.match(/^br$/i)) {
					c=c.nextSibling;
				}
				c.parentNode.removeChild(c);
				c = document.getElementById(val.dataset.id);
				c.parentNode.removeChild(c);
				var d = {};
				d.name = val.dataset.id;
				d.path = Bookmark_Pointer[val.dataset.id];
				d.loc = document.getElementById("dir").dataset.loc;
				arr.push(d);
			});
			document.getElementById("c6").setAttribute("style", "display:inline");
			Bookmark_User_Functions.Deactivate_Bookmark_Edit.f();
		},

		name: "Move_Bookmarks"
	},

	Bookmark_Compare: {
		f: function(target, origin) {
			var check = JSON.stringify(origin[one]) != "{}";
			for (var one in origin) {
				var newname = one;
				if (target[newname]) {
					if (!confirm(newname + " is already exist.\n overwrite it?")) {

						if (!!(newname = prompt("new bookmark/folder name", ""))) {
							while (target[newname]) {
								if (!!(newname = prompt("new bookmark name", ""))) {
									one = newname;
								} else {
									continue;
								}
							}
						} else {
							continue;
						}
					}
				}
				if (typeof origin[one] == "object") {
					if (!target[newname]) {
						target[newname] = {};
					}
					Bookmark_User_Functions.Bookmark_Compare.f(target[newname], origin[one]);
				} else {
					target[newname] = origin[one];
					delete origin[one];
				}
				if (JSON.stringify(origin[one]) == "{}" && check) {
					delete origin[one];
				}
			}
		},

		name: "Bookmark_Compare"
	},

	Paste_Bookmark: {
		f: function() {
			for (var d of arr) {
				var Bookmark_Pointer = Bookmark_Original;
				for (var t of document.getElementById("dir").dataset.loc.split("/")) {
					Bookmark_Pointer = Bookmark_Pointer[t];
				}
				var Bookmark_Pointer_Second = Bookmark_Original;
				for (var t of d.loc.split("/")) {
					Bookmark_Pointer_Second = Bookmark_Pointer_Second[t];
				}
				if (typeof Bookmark_Pointer_Second[d.name] == "object") {
					if (!Bookmark_Pointer[d.name]) {
						Bookmark_Pointer[d.name] = {};
						//Bookmark_User_Functions.Bookmark_Compare.f(Bookmark_Pointer[d.name],Bookmark_Pointer_Second[d.name]);
						[Bookmark_Pointer[d.name],Bookmark_Pointer_Second[d.name]]=[Bookmark_Pointer_Second[d.name],Bookmark_Pointer[d.name]]
						console.log(JSON.stringify(Bookmark_Original));
						if (JSON.stringify(Bookmark_Pointer_Second[d.name]) == "{}") {
							delete Bookmark_Pointer_Second[d.name];
						}
					} else {
						//Bookmark_User_Functions.Bookmark_Compare.f(Bookmark_Pointer[d.name],Bookmark_Pointer_Second[d.name]);
						[Bookmark_Pointer[d.name],Bookmark_Pointer_Second[d.name]]=[Bookmark_Pointer_Second[d.name],Bookmark_Pointer[d.name]]
						if (JSON.stringify(Bookmark_Pointer_Second[d.name]) == "{}") {
							delete Bookmark_Pointer_Second[d.name];
						}
						continue;
					}
				} else {
					if (Bookmark_Pointer[d.name]) {
						if (!confirm(d.name + " is already exist.\n overwrite it?")) {
							if (!!(d.name = prompt("new bookmark name", ""))) {
								while (Bookmark_Pointer[d.name]) {
									if (!!(d.name = prompt("new bookmark name", ""))) {

									} else {
										continue;
									}
								}
							} else {
								continue;
							}
						}
					}
					delete Bookmark_Pointer_Second[d.name];
					Bookmark_Pointer[d.name] = d.path;
				}
			}
			arr = [];
			document.getElementById("c6").setAttribute("style", "display:none");
			Bookmark_User_Functions.Show_Bookmark.f(document.getElementById("dir").dataset.loc);
			window.postMessage({
				type: "setbmk",
				bmk: Bookmark_Original
			}, location.href);
		},

		name: "Paste_Bookmark"
	},

	Export_Bookmark: {
		f: function() {

			var req = new XMLHttpRequest();
			req.open('POST', "https://psydel.000webhostapp.com/", true);
			req.onreadystatechange = function(aEvt) {
				if (req.readyState == 4 && req.status == 200) {
					alert(req.responseText);
				}
			}
			var dats = new FormData();
			dats.append("id", JSON.stringify(Bookmark_Original));
			req.send(dats);
			alert("exported");
		},

		name: "Export_Bookmark"
	},

	Sort_Bookmark: {
		f: function() {

			var Bookmark_Pointer = Bookmark_Original;
			for (var s of document.getElementById("dir").dataset.loc.split("/")) {
				Bookmark_Pointer = Bookmark_Pointer[s];
			}
			var Temporal_Bookmark = {};
			var Bookmark_Folders = [];
			var Bookmark_Links = [];
			for (var key in Bookmark_Pointer) {
				if (typeof Bookmark_Pointer[key] == "object") {
					Bookmark_Folders.push(key);
				} else {
					Bookmark_Links.push(key);
				}
			}
			if (Bookmark_Folders.length > 1) {
				Bookmark_Folders.sort();
			}
			if (Bookmark_Links.length > 1) {
				Bookmark_Links.sort();
			}
			for (key = 0; key < Bookmark_Folders.length; key++) {
				Temporal_Bookmark[Bookmark_Folders[key]] = Bookmark_Pointer[Bookmark_Folders[key]];
			}
			for (key = 0; key < Bookmark_Links.length; key++) {
				Temporal_Bookmark[Bookmark_Links[key]] = Bookmark_Pointer[Bookmark_Links[key]];
			}
			for (key in Temporal_Bookmark) {
				delete Bookmark_Pointer[key];
				Bookmark_Pointer[key] = Temporal_Bookmark[key];
			}
			Bookmark_User_Functions.Show_Bookmark.f(document.getElementById("dir").dataset.loc);
			window.postMessage({
				type: "setbmk",
				bmk: Bookmark_Original
			}, location.href);
		},

		name: "Sort_Bookmark"
	},

	Hide_Bookmark: {
		f: function() {
			document.getElementById("bmkmain").classList.add("__hided");
			var a = document.getElementById("actionbar")
			a.classList.remove("__hided");
		},

		name: "Hide_Bookmark"
	},

	Import_Bookmark: {
		f: function() {
			window.postMessage({
				type: "importbmk"
			}, location.href);
		},

		name: "Import_Bookmark"
	},

	Remove_Saved_Bookmark: {
		f: function() {
			window.postMessage({
				type: "removebmk"
			}, location.href);
		},

		name: "Remove_Saved_Bookmark"
	},

	Get_External_Bookmark: {
		f: function() {
			var reader = new FileReader();
			reader.addEventListener("load", function() {
				window.Bookmark_Original = Extension_Tool_Functions.utf8_decode.f(reader.result);
				window.postMessage({
					type: "setbmk",
					bmk: Bookmark_Original
				}, location.href);
				Bookmark_User_Functions.Show_Bookmark.f("root");
			}, false);
			if (this.files[0]) {
				reader.readAsBinaryString(this.files[0]);
			}
			document.getElementById("getbmk").style.display = "none";
		},

		name: "Get_External_Bookmark"
	}

}
