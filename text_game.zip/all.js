function Equipment() {
	var req = new Object();
	var i=0;
	req.type="sword";
	req.limit={ };
	req.damage=1;
	req.effect={ };
	req.descrption="normal sword";
	req.value=100;
	for (var s in req) {
		if (i<arguments.length) {
			req[s]=arguments[i];
			i++;
		}
		else {
			break;
		}
	}
    return req;
}

var map = {
	width:0,
	height:0,
	floor:0,
	id:"none",
	cells:createCells()
}