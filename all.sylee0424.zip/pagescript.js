var nds = null;

window.Button_Tab_Page = 0;

var size = {
	width: window.innerWidth || document.body.clientWidth,
	height: window.innerHeight || document.body.clientHeight
}

function resetclick() {
	if (document.getElementById("setover")) {
		document.getElementById("setover").parentNode.removeChild(document.getElementById("setover"));
	}
}

function ltcheck() {
	if (document.getElementById("setover")) {
		var a = document.createElement("div");
		a.style = document.getElementById(document.getElementById("setover").dataset.id).getAttribute("style");
		a.setAttribute("data-id", document.getElementById("setover").dataset.id);
		a.id = "ltsde";
		a.appendChild(document.createTextNode("lt"));
		document.body.appendChild(a);
		a.addEventListener("ltend", ltaction);
		a.addEventListener("mouseup", drgend);
	}
}

function ltaction() {
	Action_Bar_Function[this.dataset.id].lt();
	this.parentNode.removeChild(this);
}

function drgend(event) {
	var a = 15;
	var aaa = this;
	if (event.changedTouches||this.id=="ltsde") {
		aaa = document.getElementById("setover");
	}
	var eventx = event.clientX || event.changedTouches[0].clientX;
	var eventy = event.clientY || event.changedTouches[0].clientY;
	var movex = eventx - Number(aaa.dataset.x);
	var movey = Number(aaa.dataset.y) - eventy;
	if (Math.abs(movex)<a&&Math.abs(movey)<a){
		if (document.getElementById("ltsde")) {
			var lte = new Event('ltend');
			document.getElementById("ltsde").dispatchEvent(lte);
		} else {
			Action_Bar_Function[aaa.dataset.id].f();
		}
	} else if (movex >= 0 && movey >= 0) {
		if (movey / movex > 3) {
			if (Action_Bar_Function[aaa.dataset.id].u) {
				Action_Bar_Function[aaa.dataset.id].u();
			}
		} else if (movey / movex < 0.3) {
			if (Action_Bar_Function[aaa.dataset.id].r) {
				Action_Bar_Function[aaa.dataset.id].r();
			}
		}
	} else if (movex < 0 && movey >= 0) {
		if (movey / movex < -3) {
			if (Action_Bar_Function[aaa.dataset.id].u) {
				Action_Bar_Function[aaa.dataset.id].u();
			}
		} else if (movey / movex > -0.3) {
			if (Action_Bar_Function[aaa.dataset.id].l) {
				Action_Bar_Function[aaa.dataset.id].l();
			}
		}
	} else if (movex >= 0 && movey < 0) {
		if (movey / movex < -3) {
			if (Action_Bar_Function[aaa.dataset.id].d) {
				Action_Bar_Function[aaa.dataset.id].d();
			}
		} else if (movey / movex > -0.3) {
			if (Action_Bar_Function[aaa.dataset.id].r) {
				Action_Bar_Function[aaa.dataset.id].r();
			}
		}
	} else if (movex < 0 && movey < 0) {
		if (movey / movex > 3) {
			if (Action_Bar_Function[aaa.dataset.id].d) {
				Action_Bar_Function[aaa.dataset.id].d();
			}
		} else if (movey / movex < 0.3) {
			if (Action_Bar_Function[aaa.dataset.id].l) {
				Action_Bar_Function[aaa.dataset.id].l();
			}
		}
	}
	aaa.parentNode.removeChild(aaa);
}

if (location.href.match(/^https?\:\/\/hitomi\.la/i)) {
	Extension_User_Functions.hab.f();
	Extension_User_Functions.hlb.f();
}

if (location.href.match(/^https?\:\/\/(m|www|bbs)\.ruliweb/i)) {
	Extension_User_Functions.rab.f();
}

if (location.href.indexOf("marumaru") != -1 || location.href.indexOf("wasabisyrup") != -1) {
	Extension_User_Functions.mab.f();
}

function addinterface() {
	var addlist=[{tag:"input",id:"getbmk",classname:["__hided"],attributes:[{name:"accept",value:".json"},{name:"type",value:"file"}]},{tag:"button",name:"edit",id:"b1",classname:[]},{tag:"button",name:"add",id:"b2",classname:[]},{tag:"button",name:"sort",id:"c7",classname:[]},{tag:"button",name:"new",id:"c4",classname:[]},{tag:"button",name:"up",id:"c5",classname:["__invisibled"]},{tag:"button",name:"paste",id:"c6",classname:["__hided"]},{tag:"button",name:"close",id:"b3",classname:[]},{tag:"br"},{tag:"label",name:"this tab",classname:[],childs:[{tag:"input",id:"tab",attributes:[{name:"type","value":"checkbox"}]}]},{tag:"button",name:"import",id:"c9",classname:[]},{tag:"button",name:"export",id:"c8",classname:[]},{tag:"div",name:"root",id:"dir",classname:[],attributes:[{name:"data-loc",value:"root"}]},{tag:"button",name:"remove",id:"c1",classname:["__invisibled"]},{tag:"button",name:"move",id:"c2",classname:["__invisibled"]},{tag:"button",name:"end",id:"c3",classname:["__invisibled"]},{tag:"div",name:"loading...",id:"bmks"},];

	importnodes({tag:"div",id:"bmkmain",classname:["__hided"],target:document.body});
	importnodes({tag:"div",id:"tabbar",classname:["__hided"],target:document.body});

	for (var i=0;i<addlist.length;i++) {
		importnodes(addlist[i])
	}

	var i = 0;

	for (var s in Extension_User_Functions) {
		var a={};
		a.tag="div";
		a.classname=["Button_Tab_Page" + parseInt(i / 3),"__loc"+(i % 3),"btnz","__invisibled","__extension"];
		if (Extension_User_Functions[s].image != undefined) {
			var b = {}
			b.tag="img"
			b.attributes=[{name:"src",value: Extension_User_Functions[s].image}];
			b.classname=["__innerimage"];
			b.ne=true;
			a.childs=[b];
		} else if (Extension_User_Functions[s].name != undefined) {
			a.name=Extension_User_Functions[s].name;
		} else {
			a.name=s;
		}
		a.events=[{name:"click",value:Extension_User_Functions[s].f}];
		a.target=document.body;
		i++;
		importnodes(a);
	}

	i = 0;

	for (s in Button_Tab_Action) {
		a={};
		a.tag="div";
		a.classname=["actz","btnz","__invisibled"];
		if (i == 0) {
			a.classname.push("__prevpage");
		} else if (i == 1) {
			a.classname.push("__nextpage");
		}
		if (Button_Tab_Action[s].image != undefined) {
			b = {}
			b.tag="img"
			b.attributes=[{name:"src",value: Button_Tab_Action[s].image}];
			b.classname=["__innerimage"];
			b.ne=true;
			a.childs=[b];
		} else if (Button_Tab_Action[s].name != undefined) {
			a.name=Button_Tab_Action[s].name;
		} else {
			a.name=s;
		}
		a.events=[{name:"click",value:Button_Tab_Action[s].f}];
		a.target=document.body;
		i++;
		importnodes(a);
	}

	i = 0;
	for (s in Action_Bar_Function) {
		a={};
		a.tag="div";
		a.id=s;
		a.classname=["__abtn"];
		a.name=Action_Bar_Function[s].name;
		a.events=[{name:"mousedown", value:Extension_Tool_Functions.drgstart.f},{name:"mouseup", value:resetclick},{name:"touchstart", value:Extension_Tool_Functions.drgstart.f},{name:"touchend", value:drgend},{name:"selectstart", value:function(event) {event.preventDefault();}}];
		a.target=document.body;
		i++;
		importnodes(a);
	}

	window.postMessage({
		type: "gettab",
		des: "back"
	}, "*");
}

function importnodes(item) {
	var div= document.createElement(item.tag);
	if (item.classname) {
		for (var i=0;i<item.classname.length;i++) {
			div.classList.add(item.classname[i]);
		}
	}
	if (!(item.ne)) {
		div.classList.add("__extension");
	}
	if (item.id) {
		div.id=item.id;
	}
	if (item.name) {
		div.appendChild(document.createTextNode(item.name));
	}
	if (item.attributes) {
		for (var i=0;i<item.attributes.length;i++) {
			div.setAttribute(item.attributes[i].name,item.attributes[i].value);
		}
	}
	if (item.childs) {
		for (var i=0;i<item.childs.length;i++) {
			item.childs[i].target=div;
			importnodes(item.childs[i]);
		}
	}
	if (item.events) {
		for (var i=0;i<item.events.length;i++) {
			div.addEventListener(item.events[i].name,item.events[i].value);
		}
		
	}
	if (item.target) {
		item.target.appendChild(div);
	}
	else {
		document.getElementById("bmkmain").appendChild(div);
	}
}

setInterval(function() {
	if (window.innerWidth != lncs) {
		lncs = window.innerWidth;
		var a = document.getElementsByClassName("abtn");
		var c = window.innerWidth / document.body.offsetWidth;
		for (var b of a) {
			b.style.fontSize = c * 10 + "px";
			b.style.borderWidth = c + "px";
		}
	}
}, 100);

window.lncs = 0;

window.addEventListener("mousedown",Extension_Tool_Functions.ups.f);
window.addEventListener("mouseup",Extension_Tool_Functions.sfg.f);

setInterval(Extension_User_Functions.ael.f,40);

addinterface();

document.getElementById("b1").addEventListener("click", Bookmark_User_Functions.Activate_Bookmark_Edit.f);
document.getElementById("b2").addEventListener("click", Bookmark_User_Functions.Add_Bookmark.f);
document.getElementById("b3").addEventListener("click", Bookmark_User_Functions.Hide_Bookmark.f);
document.getElementById("c1").addEventListener("click", Bookmark_User_Functions.Remove_Bookmark.f);
document.getElementById("c2").addEventListener("click", Bookmark_User_Functions.Move_Bookmarks.f);
document.getElementById("c3").addEventListener("click", Bookmark_User_Functions.Deactivate_Bookmark_Edit.f);
document.getElementById("c5").addEventListener("click", Bookmark_User_Functions.Go_To_Upper_Bookmark_Folder.f);
document.getElementById("c4").addEventListener("click", Bookmark_User_Functions.Create_Bookmark_Folder.f);
document.getElementById("c6").addEventListener("click", Bookmark_User_Functions.Paste_Bookmark.f);
document.getElementById("c7").addEventListener("click", Bookmark_User_Functions.sortbmk.f);
document.getElementById("c8").addEventListener("click", Bookmark_User_Functions.exportbmk.f);
document.getElementById("c9").addEventListener("click", Bookmark_User_Functions.importbmk.f);
document.getElementById("tab").addEventListener("click", Bookmark_User_Functions.toggle.f);
document.getElementById("getbmk").addEventListener("change", Bookmark_User_Functions.externalbmk.f);

window.addEventListener("message",
	function(event) {
		if (event.data.type == "show") {
			if (typeof Bookmark_Original == "undefined") {
				window.Bookmark_Original = JSON.parse(unescape(document.getElementById("bmksdata").innerHTML));
				document.getElementById("bmksdata").parentNode.removeChild(document.getElementById("bmksdata"));
			}
			Bookmark_User_Functions.Show_Bookmark.f("root");
		} else if (event.data.type == "update") {
			window.Bookmark_Original = event.data.bmk;
			Bookmark_User_Functions.Show_Bookmark.f(document.getElementById("dir").dataset.loc);
		} else if (event.data.type == "tabs") {
			if (event.data.tab.type == "toggle") {
				if (!(event.data.tab.toggle)) {
					document.getElementById("tabbar").style.display = "none";
					document.body.style.marginTop = "0px";
				} else {
					document.getElementById("tabbar").style.display = "block";
					document.body.style.marginTop = "50px";
				}
			} else {
				tabbar(event.data.tab);
			}
		}
	}
);

function tabbar(tabs) {
	var e = document.getElementById("tabbar");
	while (e.firstChild) {
		e.removeChild(e.firstChild);
	}
	for (var i = 0; i < tabs.length; i++) {
		var a = document.createElement("div");
		var b = document.createElement("img");
		var c = document.createElement("span");
		var d = document.createElement("button");
		a.style = "border:1px solid #000000; overflow-y:hidden; position:relative; width:150px; height:30px; display:inline-block;";
		b.style = "border:1px solid #000000; position:absolute; top:0px; left:0px; width:20px; height:20px;";
		c.style = "border:1px solid #000000; background-color:#ffffff; position:absolute; top:0px; left:22px; width:100px; height:20px; overflow:hidden; text-overflow:ellipsis;";
		d.style = "border:1px solid #000000; background-color:#ce3333; position:absolute; top:0px; right:0px; width:20px; height:20px;";
		if (!(tabs[i].favIconUrl)) {
			b.src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAIAAADYYG7QAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABDSURBVFhH7c4xAQAwDASh+jf9lcCa4VDA2zGFpJAUkkJSSApJISkkhaSQFJJCUkgKSSEpJIWkkBSSQlJICkkhORbaPoBi5ofwSUznAAAAAElFTkSuQmCC";
		}
		else {
			b.src = tabs[i].favIconUrl;
		}
		c.appendChild(document.createTextNode(tabs[i].title));
		c.setAttribute("data-id", tabs[i].id);
		d.appendChild(document.createTextNode("X"));
		d.setAttribute("data-id", tabs[i].id);
		d.setAttribute("data-index", tabs[i].index);
		a.appendChild(b);
		a.appendChild(c);
		a.appendChild(d);
		document.getElementById("tabbar").appendChild(a);
		c.addEventListener("click", changetab);
		d.addEventListener("click", closetab);
	}
}

function changetab() {
	window.postMessage({
		type: "changeto",
		id: Number(this.dataset.id),
		des: "back"
	}, "*");
}

function closetab() {
	window.postMessage({
		type: "closeto",
		id: Number(this.dataset.id),
		index: Number(this.dataset.index),
		des: "back"
	}, "*");
}

document.onmousedown=function () {};

window.postMessage({
	type: "gettab",
	des: "back"
}, "*");

window.postMessage({
	type: "check",
	bmk: {}
}, "*");