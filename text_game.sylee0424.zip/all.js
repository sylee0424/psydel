// function tab {

function Equipment() {
	var req = new Object();
	var i=0;
	req.id="000001";
	req.type="sword";
	req.limit={ };
	req.damage=1;
	req.effect={ };
	req.descrption="normal sword";
	req.value=100;
	if (arguments[0]) {
		req=getequip(arguments[0]);
	}
	for (var s in req) {
		if (i<arguments.length&&arguments[i]) {
			req[s]=arguments[i];
			i++;
		}
	}
    return req;
}

function OpenDG (map) {
	map.width=dg[map.id].width;
	map.height=dg[map.id].height;
	map.data=dg[map.id].data;
	map.cells=createCells(map.width,map.height);
}

function getequip(id) {
	return eqs[id];
}

function createCells(width,height) {
	var a=new Array(width);
	for (var i=0;i<width;i++) {
		a[i]=new Array(height);
		for (var j=0;j<height;j++) {
			a[i][j]=acell();
		}
	}
	var b=a[Math.floor(Math.random*width)][Math.floor(Math.random*height)];
}

function acell() {
	var cell={
		around={up:false,down:false,left:false,right:false},
		status=""
	}
	return cell;
}

// } object tab
var map = {
	width:0,
	height:0,
	floor:0,
	id:"none",
	cells:{},
	data:{}
};

var dg = {
	none: {
		width:3,
		height:3,
		data: {
			max:3,
			type:[1,2,3]
		}
	}
};

var eqs = {
	"000001": {
		id:"000001",
		type:"sword",
		limit: {},
		damage:1,
		effect: {},
		description: "normal sword",
		value:100
	}
};
