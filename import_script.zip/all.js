if (!alljs&&!(parent&&parent!=this)) {
    var __scr=document.createElement("script");
    __scr.setAttribute("type","text/javascript");
    //__scr.setAttribute("src","https://rawgit.com/sylee0424/psydel/master/all.js");
    __scr.setAttribute("src",chrome.extension.getURL("all2.js"));
    document.head.appendChild(__scr);
    var alljs=1;
}