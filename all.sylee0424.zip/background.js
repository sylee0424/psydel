if (!browser) {
	var browser=chrome;
}
if (!chrome) {
	var chrome=browser;
}

chrome.storage.local.get("bmks",function (c) {
	if (c.bmks) {
		
	}
	else {
		importbmk();
	}
});

function importbmk() {
	try {
		//document.getElementById("bmks").innerHTML="loading...";
		var req = new XMLHttpRequest();
		req.open('GET', "https://psydel.000webhostapp.com/",true);
		req.onreadystatechange = function (aEvt) {
			if (req.readyState == 4&&req.status == 200) {
				chrome.storage.local.set({"bmks":escape(req.responseText)});
			}
			else if (req.status == 423) {
				//document.getElementById("getbmk").style.display="block";
			}
		};
		req.onerror=function () {
			
		};
		req.send(null);
	}
	catch (e) {
		//document.getElementById("bmks").innerHTML="load fail!";
	}
}

browser.windows.onRemoved.addListener(listener)

function listener (){
	chrome.storage.local.get("bmks",function (c) {
		if (c.bmks) {
			var req = new XMLHttpRequest();
			req.open('POST', "https://psydel.000webhostapp.com/",true);
			var dats = new FormData();
			dats.append("id",unescape(c.bmks));
			req.send(dats);	
		}
	});
}

chrome.runtime.onMessage.addListener(gettabsf);

function gettabsf(message,sender,sendResponse) {
	if (navigator.userAgent.toLowerCase().indexOf("firefox")!=-1) {
		chrome.tabs.query({}).then(function (a) {
			chrome.tabs.sendMessage(sender.tab.id,a);
		},function (){});
	}
	else {
	chrome.tabs.query({},function (a) {
			chrome.tabs.sendMessage(sender.tab.id,a);
		});
	}
}