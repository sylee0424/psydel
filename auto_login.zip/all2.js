var wind=chrome.extension.getBackgroundPage();

var t=document.getElementById("btn1");
t.addEventListener("click", namu);

t=document.getElementById("btn2");
t.addEventListener("click", typemoon);

t=document.getElementById("btn3");
t.addEventListener("click", github);

t=document.getElementById("btn4");
t.addEventListener("click", icomu);

function namu() {
var d=wind.document;
d.location.href="https://namu.wiki/login";
wind.addEventListener("DOMContentLoaded", function () {
var a=document.getElementById("usernameInput");
var b=document.getElementById("passwordInput");
var c=document.getElementsByClassName("login-form")[0];
a.value="sylee0424";
b.value="lsy0307";
c.submit();
} );
}

function icomu() {
var d=wind.document;
d.location.href="https://idolmaster.co.kr/bbs/login.php";
wind.addEventListener("DOMContentLoaded", function () {
var a=document.getElementsByName("mb_id")[0];
var b=document.getElementsByName("mb_password")[0];
var c=document.getElementsByName("flogin")[0];
a.value="sylee0424";
b.value="lsy0307";
c.submit();
} );
}

function typemoon() {
var d=wind.document;
d.location.href="http://www.typemoon.net/bbs/login.php";
wind.addEventListener("DOMContentLoaded", function () {
var a=document.getElementsByName("mb_id")[0];
var b=document.getElementsByName("mb_password")[0];
var c=document.getElementsByName("flogin")[0];
a.value="sylee0424";
b.value="lsy0307";
c.submit();
} );
}

function github() {
var d=wind.document;
d.location.href="https://github.com/login";
wind.addEventListener("DOMContentLoaded", function () {
var a=document.getElementById("login_field");
var b=document.getElementById("password");
var c=document.getElementsByTagName("form")[0];
a.value="sylee0424";
b.value="lsy0307";
c.submit();
} );
}