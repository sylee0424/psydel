window.addEventListener("DOMContentLoaded", function () {
if (!alljs&&!(parent&&parent!=this)) {
    var __scr=document.createElement("script");
    __scr.setAttribute("type","text/javascript");
    __scr.setAttribute("src",chrome.runtime.getURL("all2.js"));
    document.head.appendChild(__scr);
    var alljs=1;
}
} );