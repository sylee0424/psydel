function setbookmark() {
	//var tid;
	//chrome.bookmarks.getTree(function (a) { tid=a[0].id});
	var req = new XMLHttpRequest();
	req.open('GET', geturl("bmk.json"), false);
	req.onreadystatechange = function (aEvt) {
		if (req.readyState == 4&&req.status == 200) {
			jsn=JSON.parse(req.responseText);
			for (var s in jsn) {
				var a=document.createElement("div");
				a.setAttribute("data-src",jsn[s]);
				a.setAttribute("id",s);
				a.appendChild(document.createTextNode(s));
				document.getElementById("bmks").appendChild(a);
				a.addEventListener("click", bmklink);
			}
		}
	};
	req.send(null);
}

function bmklink(){
	if (document.getElementById("chk").checked) {
		var req = new XMLHttpRequest();
		req.open('GET', geturl("bmk.json"), false);
		req.onreadystatechange = function (aEvt) {
			if (req.readyState == 4&&req.status == 200) {
				jsn=JSON.parse(req.responseText);
				delete jsn[this.id];
				this.parentNode.removeChild(this);
				chrome.downloads.download({url:"data:text/plain,"+encodeURI(JSON.stringify(jsn)),conflictAction:"overwrite",filename:"bookmarks/bmk.json"});
			}
		};
		req.send(null);
	}
	else {
		window.open(this.dataSrc,"_blank","");
	}
}

function addbookmark() {
	var tabids;
	chrome.tabs.query(
		{ currentWindow: true, active: true },
		function (aaa) { tabids=aaa[0].id; }
	);
	var aa=window.document;
	chrome.tabs.executeScript(/*tabids,*/{code:'var a={name:"",path:""}; a.name=document.getElementsByTagName("title")[0].innerHTML; a.path=document.location.href; a;'},function (result) {
		var req = new XMLHttpRequest();
		req.open('GET', geturl("bmk.json"), false);
		req.onreadystatechange = function (aEvt) {
			if (req.readyState == 4&&req.status == 200) {
				var b;
				jsn=JSON.parse(req.responseText);
				if (!jsn[result[0].name]) {
					
				}
				else if (confirm("overwrite \""+result[0].name+"\" ?")) {
					aa.getElementById(result[0].name).parentNode.removeChild(aa.getElementById(result[0].name));
				}
				else if (""!=(result[0].name=prompt("new name",""))){
					
				}
				else {
					return undefined;
				}
				jsn[result[0].name]=result[0].path;
				chrome.downloads.download({url:"data:text/plain,"+encodeURI(JSON.stringify(jsn)),conflictAction:"overwrite",filename:"bookmarks/bmk.json"});
				var a=document.createElement("div");
				a.addEventListener("click", bmklink);
				a.setAttribute("data-src",result[0].path);
				a.setAttribute("id",result[0].name);
				a.appendChild(document.createTextNode(result[0].name));
				aa.getElementById("bmks").appendChild(a);
			}
		};
		req.send(null);
	});
}
var jsn;
var geturl=(chrome.runtime.getURL?chrome.runtime.getURL:chrome.extension.getURL);

function clc(){
	//document.getElementById("b1").addEventListener("click", function(){setbookmark()});
	document.getElementById("b2").addEventListener("click", function(){addbookmark()});
	document.removeEventListener("mouseover",clc );
	setbookmark();
}

document.addEventListener("mouseover",clc );
