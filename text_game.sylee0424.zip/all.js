// function tab {


Object.prototype.toString= function (a) {
	if (!a) {
		a=0;
	}
	var ret="{\n";
	for (var i=0;i<a;i++) {
		ret+="\t";
	}
	for (var s in this) {
		if (typeof this[s] == "object"&&a<3) {
			ret+=s+": "+this[s].toString(a+1)+"\n";
			for (i=0;i<a;i++) {
				ret+="\t";
			}
		}
		else if (typeof this[s] == "object"&&a>=3) {
			ret+=s+": {too deep object}\n";
			for (i=0;i<a;i++) {
				ret+="\t";
			}
		}
		else if (typeof this[s] == "array") {
			ret+=s+": [";
			for (var t in this[s]) {
				ret+="\""+this[s][t].toString() +"\",";
			}
			ret=ret.substring(0,ret.length);
			ret+="]\n";
			for (i=0;i<a;i++) {
				ret+="\t";
			}
		}
		else {
			ret+=s+": "+this[s].toString() +"\n";
			for (i=0;i<a;i++) {
				ret+="\t";
			}
		}
	}
	return ret+"}";
}


if (!console) {
	var console={
		text:"",
		log: function () {
			if (arguments[0]) {
				this.text+="\n"+arguments[0].toString();
			}
			else {
				this.text+="\n"+arguments[0];
			}
		}
	}
}

function randomnodes(width,height) {
	for (var i=0;i<width*height;i++) {
		var k=0;
		var b=0;
		var a=Math.floor(Math.random()*(width*height-i));
		var j=0;
		do {
			if (k!=0) {
				j++
			}
			if (map.cells[b][k%width].array) {
				j--;
			}
			else {
				rndz[i]=map.cells[b][k%width];
			}
			if (k%width==width-1) {
				b++;
			}
			k++;
		} while (j<a)
		map.cells[rndz[i].loc.x][rndz[i].loc.y].array=true;
	}
}

function loadsave() {
	var fileReader = new XMLHttpRequest();
	fileReader.open('GET', 'save.dat', true);
	fileReader.onload = function() {
		if (fileReader.status == 200) {
			party[0] = JSON.parse(fileReader.responseText);
		}
	};
	fileReader.send(null);
}

function savefile(obj) {
	var objtxt=JSON.stringify(obj);
	var a=document.createElement("a");
	if (typeof a.download!=undefined&&a.download) {
		a.setAttribute("href","data:text/plain,"+encodeURI(objtxt));
		a.setAttribute("download","save.txt");
		a.appendChild(document.createTextNode("save"));
		document.body.appendChild(a);
	}
	else if (document.execCommand) {
		a = window.open();
		a.document.write(objtxt);
		a.document.close();
		a.document.execCommand("SaveAs",true,"save.txt");
		a.close();
	}
}

function OpenDG(map)
{
	if (intv) {
		clearInterval(intv);
		intv=null;
	}
	document.getElementById("upstairs").setAttribute("disabled","true");
	document.getElementById("downstairs").setAttribute("disabled","true");
	map.width=dg[map.id].width;
	map.height=dg[map.id].height;
	map.align=dg[map.id].align;
	map.data=dg[map.id].data;
	map.cells=createCells(map.width,map.height);
	randomnodes(map.width,map.height);
	if (map.data.tile.monster) {
		rndz[0].status.mns=0;
		rndz.shift();
	}
	makestair(map.data.tile.upstair,map.data.tile.downstair);
	if (map.align=="up") {
		map.loc.x=map.data.tile.downstair.x;
		map.loc.y=map.data.tile.downstair.y;
	}
	else if (map.align=="down") {
		map.loc.x=map.data.tile.upstair.x;
		map.loc.y=map.data.tile.upstair.y;
	}
	else {
		map.loc.x=Math.floor(Math.random()*map.width);
		map.loc.y=Math.floor(Math.random()*map.height);
	}
	viewmap();
	for (var s in map.cells[map.loc.x][map.loc.y].around)
	{
		if (map.cells[map.loc.x][map.loc.y].connected[s]) {
			document.getElementById(""+(map.loc.x-(s=="left")+(s=="right")+""+(map.loc.y-(s=="down")+(s=="up")))).setAttribute("onclick","go_to('"+s+"');");
		}
	}
	var a=document.getElementById("maptable");
	var k=a.getAttribute("style")
	k=k.split(/top\s?\:\s?.*?\;\s+left\s?\:\s?.*?\;/);
	a.setAttribute("style",k[0]+"top:"+(document.body.scrollHeight-a.offsetHeight)/2+"px; left:"+(document.body.scrollWidth-a.offsetWidth)/2+"px;"+k[1]);
}

/*
7 �� �� �� �� �� �� �� �� �� ��
6 �� �� �� �� �� �� �� �� �� ��
5 �� �� �� �� �� �� �� �� �� ��
4 �� �� �� �� �� �� �� �� �� ��
3 �� �� �� �� �� �� �� �� �� ��
2 �� �� �� �� �� �� �� �� �� ��
1 �� �� �� �� �� �� �� �� �� ��
0 �� �� �� �� �� �� �� �� �� ��
ij0 1 2 3 4 5 6 7 8 9
*/

function viewmap()
{
	var a=document.getElementById("maptable");
	a.removeChild(a.firstChild);
	var b=document.createElement("tbody");
	b.appendChild(document.createTextNode(" "));
	for (var i=0;i<map.height;i++)
	{
		var c=document.createElement("tr");
		c.setAttribute("style","height:30px");
		for (var j=0;j<map.width;j++)
		{
			var d=document.createElement("td");
			d.setAttribute("style","text-align:center; width:30px; border-collapse:collapse; border-spacing:0px; border-top:"+Number(!(map.cells[j][i].connected.up))+"px solid black;"+"border-bottom:"+Number(!(map.cells[j][i].connected.down))+"px solid black;"+"border-left:"+Number(!(map.cells[j][i].connected.left))+"px solid black;"+"border-right:"+Number(!(map.cells[j][i].connected.right))+"px solid black;");
			d.id=""+j+""+i;
			c.appendChild(d);
		}
		b.insertBefore(c,b.firstChild);
	}
	b.removeChild(b.lastChild);
	a.appendChild(b);
	document.body.appendChild(a);
	for (var i=0;i<map.height;i++)
	{
		for (var j=0;j<map.width;j++)
		{
			mapstat(j,i);
		}
	}
}

function createCells(width,height)
{
	var a=new Array(width);
	for (var i=0;i<width;i++)
	{
		a[i]=new Array(height);
		for (var j=0;j<height;j++)
		{
			a[i][j]=new Cell();
		}
	}
	for (i=0;i<width;i++)
	{
		for (var j=0;j<height;j++)
		{
			if (j!=height-1)
			{
				a[i][j].around.up=a[i][j+1];
			}
			if (j!=0)
			{
				a[i][j].around.down=a[i][j-1];
			}
			if (i!=0)
			{
				a[i][j].around.left=a[i-1][j];
			}
			if (i!=width-1)
			{
				a[i][j].around.right=a[i+1][j];
			}
			a[i][j].loc.x=i;
			a[i][j].loc.y=j;
		}
	}
	var b=a[Math.floor(Math.random()*width)][Math.floor(Math.random()*height)];
	var c=new Array();
	var d=new Array();
	for (var s in b.around)
	{
		if (b.around[s].connected.up==false&&b.around[s].connected.down==false&&b.around[s].connected.left==false&&b.around[s].connected.right==false)
		{
			c.push(b.around[s]);
			d.push(s);
		}
	}
	i=width*height-1;
	while (i--)
	{
		var j=Math.floor(Math.random()*c.length);
		c[j].around[inv(d[j])].connected[d[j]]=true;
		c[j].connected[inv(d[j])]=true;
		for (s in c[j].around)
		{
			if (c[j].around[s].connected.up==false&&c[j].around[s].connected.down==false&&c[j].around[s].connected.left==false&&c[j].around[s].connected.right==false)
			{
				c.push(c[j].around[s]);
				d.push(s);
			}
		}
		var k=a[Number(c[j].loc.x)][Number(c[j].loc.y)];
		j=c.length;
		while (j--)
		{
			if (c[j]==k)
			{
				c.splice(j,1);
				d.splice(j,1);
			}
		}
	}
	rndzn=0;
	for (i=0;i<width;i++) {
		for (j=0;j<width;j++) {
			
		}
	}
	return a;
}

function inv(s)
{
	if (s=="up")
	{
		s="down";
	}
	else if (s=="down")
	{
		s="up";
	}
	else if (s=="left")
	{
		s="right";
	}
	else if (s=="right")
	{
		s="left";
	}
	return s;
}

function go_to(s)
{
	if (dg[s]) {
		map.id=s;
		OpenDG(map);
	}
	else if (world[s]) {
		
	}
	else if (s=="upper"&&map.loc.x!=-1) {
		document.getElementById("upstairs").setAttribute("disabled","true");
		document.getElementById("downstairs").setAttribute("disabled","true");
		if (map.floor+1>=map.data.max&&map.align=="up") {
			if (!confirm("next floor is dungeon boss room\nhave you go forward?")) {
				return undefined;
			}
		}
		if (intv) {
			clearInterval(intv);
			intv=null;
		}
		map.floor++;
		store.x=map.data.tile.upstair.x;
		store.y=map.data.tile.upstair.y;
		map.cells=createCells(Number(map.width),Number(map.height));
		randomnodes(map.width,map.height);
		if (map.data.tile.monster) {
			rndz[0].status.mns=0;
			map.data.tile.monster.x=rndz[0].loc.x;
			map.data.tile.monster.y=rndz[0].loc.y;
			rndz.shift();
		}
		makestair(map.data.tile.upstair,null);
		viewmap();
		for (var s in map.cells[map.loc.x][map.loc.y].around)
		{
			if (map.cells[map.loc.x][map.loc.y].connected[s]) {
				document.getElementById(""+(map.loc.x-(s=="left")+(s=="right")+""+(map.loc.y-(s=="down")+(s=="up")))).setAttribute("onclick","go_to('"+s+"');");
			}
		}
	}
	else if (s=="lower"&&map.loc.x!=-1) {
		document.getElementById("upstairs").setAttribute("disabled","true");
		document.getElementById("downstairs").setAttribute("disabled","true");
		if (map.floor-1<=map.data.min&&map.align=="down") {
			if (!confirm("next floor is dungeon boss room\nhave you go forward?")) {
				return undefined;
			}
		}
		if (intv) {
			clearInterval(intv);
			intv=null;
		}
		map.floor--;
		store.x=map.data.tile.downstair.x;
		store.y=map.data.tile.downstair.y;
		map.cells=createCells(Number(map.width),Number(map.height));
		randomnodes(map.width,map.height);
		if (map.data.tile.monster) {
			rndz[0].status.mns=0;
			map.data.tile.monster.x=rndz[0].loc.x;
			map.data.tile.monster.y=rndz[0].loc.y;
			rndz.shift();
		}
		makestair(null,map.data.tile.downstair);
		viewmap();
		for (var s in map.cells[map.loc.x][map.loc.y].around)
			{
			if (map.cells[map.loc.x][map.loc.y].connected[s]) {
				document.getElementById(""+(map.loc.x-(s=="left")+(s=="right")+""+(map.loc.y-(s=="down")+(s=="up")))).setAttribute("onclick","go_to('"+s+"');");
			}
		}
	
	}
	else if (map.loc.x!=-1) {
		if (map.cells[map.loc.x][map.loc.y].connected[s]) {
			document.getElementById("upstairs").setAttribute("disabled","true");
			document.getElementById("downstairs").setAttribute("disabled","true");
			for (var t in map.cells[map.loc.x][map.loc.y].around) {
				document.getElementById(""+(map.loc.x-(t.indexOf("left")!=-1)+(t.indexOf("right")!=-1))+""+(map.loc.y-(t.indexOf("down")!=-1)+(t.indexOf("up")!=-1))).removeAttribute("onclick");
			}
			if (intv) {
				clearInterval(intv);
				intv=null;
			}
			var a=map.cells[map.loc.x][map.loc.y].around[s].loc.x;
			map.loc.y=map.cells[map.loc.x][map.loc.y].around[s].loc.y;
			map.loc.x=a;
			viewmap();
			for (var s in map.cells[map.loc.x][map.loc.y].around)
			{
				if (map.cells[map.loc.x][map.loc.y].connected[s]) {
					document.getElementById(""+(map.loc.x-(s=="left")+(s=="right")+""+(map.loc.y-(s=="down")+(s=="up")))).setAttribute("onclick","go_to('"+s+"');");
				}
			}
			if (Math.random()<=map.data.engage&&map.cells[map.loc.x][map.loc.y].status.mns) {
				arr=battlestart();
			}
		}
	}
	else {
		alert("error! check destination")
	}
}

var arr;

function mapstat(x,y) {
	if (x==map.loc.x&&y==map.loc.y) {
		setback(document.getElementById(""+x+""+y),"pl");
		for (var s in map.cells[map.loc.x][map.loc.y].status) {
			intv=setInterval("blink("+map.loc.x+","+map.loc.y+");",500);
			if (s=="us") {
				document.getElementById("upstairs").removeAttribute("disabled");
			}
			else if (s=="ds") {
				document.getElementById("downstairs").removeAttribute("disabled");
			}
			break;
		}
	}
	else if (map.cells[x][y].status.us) {
		setback(document.getElementById(""+x+""+y),"us");
	}
	else if (map.cells[x][y].status.ds) {
		setback(document.getElementById(""+x+""+y),"ds");
	}
	else if (map.cells[x][y].status.mns) {
		setback(document.getElementById(""+x+""+y),"mns");
	}
}

function blink(x,y) {
	document.getElementById(""+x+""+y).removeChild(document.getElementById(""+x+""+y).firstChild);
	if (bls) {
		setback(document.getElementById(""+x+""+y),"pl");
		bls=!bls;
	}
	else {
		for (var s in map.cells[x][y].status) {
			var a=s;
			break;
		}
		setback(document.getElementById(""+x+""+y),a);
		bls=!bls;
	}
}

function setback(a,b) {
	if (typeof back[b]!="undefined") {
		if (typeof back[b].image!="undefined") {
			var img=document.createElement("img");
			img.setAttribute("style","width:100%; height:100%;");
			img.setAttribute("src",back[b].image);
			a.appendChild(img);
		}
		else {
			a.appendChild(document.createTextNode(back[b].text));
		}
	}
}

function makestair(up,down) {
	if (up) {
		rndz[0].status.us=true;
		map.data.tile.upstair.x=rndz[0].loc.x;
		map.data.tile.upstair.y=rndz[0].loc.y;
		rndz.shift();
	}
	else {
		if (map.data.tile.upstair) {
			map.data.tile.upstair.x=store.x;
			map.data.tile.upstair.y=store.y;
			map.cells[store.x][store.y].status.us=true;
		}
		else {
			console.log(up);
		}
	}
	if (down) {
		rndz[0].status.ds=true;
		map.data.tile.downstair.x=rndz[0].loc.x;
		map.data.tile.downstair.y=rndz[0].loc.y;
		rndz.shift();
	}
	else {
		if (map.data.tile.downstair) {
			map.data.tile.downstair.x=store.x;
			map.data.tile.downstair.y=store.y;
			map.cells[store.x][store.y].status.ds=true;
		}
		else {
			console.log(down);
		}
	}
}

function battlestart() {
	addmonster(map.data.type);
	var p=(map.data.average-1)/3;
	for (var i=0;i<3;i++) {
		if (Math.random()<=p) {
			addmonster(map.data.type);
		}
	}
	var arr=[];
	for (var s in party) {
		arr.push(party[s]);
	}
	for (var s in enemy) {
		arr.push(enemy[s]);
	}
	arr.sort( function(a, b) { return a.stat.agi < b.stat.agi ? -1 : a.stat.agi > b.stat.agi ? 1 : 0; } );
	return arr;
}

function battleend() {
	enemy=[];
	arr=null;
}

function addmonster(type) {
	var arr=[];
	for (var s in monster) {
		for (var t in monster[s].type) {
			if (type.indexOf(monster[s].type[t])!=-1) {
				arr.push(monster[s]);
			}
		}
	}
	enemy.push(arr[Math.floor(Math.random()*arr.length)]);
}

// contructor function tab

function Cell() {
	this.array=false;
	this.around={};
	this.connected={up:false,down:false,left:false,right:false};
	this.status={};
	this.loc={x:-1,y:-1};
}

function objChar() {
	this.name="";
	this.equip={head:{},body:{},left:{},right:{},feet:{},mainarms:{},subarms:{},acce1:{},acce2:{},acce3:{}};
	this.job="none";
	this.inven={items:[],money:0,max:50};
	this.stat={str:0,agi:0,con:0,"int":0,dex:0,luc:0,lv:1,exp:0,hp:1,mp:0};
	this.magic=new objMagic();
	this.skill=new objSkill();
	this.quest={};
	this.type=[];
	this.data={};
	if (arguments.length==1) {
		for (var s in arguments[0]) {
			this[s]=arguments[0][s];
		}
	}
}

function objMagic() {
	return {};
}

function objSkill() {
	return {};
}

function Equipment()
{
	this.id="000001";
	this.type="sword";
	this.limit={ };
	this.damage=1;
	this.effect={ };
	this.descrption="normal sword";
	this.value=100;
	if (arguments[0]&&arguments[0].id&&eqs[arguments[0].id])
	{
		for (var s in eqs[arguments[0]])
		{
			this[s]=eqs[arguments[0]][s];
		}
	}
	for (var s in arguments[0])
	{
		req[s]=arguments[0][s];
	}
}

// object tab

var monster ={
	rat:{
		name:"rat",
		equip:{head:{},body:{},left:{},right:{},feet:{},mainarms:{},subarms:{},acce1:{},acce2:{},acce3:{}},
		job:"none",
		inven:{items:[],money:0,max:50},
		stat:{str:0,agi:18,con:0,"int":0,dex:0,luc:0,lv:1,exp:0,hp:1,mp:0},
		magic:{},
		skill:{},
		quest:{},
		type:["small","animal","normal"],
		data:{}
	}
}

var map = {
	width:0,
	height:0,
	floor:0,
	id:"none",
	cells:[],
	align:"none",
	data:{},
	loc:{x:-1,y:-1}
};

var dg = {
	none: {
		width:9,
		height:9,
		align:"up",
		data: {
			max:3,
			min:0,
			type:["small","animal","normal"],
			tile:{upstair:{x:-1,y:-1},downstair:{x:-1,y:-1},monster:[{x:-1,y:-1}]},
			average:1.8,
			engage:0.95
		}
	}
};

var eqs = {
	"000001": {
		id:"000001",
		type:"sword",
		limit: {},
		damage:1,
		effect: {},
		description: "normal sword",
		value:100
	}
};

var world = {
	home: {
		dg: {
			none:true
		}
	}
};

var back = {
	pl: {
		text:"@"
	},
	us: {
		text:"u"
	},
	ds: {
		text:"d"
	},
	mns: {
		text:"m"
	}
};

var store = {
	x:-1,
	y:-1
};

// global variable tab

var intv=null;

var enemy=[];

var party=[{
	name:"nameless",
	equip:{head:{},body:{},left:{},right:{},feet:{},mainarms:{},subarms:{},acce1:{},acce2:{},acce3:{}},
	job:"stranger",
	inven:{items:[],money:1000,max:50},
	stat:{str:10,agi:10,con:10,"int":10,dex:10,luc:10,lv:1,exp:0,hp:100,mp:100},
	magic:{},
	skill:{},
	quest:{},
	type:["small","animal","normal"],
	data:{}
}];

var bls=true;

var rndz=[];

var rndzn=0;