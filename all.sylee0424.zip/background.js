﻿function gettablist(option,callback) {
	if (navigator.userAgent.toLowerCase().indexOf("firefox")!=-1) {
		extension.tabs.query(option).then(callback,function (){});
	}
	else {
		extension.tabs.query(option,callback);
	}
}

function gettabsf(message,sender,sendResponse) {
	switch (message.type) {
		case "gettab":
			gettablist({},function (a) {
				extension.tabs.sendMessage(sender.tab.id,a);
			});
			break;
		case "changeto":
			if (message.id) {
				extension.tabs.update(message.id, {active: true});
			}
			else {
				gettablist({},function (a) {
					if (message.dir=="left") {
						if (sender.tab.index==0) {
							return undefined;
						}
						extension.tabs.update(a[sender.tab.index-1].id,{active: true});
					} else if (message.dir=="right") {
						if (sender.tab.index==a.length-1) {
							return undefined;
						}
						extension.tabs.update(a[sender.tab.index+1].id,{active: true});
					}
				});
			}
			break;
		case "create":
			extension.tabs.create(message.option);
			break;
		case "moveto":
			if (message.dir=="left") {
				if (sender.tab.index==0) {
					return undefined;
				}
				extension.tabs.move(sender.tab.id,{index:sender.tab.index-1});
			} else if (message.dir=="right") {
				extension.tabs.move(sender.tab.id,{index:sender.tab.index+1});
			}
			break;
		case "closeto":
			extension.tabs.remove(message.id);
			break;
		case "tabbartoggle":
			gettablist({},function (a) {
				for (var i=0;i<a.length;i++) {
					if (sender.tab.id!=a[i].id) {
						extension.tabs.sendMessage(a[i].id,{type:"toggle",toggle:message.toggle});
					}
				}
			});
			break;
		case "dataurl":
			var req = new XMLHttpRequest();
			req.open('GET', "https://psydel.000webhostapp.com/append.php",true);
			req.onreadystatechange = function (aEvt) {
				if (req.readyState == 4&&req.status == 200) {
					window.e=JSON.parse(escape(req.responseText));
				}
				else if (req.status == 423) {
					//document.getElementById("getbmk").style.display="block";
				}
			};
			req.onerror=function () {
				
			};
			req.send(null);
			break;
		default:
	}
}

function updatetabs(id,info,tab) {
	if (navigator.userAgent.toLowerCase().indexOf("firefox")!=-1) {
		extension.tabs.query({}).then(favcng,function (){});
	}
	else {
		extension.tabs.query({},favcng);
	}
}

function favcng(a) {
	var d=[];
	var b="";
	for (var i=0;i<a.length;i++) {
		d[i]={};
		d[i].id=Number(a[i].id);
		d[i].index=Number(a[i].index);
		d[i].title=String(a[i].title);
		b=a[i].favIconUrl;
		if (!b||b=="undefined"||b==""||typeof b=="undefined") {
			d[i].favIconUrl="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAIAAADYYG7QAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABDSURBVFhH7c4xAQAwDASh+jf9lcCa4VDA2zGFpJAUkkJSSApJISkkhaSQFJJCUkgKSSEpJIWkkBSSQlJICkkhORbaPoBi5ofwSUznAAAAAElFTkSuQmCC";
		}
		else if (window.e[b]) {
			d[i].favIconUrl=window.e[b];
		}
		else {
			getDataUri(b, function(dataUri) {});
			d[i].favIconUrl=a[i].favIconUrl;
		}
	}
	for (var i=0;i<a.length;i++) {
		extension.tabs.sendMessage(a[i].id,d);
	}
}

function getDataUri(url, callback) {
    var image = new Image();
    image.onload = function () {
        var canvas = document.createElement('canvas');
        canvas.width = this.naturalWidth;
        canvas.height = this.naturalHeight;
        canvas.getContext('2d').drawImage(this, 0, 0);
        window.e[url]=canvas.toDataURL('image/png');
    };
    image.src = url;
}

function importbmk() {
	try {
		//document.getElementById("bmks").innerHTML="loading...";
		var req = new XMLHttpRequest();
		req.open('GET', "https://psydel.000webhostapp.com/",true);
		req.onreadystatechange = function (aEvt) {
			if (req.readyState == 4&&req.status == 200) {
				extension.storage.local.set({"bmks":escape(req.responseText)});
				console.log("loaded");
			}
			else if (req.status == 423) {
				//document.getElementById("getbmk").style.display="block";
				console.log("load failed");
			}
		};
		req.onerror=function () {
			
		};
		req.send(null);
	}
	catch (e) {
		//document.getElementById("bmks").innerHTML="load fail!";
				console.log("error");
	}
	
	var rep = new XMLHttpRequest();
	rep.open('GET', "https://psydel.000webhostapp.com/append.php",true);
	rep.onreadystatechange = function (aEvt) {
		if (rep.readyState == 4&&rep.status == 200) {
			window.e=JSON.parse(escape(rep.responseText));
		}
		else if (rep.status == 423) {
			//document.getElementById("getbmk").style.display="block";
		}
	};
	
}

function listener (){
	extension.storage.local.get("bmks",function (c) {
		if (c.bmks) {
			var req = new XMLHttpRequest();
			req.open('POST', "https://psydel.000webhostapp.com/",true);
			var dats = new FormData();
			dats.append("id",unescape(c.bmks));
			req.send(dats);	
		}
	});
	var req = new XMLHttpRequest();
	req.open('POST', "https://psydel.000webhostapp.com/append.php",true);
	var dats = new FormData();
	dats.append("id",unescape(JSON.stringify(e)));
	req.send(dats);
}

var extension=(!!chrome)?chrome:browser;

var e={};

extension.windows.onRemoved.addListener(listener)
extension.runtime.onMessage.addListener(gettabsf);
extension.tabs.onRemoved.addListener(updatetabs);
extension.tabs.onUpdated.addListener(updatetabs);
extension.tabs.onMoved.addListener(updatetabs);
extension.tabs.onReplaced.addListener(updatetabs);
extension.tabs.onCreated.addListener(updatetabs);

extension.webRequest.onHeadersReceived.addListener(
	function(details) {
		if (details.type=="main_frame") {
			console.log("a");
			return {redirectUrl:"data:text/html,%3Chtml%3E%3Chead%3E%3Cscript%3Ewindow.postMessage%28%7Btype%3A%22test%22%7D%2C%22*%22%29%3C/script%3E%3Cbase%20href%3D%22https%3A//hitomi.la%22%3E%3C/base%3E%3C/head%3E%3Cbody%3E%3Cdiv%20id%3D%22left%22%20style%3D%22z-index%3A3%3B%20position%3Afixed%3B%20top%3A50%25%3B%20left%3A0%25%3B%20width%3A20px%3B%20height%3A50px%3B%20opacity%3A0.5%3B%20border%3A1px%20solid%20%23000000%3B%20background-color%3A%23ffffff%3B%22%3E%3C/div%3E%3Cdiv%20id%3D%22right%22%20style%3D%22z-index%3A3%3B%20position%3Afixed%3B%20top%3A50%25%3B%20right%3A0%25%3B%20width%3A20px%3B%20height%3A50px%3B%20opacity%3A0.5%3B%20border%3A1px%20solid%20%23000000%3B%20background-color%3A%23ffffff%3B%22%3E%3C/div%3E%3C/body%3E%3C/html%3E"};
		}
		if (details.url.indexOf("https://hitomi.la")!=-1) {
			for (var i = 0; i < details.responseHeaders.length; ++i) {
				if (details.responseHeaders[i].name === "access-control-allow-origin") {
					details.responseHeaders[i].value="*";
				}
			}
		}
		console.log(details);
	return {responseHeaders: details.responseHeaders};
	},
	{urls: ["https://hitomi.la/*"]},
	["blocking", "responseHeaders"]
);

extension.webRequest.onBeforeSendHeaders.addListener(
	function(details) {
		for (var i = 0; i < details.requestHeaders.length; ++i) {
			if (details.requestHeaders[i].name === "Origin") {
				details.requestHeaders[i].value="https://hitomi.la/index-korean-1.html";
			}
		}
		details.requestHeaders.push({name:"Referer",value:"https://hitomi.la/index-korean-1.html"});
	return {requestHeaders: details.requestHeaders};
	},
	{urls: ["https://hitomi.la/*"]},
	["blocking", "requestHeaders"]
);

extension.storage.local.get("bmks",function (c) {
	if (c.bmks) {
		
	}
	else {
		importbmk();
	}
});