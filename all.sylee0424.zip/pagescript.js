var nds = null;

window.Button_Tab_Page = 0;

var size = {
	width: window.innerWidth || document.body.clientWidth,
	height: window.innerHeight || document.body.clientHeight
}

if (location.href.match(/^https?\:\/\/hitomi\.la/i)) {
	Extension_User_Functions.hab.f();
	Extension_User_Functions.hlb.f();
}

if (location.href.match(/^https?\:\/\/(m|www|bbs)\.ruliweb/i)) {
	Extension_User_Functions.rab.f();
}

if (location.href.indexOf("marumaru") != -1 || location.href.indexOf("wasabisyrup") != -1) {
	Extension_User_Functions.mab.f();
}

setInterval(function() {
	if (window.innerWidth != lncs) {
		lncs = window.innerWidth;
		var a = document.getElementsByClassName("abtn");
		var c = window.innerWidth / document.body.offsetWidth;
		for (var b of a) {
			b.style.fontSize = c * 10 + "px";
			b.style.borderWidth = c + "px";
		}
	}
}, 100);

window.lncs = 0;

window.addEventListener("mousedown",Extension_Tool_Functions.Fake_Scroll_Event.f);
window.addEventListener("mouseup",Extension_Tool_Functions.Fake_Scroll_Event_End.f);

setInterval(Extension_User_Functions.ael.f,40);

Extension_Tool_Functions.Add_Extension_Interface.f();

window.addEventListener("message",Extension_Tool_Functions.On_Message.f);

function changetab() {
	window.postMessage({
		type: "changeto",
		id: Number(this.dataset.id),
		des: "back"
	}, "*");
}

function closetab() {
	window.postMessage({
		type: "closeto",
		id: Number(this.dataset.id),
		index: Number(this.dataset.index),
		des: "back"
	}, "*");
}

document.onmousedown=function () {};

window.postMessage({
	type: "gettab",
	des: "back"
}, "*");

window.postMessage({
	type: "check",
	bmk: {}
}, "*");