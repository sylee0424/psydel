﻿window.Button_Tab_Page = 0;

Extension_Tool_Functions.Add_Extension_Interface.f();

if (location.href.match(/^https?\:\/\/hitomi\.la/i)) {
	Extension_Tool_Functions.hab.f();
	Extension_Tool_Functions.hlb.f();
}

if (location.href.match(/adfree\.html/i)) {
	Extension_Tool_Functions.hlb.f();
}

if (location.href.match(/^https?\:\/\/(m|www|bbs)\.ruliweb/i)) {
	Extension_Tool_Functions.rab.f();
}

window.postMessage({
	type: "gettab",
	des: "back"
}, "*");

window.postMessage({
	type: "check",
	bmk: {}
}, "*");

window.addEventListener("mousedown",Extension_Tool_Functions.Fake_Scroll_Event.f);
window.addEventListener("mouseup",Extension_Tool_Functions.Fake_Scroll_Event_End.f);
window.addEventListener("message",Extension_Tool_Functions.On_Message.f);

setInterval(Extension_Tool_Functions.ael.f,40);

document.onmousedown=function () {};
