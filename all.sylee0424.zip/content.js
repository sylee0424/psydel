var extension=(!!chrome)?chrome:browser;

window.arr=[];
window.arr2=[];

function movefixed(element) {
	if (!element) {
		element = document.documentElement;
	}
	if (element.nodeName != "#text" && element.tagName && element.nodeName != "#comment") {
		if (element.hasAttribute("src")||element.hasAttribute("href")) {
			arr[arr.length]=element;
			arr2[arr2.length]=false;
		}
	}
	console.log(element.childNodes);
	for (var i=0;i<element.childNodes.length;i++) {
		movefixed(element.childNodes[i]);
	}
	if (element==document.documentElement) {
		getdatauri();
	}
}

function getdatauri(){
	for (var i=0;i<arr.length;i++) {
		if (arr[i].hasAttribute("src")) {
			var url=element.getAttribute("src");
		}
		else {
			var url=element.getAttribute("href");
		}
		getDataUri(arr[i].hasAttribute("src"),url,i)
	}
}

function getDataUri(has,url,index) {
    var req = new XMLHttpRequest();
	req.open('GET',url,true);
	req.onreadystatechange = function (aEvt) {
		if (req.readyState == 4&&req.status == 200) {
			if (has) {
				var a="src";
			}
			else {
				var a="href";
			}
			if (window.arr[index].tagName=="image") {
				var b="data:image/png;base64,"
			}
			else {
				var b="data:text/html;base64,"
			}
			window.arr[index].setAttribute(a,b+btoa(req.responseText));
			window.arr2[index].shift();
			if (window.arr2.length==0) {
				
			}
		}
	};
	req.send(null);
}

var addlist=[
	{
		tag:"button",
		name:"edit",
		id:"b1",
		classname:[]
	},
	{
		tag:"button",
		name:"add",
		id:"b2",
		classname:[]
	},
	{
		tag:"button",
		name:"sort",
		id:"c7",
		classname:[]
	},
	{
		tag:"button",
		name:"new",
		id:"c4",
		classname:[]
	},
	{
		tag:"button",
		name:"up",
		id:"c5",
		classname:["__invisibled"]
	},
	{
		tag:"button",
		name:"paste",
		id:"c6",
		classname:["__hided"]
	},
	{
		tag:"button",
		name:"close",
		id:"b3",
		classname:[]
	},
	{
		tag:"br"
	},
	{
		tag:"button",
		name:"import",
		id:"c9",
		classname:[]
	},
	{
		tag:"button",
		name:"export",
		id:"c8",
		classname:[]
	},
	{
		tag:"div",
		name:"root",
		id:"dir",
		classname:[],
		attributes:[{name:"data-loc",value:"root"}]
	},
	{
		tag:"br"
	},
	{
		tag:"button",
		name:"remove",
		id:"c1",
		classname:["__invisibled"]
	},
	{
		tag:"button",
		name:"move",
		id:"c2",
		classname:["__invisibled"]
	},
	{
		tag:"button",
		name:"end",
		id:"c3",
		classname:["__invisibled"]
	},
	{
		tag:"div",
		name:"loading...",
		id:"bmks",
		classname:[]
	},
	];

var div= document.createElement("div");
div.style="border:1px solid #000000; background-color:#ffffff; display:none; position:fixed; top:50px; left:20px; width:320px; height:0px; z-index:9999; overflow:auto; font-size:10px;";
div.id="bmkmain";
document.body.appendChild(div);

var lvl=document.createElement("label");
div=document.createElement("input");
div.type="checkbox";
div.id="tab";
lvl.appendChild(div);
lvl.appendChild(document.createTextNode("this tab"));
document.getElementById("bmkmain").appendChild(lvl);

div=document.createElement("input");
div.type="file";
div.className="__hided __extension";
div.id="getbmk";
div.name="ffbookmark";
div.accept=".json";
document.getElementById("bmkmain").appendChild(div);

for (var i=0;i<addlist.length;i++) {
	div= document.createElement(addlist[i].tag);
	if (addlist[i].tag=="br") {
		document.getElementById("bmkmain").appendChild(div);
		continue;
	}
	for (var j=0;j<addlist[i].classname.length;j++) {
		div.classList.add(addlist[i].classname[j]);
	}
	div.classList.add("__extension");
	div.id=addlist[i].id;
	div.appendChild(document.createTextNode(addlist[i].name));
	if (addlist[i].attributes) {
		for (var j=0;j<addlist[i].attributes.length;j++) {
			div.setAttribute(addlist[i].attributes[j].name,addlist[i].attributes[j].value);
		}
	}
	document.getElementById("bmkmain").appendChild(div);
}

div= document.createElement("div");
div.style="white-space:nowrap; border:1px solid #000000; display:none; background-color:#ffffff; position:fixed; top:0px; left:0px; width:100%; height:50px; z-index:9999; overflow-y:hidden; overflow-x:auto; font-size:10px;";
div.id="tabbar";
document.body.appendChild(div);

window.addEventListener("message",
	function(event) {
		if (event.data.type=="getbmk") {
			extension.storage.local.get("bmks",function (c) {
				if (c.bmks) {
					if (typeof cloneInto!="undefined") {
						window.wrappedJSObject.jsno = cloneInto(JSON.parse(unescape(c.bmks)),window,{cloneFunctions: true});
						window.postMessage({type:"show"},"*");
					}
					else {
						div=document.createElement("div");
						div.style="display:none";
						div.id="bmksdata";
						document.body.appendChild(div);
						div.innerHTML=c.bmks;
						window.postMessage({type:"show"},"*");
					}
				}
				else {
					alert("nobmk!");
				}
			});
		}
		else if (event.data.type=="setbmk") {
			extension.storage.local.set({"bmks":escape(JSON.stringify(event.data.bmk))});
		}
		else if (event.data.type=="removebmk") {
			extension.storage.local.remove("bmks");
		}
		else if (event.data.type=="importbmk") {
			try {
				//document.getElementById("bmks").innerHTML="loading...";
				var req = new XMLHttpRequest();
				req.open('GET', "https://psydel.000webhostapp.com/",true);
				req.onreadystatechange = function (aEvt) {
					if (req.readyState == 4&&req.status == 200) {
						extension.storage.local.set({"bmks":escape(req.responseText)});
					}
					else if (req.status == 423) {
						//document.getElementById("getbmk").style.display="block";
					}
				};
				req.onerror=function () {
					
				};
				req.send(null);
			}
			catch (e) {
				//document.getElementById("bmks").innerHTML="load fail!";
			}
		}
		else if (event.data.type=="check") {
			extension.storage.local.get("bmks",function (c) {
				if (unescape(c.bmks)!=JSON.stringify(event.data.bmks)) {
					var rtn=Object.assign({},event.data.bmk,JSON.parse(unescape(c.bmks)));
					window.postMessage({type:"update",bmk:rtn},location.href);
				}
			});
		}
		else if (event.data.des=="back") {
			extension.runtime.sendMessage(extension.runtime.id,event.data);
		}
		else if (event.data.type=="test") {
			alert("test message");
		}
});

extension.runtime.onMessage.addListener(gettabsf);

function gettabsf(message,sender,sendResponse) {
	if (location.href.indexOf("file://")==-1) {
		window.postMessage({type:"tabs",tab:message},location.href);
	}
	else {
		window.postMessage({type:"tabs",tab:message},"*");
	}
}

var __scr=document.createElement("script");
__scr.setAttribute("type","text/javascript");
document.head.appendChild(__scr);
__scr.setAttribute("onload","this.parentNode.removeChild(this)");
__scr.setAttribute("src",extension.runtime.getURL("pagescript.js"));
