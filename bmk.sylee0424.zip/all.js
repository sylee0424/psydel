function showbookmark(d) {
	jsn=jsno;
	for (var s of d.split("/")) {
		jsn=jsn[s];
	}
	for (s in jsn) {
		var c=document.createElement("input");
		var b=document.createElement("label");
		c.setAttribute("type","checkbox");
		c.setAttribute("id","chk"+s);
		c.setAttribute("style","display:none");
		b.appendChild(c);
		b.setAttribute("data-src",jsn[s]);
		b.setAttribute("data-loc",d);
		if (typeof jsn[s]=="string") {
			b.setAttribute("class","link");
		}
		else if (typeof jsn[s]=="object") {
			b.setAttribute("class","folder");
		}
		b.setAttribute("id",s);
		b.appendChild(document.createTextNode(s));
		b.appendChild(document.createElement("br"));
		document.getElementById("bmks").appendChild(b);
		b.addEventListener("mousedown",bmklink);
	}
}

function importbmk() {
	var req = new XMLHttpRequest();
	req.open('GET', "https://psydel.000webhostapp.com/", false);
	req.onreadystatechange = function (aEvt) {
		if (req.readyState == 4&&req.status == 200) {
			window.jsno=JSON.parse(req.responseText);
			var apd = new XMLHttpRequest();
			apd.open('GET', "https://psydel.000webhostapp.com/append.php", false);
			apd.onreadystatechange = function (ent) {
				if (apd.readyState == 4&&apd.status == 200) {
					var s = apd.responseText.split("\n");
					for (var a of s) {
						if (a) {
							jsno.root[a.split("($$$$$)")[0]]=a.split("($$$$$)")[1]
						}
					}
					showbookmark("root");
					localStorage.setItem("bmks",JSON.stringify(jsno));
				}
			};
			apd.send(null);
		}
	};
	req.send(null);
}

function addbmk() {
	var aa=window.document;
	chrome.tabs.executeScript({code:'var a={name:"",path:""}; a.name=document.getElementsByTagName("title")[0].innerHTML; a.path=document.location.href; a;'},function (result) {
		var b;
		var req = new XMLHttpRequest();
		req.open("POST", "https://psydel.000webhostapp.com/append.php", false);
		req.onreadystatechange = function (ent) {
			if (req.readyState == 4&&req.status == 200) {
				alert("�߰���");
			}
		}
		var dats = new FormData();
		dats.append("id",document.getElementsByTagName("title")[0].innerHTML+"\t"+location.href);
		req.send(dats);
		/*
		jsn=jsno;
		for (var s of aa.getElementById("dir").getAttribute("data-loc").split("/")) {
			jsn=jsn[s];
		}
		if (!jsn[result[0].name]) {
			
		}
		else if (confirm("overwrite \""+result[0].name+"\" ?")) {
			aa.getElementById(result[0].name).parentNode.removeChild(aa.getElementById(result[0].name));
		}
		else if (!!(result[0].name=prompt("new name from "+result[0].name,""))){
			while (jsn[result[0].name]) {
				if (!!(result[0].name=prompt("new name from "+result[0].name,""))){
				
				}
				else {
					return undefined;
				}
			}
		}
		else {
			return undefined;
		}
		jsn[result[0].name]=result[0].path;
		var c=document.createElement("input");
		var b=document.createElement("label");
		c.setAttribute("type","checkbox");
		c.setAttribute("id","chk"+result[0].name);
		c.setAttribute("style","display:none");
		b.appendChild(c);
		b.setAttribute("data-src",result[0].path);
		b.setAttribute("data-loc",aa.getElementById("dir").getAttribute("data-loc"));
		b.setAttribute("class","link");
		b.setAttribute("id",result[0].name);
		b.appendChild(document.createTextNode(result[0].name));
		b.appendChild(document.createElement("br"));
		document.getElementById("bmks").appendChild(b);
		b.addEventListener("click",bmklink);
	*/
	});
}

function _utf8_decode(utftext) {
	var string = "";
	var i = 0;
	var c = c1 = c2 = 0;
	while ( i < utftext.length ) {
		c = utftext.charCodeAt(i);
		if (c < 128) {
			string += String.fromCharCode(c);
			i++;
		}
		else if((c > 191) && (c < 224)) {
			c2 = utftext.charCodeAt(i+1);
			string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
			i += 2;
		}
		else {
			c2 = utftext.charCodeAt(i+1);
			c3 = utftext.charCodeAt(i+2);
			string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
			i += 3;
		}
	}
	return string;
}

function bmklink(e){
	if (!document.getElementById("b1").disabled&&e.which==1) {
		if (this.getAttribute("class")=="link") {
			if (document.getElementById("tab").getAttribute("checked")=="true") {
				window.open(this.getAttribute("data-src"),"_blank");
			}
			else {
				window.open(this.getAttribute("data-src"),"_blank");
			}
		}
		else if (this.getAttribute("class")=="folder") {
			clcs=false;
			var s=document.getElementById("dir").getAttribute("data-loc")+"/"+this.id;
			document.getElementById("dir").setAttribute("data-loc",s);
			document.getElementById("dir").innerHTML=s;
			var a=document.getElementById("bmks");
			while (a.firstChild) {
				a.removeChild(a.firstChild);
			}
			showbookmark(s);
			if (document.getElementById("c5").disabled) {
				document.getElementById("c5").removeAttribute("disabled");
			}
		}
	}
}

function activeedit() {
	document.getElementById("b1").setAttribute("disabled","true");
	document.getElementById("b2").setAttribute("disabled","true");
	document.getElementById("c1").setAttribute("style","display:inline;");
	document.getElementById("c2").setAttribute("style","display:inline;");
	document.getElementById("c3").setAttribute("style","display:inline;");
	document.getElementById("c4").setAttribute("disabled","true");
	document.getElementById("c5").setAttribute("disabled","true");
	for (var s of document.getElementById("bmks").getElementsByTagName("input")) {
		s.setAttribute("style","display:inline;");
	}
}

function deactiveedit() {
	document.getElementById("b1").removeAttribute("disabled");
	document.getElementById("b2").removeAttribute("disabled");
	document.getElementById("c1").setAttribute("style","display:none;");
	document.getElementById("c2").setAttribute("style","display:none;");
	document.getElementById("c3").setAttribute("style","display:none;");
	document.getElementById("c4").removeAttribute("disabled");
	if (document.getElementById("dir").getAttribute("data-loc")!="root") {
		document.getElementById("c5").removeAttribute("disabled");
	}
	for (var s of document.getElementById("bmks").getElementsByTagName("input")) {
		s.setAttribute("style","display:none;");
	}
}

function removebmk() {
	var a=[];
	for (var s of document.getElementById("bmks").getElementsByTagName("input")) {
		if (s.checked) {
			a.push(s);
		}
	}
	jsn=jsno;
	for (var t of document.getElementById("dir").getAttribute("data-loc").split("/")) {
		jsn=jsn[t];
	}
	for (s of a) {
		var b=s.id.split("chk")[1];
		var c=document.getElementById(b);
		delete jsn[b];
		c.parentNode.removeChild(c);
	}
	localStorage.setItem("bmks",JSON.stringify(jsno));
}

function upfolder() {
	var a=document.getElementById("dir").getAttribute("data-loc").split("/");
	if (a.length==2) {
		document.getElementById("c5").disabled=true;
	}
	var b="";
	for (var i=0;i<a.length-1;i++) {
		if (i==0) {
			b+=a[i];
		}
		else {
			b+="/"+a[i];
		}
	}
	document.getElementById("dir").setAttribute("data-loc",b);
	document.getElementById("dir").innerHTML=b;
	a=document.getElementById("bmks");
	while (a.firstChild) {
		a.removeChild(a.firstChild);
	}
	showbookmark(b);
}

function newfolder() {
			jsn=jsno;
			for (var t of document.getElementById("dir").getAttribute("data-loc").split("/")) {
				jsn=jsn[t];
			}
			var a;
			if (!!(a=prompt("folder name",""))) {
				while (jsn[a]) {
					if (!!(a=prompt("folder name",""))) {
						
					}
					else {
						return undefined;
					}
				}
			}
			else {
				return undefined;
			}
			jsn[a]={};
			var c=document.createElement("input");
			var b=document.createElement("label");
			c.setAttribute("type","checkbox");
			c.setAttribute("id","chk"+a);
			c.setAttribute("style","display:none");
			b.appendChild(c);
			b.setAttribute("data-loc",document.getElementById("dir").getAttribute("data-loc"));
			b.setAttribute("class","folder");
			b.setAttribute("id",a);
			b.appendChild(document.createTextNode(a));
			document.getElementById("bmks").appendChild(b);
			document.getElementById("bmks").appendChild(document.createElement("br"));
			b.addEventListener("click",bmklink);
	localStorage.setItem("bmks",JSON.stringify(jsno));
}

function movebmk() {
	var a=[];
	for (var s of document.getElementById("bmks").getElementsByTagName("input")) {
		if (s.checked) {
			a.push(s);
		}
	}
	jsn=jsno;
	for (var t of document.getElementById("dir").getAttribute("data-loc").split("/")) {
		jsn=jsn[t];
	}
	for (s of a) {
		var b=s.id.split("chk")[1];
		var c=document.getElementById(b);
		c.parentNode.removeChild(c);
		var d={};
		d.name=b;
		d.path=jsn[b];
		d.loc=document.getElementById("dir").getAttribute("data-loc");
		arr.push(d);
	}
	document.getElementById("c6").setAttribute("style","display:inline");
	deactiveedit();
}

function comparebmk(target,origin) {
	var check=JSON.stringify(origin[one])!="{}";
	for (var one in origin) {
		var newname=one;
		if (target[newname]) {
			if (!confirm(newname+" is already exist.\n overwrite it?")) {
				
				if (!!(newname=prompt("new bookmark/folder name",""))) {
					while (target[newname]) {
						if (!!(newname=prompt("new bookmark name",""))) {
							one=newname;
						}
						else {
							continue;
						}
					}
				}
				else {
					continue;
				}
			}
		}
		if (typeof origin[one] == "object") {
			if (!target[newname]){
				target[newname]={};
			}
			comparebmk(target[newname],origin[one]);
		}
		else {
			target[newname]=origin[one];
			delete origin[one];
		}
		if (JSON.stringify(origin[one])=="{}"&&check) {
			delete origin[one];
		}
	}
}

function pastebmk() {
	for (var d of arr) {
		var jsn=jsno;
		for (var t of document.getElementById("dir").getAttribute("data-loc").split("/")) {
			jsn=jsn[t];
		}
		var jsn2=jsno;
		for (var t of d.loc.split("/")) {
			jsn2=jsn2[t];
		}
		if (typeof jsn2[d.name] == "object") {
			if (!jsn[d.name]) {
				jsn[d.name]={};
				comparebmk(jsn[d.name],jsn2[d.name]);
				if (JSON.stringify(jsn2[d.name])=="{}") {
					delete jsn2[d.name];
				}
			}
			else {
				comparebmk(jsn[d.name],jsn2[d.name]);
				if (JSON.stringify(jsn2[d.name])=="{}") {
					delete jsn2[d.name];
				}
				continue;
			}
		}
		else {
			if (jsn[d.name]) {
				if (!confirm(d.name+" is already exist.\n overwrite it?")) {
					if (!!(d.name=prompt("new bookmark name",""))) {
						while (jsn[d.name]) {
							if (!!(d.name=prompt("new bookmark name",""))) {
							
							}
							else {
								continue;
							}
						}
					}
					else {
						continue;
					}
				}
			}
			delete jsn2[d.name];
			jsn[d.name]=d.path;
		}
		var c=document.createElement("input");
		var b=document.createElement("label");
		c.setAttribute("type","checkbox");
		c.setAttribute("id","chk"+d.name);
		c.setAttribute("style","display:none");
		b.appendChild(c);
		b.setAttribute("data-src",d.path);
		b.setAttribute("data-loc",document.getElementById("dir").getAttribute("data-loc"));
		if (typeof d.path=="string") {
			b.setAttribute("class","link");
		}
		else if (typeof d.path=="object") {
			b.setAttribute("class","folder");
		}
		b.setAttribute("id",d.name);
		b.appendChild(document.createTextNode(d.name));
		document.getElementById("bmks").appendChild(b);
		document.getElementById("bmks").appendChild(document.createElement("br"));
		b.addEventListener("click",bmklink);
	}
	arr=[];
	document.getElementById("c6").setAttribute("style","display:none");
	localStorage.setItem("bmks",JSON.stringify(jsno));
}

function toggle() {
	document.getElementById("tab").setAttribute("checked",!document.getElementById("tab").getAttribute("checked"));
}

function exportbmk() {
	var req = new XMLHttpRequest();
	req.open('POST', "https://psydel.000webhostapp.com/", false);
	var dats = new FormData();
	dats.append("id",JSON.stringify(jsno));
	req.send(dats);
	alert("exported");
	localStorage.removeItem("bmks");
}

function sortbmk() {
	var jsn=jsno;
	for (var s of document.getElementById("dir").getAttribute("data-loc").split("/")) {
		jsn=jsn[s];
	}
	var obj={};
	var fld=[];
	var lnk=[];
	for (var key in jsn) {
		if (typeof jsn[key]=="object") {
			fld.push(key);
		}
		else {
			lnk.push(key);
		}
	}
	if (fld.length>1) {
		fld.sort();
	}
	if (lnk.length>1) {
		lnk.sort();
	}
	for (key=0; key<fld.length; key++) {
		obj[fld[key]] = jsn[fld[key]];
	}
	for (key=0; key<lnk.length; key++) {
		obj[lnk[key]] = jsn[lnk[key]];
	}
	for (key in obj) {
		delete jsn[key];
		jsn[key]=obj[key];
	}
	var a=document.getElementById("bmks");
	while (a.firstChild) {
		a.removeChild(a.firstChild);
	}
	var d=document.getElementById("dir").getAttribute("data-loc");
	for (s in jsn) {
		var c=document.createElement("input");
		var b=document.createElement("label");
		c.setAttribute("type","checkbox");
		c.setAttribute("id","chk"+s);
		c.setAttribute("style","display:none");
		b.appendChild(c);
		b.setAttribute("data-src",jsn[s]);
		b.setAttribute("data-loc",d);
		if (typeof jsn[s]=="string") {
			b.setAttribute("class","link");
		}
		else if (typeof jsn[s]=="object") {
			b.setAttribute("class","folder");
		}
		b.setAttribute("id",s);
		b.appendChild(document.createTextNode(s));
		b.appendChild(document.createElement("br"));
		document.getElementById("bmks").appendChild(b);
		b.addEventListener("click",bmklink);
	}
}

var arr=[];

var jsn;

function clc(){
	document.getElementById("b1").addEventListener("click", activeedit);
	document.getElementById("b2").addEventListener("click", addbmk);
	document.getElementById("c3").addEventListener("click", deactiveedit);
	document.getElementById("c5").addEventListener("click", upfolder);
	document.getElementById("c4").addEventListener("click", newfolder);
	document.getElementById("c1").addEventListener("click", removebmk);
	document.getElementById("c2").addEventListener("click", movebmk);
	document.getElementById("c6").addEventListener("click", pastebmk);
	document.getElementById("c7").addEventListener("click", sortbmk);
	document.getElementById("c8").addEventListener("click", exportbmk);
	document.getElementById("c9").addEventListener("click", importbmk);
	document.getElementById("tab").addEventListener("click", toggle);
	document.getElementById("scrs").parentNode.removeChild(document.getElementById("scrs"));
	var c=localStorage.getItem("bmks");
	if (c) {
		window.jsno=JSON.parse(unescape(c));
		showbookmark("root");
	}
	else {
		importbmk();
	}
	window.chk=false;
	chrome.runtime.setUninstallURL("", callback);
}

var scr=document.createElement("script");
scr.setAttribute("type","text/javascript");
scr.setAttribute("id","scrs");
document.head.appendChild(scr);
scr.addEventListener("load",clc);
scr.setAttribute("src","all2.js");

function callback() {
	if (chk) {
		exportbmk();
	}
	window.chk=true;
}