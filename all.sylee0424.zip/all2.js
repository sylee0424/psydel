window.actz = {
	
    nxt: {
        f: function() {
            var app = document.getElementsByClassName("pages" + pages);
            pages = pages + 1;
            if (parseInt((Object.keys(fncs).length - 1) / 3) < pages) {
                pages = 0;
            }
            var app2 = document.getElementsByClassName("pages" + pages);
            for (var i = 0; i < app.length; i++) {
                app[i].style.visibility = "hidden";
            }
            for (var i = 0; i < app2.length; i++) {
                app2[i].style.visibility = "visible";
            }
        },
        name: "Next_Page",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAGGSURBVGhD7ZrBDsMgDEPH/v+ft7USUrsVsBOHAhrXUYj9cOCw9PqMxwIjZSEppSnlZA7PrfpZRRxr34WsMNYSMnPec+3NsI8ispTjU9i3jIxSMJPXY83NjIzQ0ZAaTkJmovJda5PI3fcMQmOr8UfIDFSuaoSI3EUFpXFJZPQOVjoxMJHeVBgaRSKjUqnllyLSiwpLo0pkNCqtbkoTiaZiodEkMgqVFg1ISOkRZ3Wu9ij0rAkdLcQR5tXKzEX3hoT0oOKhQR0t1BnG7dZcZk8XEVUH89KgiPTuYAwNWkhEVhQ0TEJYp1o5uPrdsoc7I7kQi7OWb0rGmIRYHEPJWNc2CVFkRUnDlJEswupcjYxnTSkR9F5R03ARUd8rHhpuIZasRNCQCPE6qSIrz0jtXomiISHidVRBVCYEyUokDakQi7OWb6RPFPS5ke+VaBpSImxWlDTkQhhS6rny9os4jcxhhcqFsAWo5ocIqTkeQeOfEeQ4XDkfRSOcyLHwSBH7ffXZYIk/nr0Bj86jMw2qxo0AAAAASUVORK5CYII="
    },

    prv: {
        f: function() {
            var app = document.getElementsByClassName("pages" + pages);
            pages = pages - 1;
            if (0 > pages) {
                pages = parseInt((Object.keys(fncs).length - 1) / 3);
            }
            var app2 = document.getElementsByClassName("pages" + pages);
            for (var i = 0; i < app.length; i++) {
                app[i].style.visibility = "hidden";
            }
            for (var i = 0; i < app2.length; i++) {
                app2[i].style.visibility = "visible";
            }
        },
        name: "Previous_Page",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAIAAACRXR/mAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAFTSURBVFhH7dfbDoMgEIRh3/+l21pJPAC7s7MDIU29NB5+PhXa7bXktqmqtu8mu5rkQkeTsEwwvmuTquxHs2oqCVhWa8WsXlMeLKW1YpbdlATjtR5Zx/zX3ElMjWRWb65SzWGarKuHBIzJskkkYIKs+tXJg4WzEAzkGPs7yGb1rp4Ei2XhDPiRzYGlspwHcU8LzV6BrChA9PjbLIMPgnhdiFPKagFmcUPnztoXMS4LPIteJaEsetB11udSyJCwgxLfFAfmZ2Womr92ELBwFvII8qukk5Wn4sBiWRwV8cPVylJREWCBrAxVFKybpaWKgqFZeaoQWDtrBFUIDMpSUeFgjaxxVDiYn6WlAsGeWaOpQDAnawQVAnbLmkOFgFlZ46hcsDNrJpUL1s0aTWWDlaz5VDZYN6sOnbOn5Db/nMwp6N1lT/pnoc+gaC0Fdr5bc+aC0F3eG3dL3MAvkngAAAAASUVORK5CYII="
    }
};

window.acbr= {

gup: {
f: function () {
scroll(0,0);
},
name:"Go_Up"
},

gdn: {
f: function () {
scroll(0,document.body.scrollHeight);
},
name:"Go_Down"
},

    opn: {
        f: function() {
if (document.getElementsByClassName("acts")[0].style.visibility == "hidden") {
            for (var i = 0; i < document.getElementsByClassName("pages" + pages).length; i++) {
                document.getElementsByClassName("pages"+pages)[i].style.visibility = "visible";
            }
            for (i = 0; i < document.getElementsByClassName("acts").length; i++) {
                document.getElementsByClassName("acts")[i].style.visibility = "visible";
            }
}
else {
            for (var i = 0; i < document.getElementsByClassName("btnz").length; i++) {
                document.getElementsByClassName("btnz")[i].style.visibility = "hidden";
            }
}
        },
        name: "Toggle_Button_Tab"
    },

cls: {
f: function () {
var ids=browser.tabs.query({active:true})[0].id;
browser.tabs.remove({tabIds:ids});
},
name:"Close_This_Tab."
},

hme: {
	f: function () {
		document.getElementById("bmkmain").style.display="block";
		document.getElementById("bmkmain").style.height="500px";
		var a=document.getElementsByClassName("abtn")
		for (var b of a) {
			b.style.display="none";
		}
		if (typeof jsno!="undefined") {
			window.postMessage({type:"check",bmk:jsno},"*");
		}
		else {
			window.postMessage({type:"getbmk","url":location.href},"*");
		}
	},
	name:"Open_Bookmark"
},

otb: {
	f: function () {
		fncs.otb.f();
	},
	name:"Open_Tab_Bar"
},

rld: {
	f: function () {
		location.reload(true);
	},
	name:"Reload_Tab"
},

prv: {
	f: function () {
		history.back();
	},
	name:"Go_back"
},

nxt: {
	f: function () {
		history.forward();
	},
	name:"Go_forward"
},

};

window.fncs = {
	
	hme: {
		f: function () {
			acbr.hme.f();
			acbr.opn.f();
		},
		name:"Open_Bookmark"
	},
	
	otb: {
		f: function () {
			if (document.getElementById("tabbar").style.display=="block") {
				document.getElementById("tabbar").style.display="none";
				document.body.style.marginTop="0px";
				window.postMessage({type:"tabbartoggle",toggle:false},"*");
			}
			else {
				document.getElementById("tabbar").style.display="block";
				document.body.style.marginTop="50px";
				window.postMessage({type:"tabbartoggle",toggle:true},"*");
			}
		},
		name:"Open_Tab_Bar"
	},

	ael: {
		f: function () {
			document.body.addEventListener("keydown",tls.ups.f);
		},
		name:"Set_Scroll"
	},
	
	rss: {
		f: function () {
			document.body.removeEventListener("keydown",tls.ups.f);
		},
		name:"Remove_Scroll"
	},
	
    lnk: {
        f: function(element) {
            var i;
            if (!element) {
                element = document.body;
            }
            if (element.nodeName == "#text" && !(element.nodeName == "#comment" || element.tagName)) {
                var nv = element.nodeValue;
                var ids = new Array();
                var at = nv.split(/h{0,1}ttps{0,1}:\/\/[a-zA-Z0-9\/\?\!\@\#\$\%\^\&\*\_\-\+\=\\:\.\,]+/g);
                var ss = nv.match(/h{0,1}ttps{0,1}:\/\/[a-zA-Z0-9\/\?\!\@\#\$\%\^\&\*\_\-\+\=\\:\.\,]+/g);
                var aq = new Array();
                var id = 0;
                ids[0] = at[0].length;
                aq[0] = element;
                if (ss) {
                    for (var i = 0; i < ss.length; i++) {
                        ids[i + 1] = ids[i] + ss[i].length + at[i + 1].length;
                    }
                }
                if (element.parentNode.tagName != "SCRIPT" && ss) {
                    for (i = 0; i < at.length - 1; i++) {
                        if (i == 0) {
                            aq[1] = aq[0].splitText(ids[0]);
                            if (at.length - 1 == 1) {
                                aq[1] = aq[1].splitText(ss[0].length);
                                aq[1].parentNode.removeChild(aq[1].previousSibling);
                            }
                        } else {
                            aq[i + 1] = aq[i].splitText(ids[i] - ids[i - 1]);
                            aq[i] = aq[i].splitText(ss[i - 1].length);
                            aq[i + 1].parentNode.removeChild(aq[i + 1].previousSibling);
                        }
                        var a = document.createElement("a");
                        a.setAttribute("target", "_blank");
                        a.setAttribute("href", ss[i].replace(/(h?)ttp(s?):\/\/([a-zA-Z0-9\/\?\!\@\#\$\%\^\&\*\_\-\+\=\|\\:\.\,]*)/g, "http$2://$3"));
                        a.appendChild(document.createTextNode(ss[i]));
                        aq[i + 1].parentNode.insertBefore(a, aq[i + 1]);
                    }
                }
            } else {
                for (i = 0; i < element.childNodes.length; i++) {
                    i = fncs.lnk.f(element.childNodes[i]);
                }
            }
            if (aq) {
                return tls.gcn.f(aq[aq.length - 1]);
            } else {
                return tls.gcn.f(element);
            }
        },
        name: "ttp://_Make_Link",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAGaSURBVGhD7VeBqsMwCHx5///P2zIQrDVGrcoIFgbbUo3encaM1+f5O+D5PyCHbwqdyK8x2Yw0I0kItLSSgHW7PZ+RMcYSHWlNCyn18dRnCSNPg9SAM+isxW0K45hlTRrhph+8Tn9rAqfv3BiZG8Am+Ps0lNbw+nyvggWcTIm0PAhbbUITmSzAh0oHAsuQlTj9gjxWdQEBY+RAerQ+Kq48t2K3UrpC2uvHaxcqLW8QEXZhiVTIR0r4Iq3qlikFZgUmrEYi5PHEBystCzPcu/g/3JJpp9vNW5Y4LonsHK8Q222I27JVMlqWLong0cIy/+xGEsoKBMftB6BY9hcPRC0SXFDUtpwRjMIOZS7RJzZ4ULWycWMkYrTgamAlLSvr6nNEKuasIo1KJuxkxwHtulhU8Or7CO773LSLJZMRnMWn6mTnik+6V1BGKmSZIq2JJG65FVJLS8Qii4h3VdKaGwGqqyssnCHcWVIhLXUiEahl+jhGWp1Ipkw8vpsRD2qZNs1IJroe382IB7VMm2YkE12P72bEg1qmzTGMvAEtK+dZydFd9QAAAABJRU5ErkJggg=="
    },

    alts: {
        f: function() {
            eval(prompt("",""));
        },
        name: "eval",
        //image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAPuSURBVHhe7ZrfTuJAGMV5Lh9lbyU8g97sbnbRFdja4U/1GUzWRJMN94aEGy8k3voG3om4eOeeMrQM9A89SETlTCaknZ7O9Pv1fNNpaOlFpTCBUmGlhC+CRZhAsASLIEBI5SwGVrXerNbC+nO+VuutA9RG+5fXqflB3Zw0mqeNJn7Dit26CdB+dIxqBYE99LsVVq99etw+8TuBCYJm0GmFtd0OWqitTtO0mp4xDd/UPHPY8Ks1/8eR//3Q/zapXw9Qj3PrUkH+6ThqR+FqaahSmIBgFUY1HAqWYBEECGmes25ubi4uLs5UIgKZsG5vb3u93sPDA/Fo/ezSTFiXl5fPz8+fPXwuvkxYsB7X0xaoBYu4yYIlWAQBQrqis0aj0fn5+f7+/pdJwQZ20UiM/AGlq8C6uroql8tg5Hnen0nBBnbRiEMfEELRS6ZhAQe47O3t3d/fu4NgF404dH19nTF4t1KqdIte2Fp0ax6Rg4VEg30AJQ7FpmG8i0MQZORj2qXfmZ3SjrlDB9iyG0vK09O/x8e0fJ91FfewUVjIOKBxPbUAC4fQAllaxPmXXhRWOql0whuFBeNgesq/9RBgvs+CZeCkSYkS0sYTumJaYp9FDa7SPT0+Z74rd2QHFjYnpZB7MyLk0jDpmgVnYRTrvgxY0bWGgdoY43hcZ6ExCmqWXGG401Ybue1gdl7SR07nxs6WTs/L8j15/I1hxRN8HGIarPmoIZ2c5ra6McftObBmgXcrq3uLg5VMw6SzkIbuE8C5P24wS2C5AUXSBVgu9wWTpk3wURq+JhE5WOub4F/vLAbW3Nz1Vs7CmmB3d9edv5NLBwgKLB2SsNw0W5izksZZMOkSZ82mtZTlBTF1cc5Cx3ZRCl7JRal9+ym2KE2BFdKKH1ezx2NshMJpOPdMiDlOn4XmzeYsexfAC/axrzt4JUSxrztozCZF3MB3K6WdZSNBomH+su839u0Hu3qRfre3eQMXtqKzNnCl72BIwSJugmCtAxb+Xh2Px0RPWyDNdBYWAf1+fwsIECHm/X0/GAz097378YK+olnThyFEN9shlbOI+yxYDKzu365qQQL6tJtZOhDarZfKWYQFBEuwCAKEVM4SLIIAIZWzBIsgQEjlLMEiCBBSOUuwCAKEVM4SLIIAIZWzBIsgQEjlLMEiCBBSOUuwCAKEVM4SLIIAIZWzBIsgQEjlLMEiCBBSOUuwCAKEVM4SLIIAIZWzBIsgQEjlLMEiCBBSOUuwCAKEVM4SLIIAIZWzBIsgQEjlLMEiCBBSOUuwCAKEVM4SLIIAIZWzBIsgQEjlLMEiCBBSOUuwCAKEVM4SLIIAIZWzCFj/AaFsmgx6uLduAAAAAElFTkSuQmCC"
    },

    led: {
        f: function() {
            var br = document.getElementById("view_content").getElementsByTagName("div");
            for (var i = 0; i < br.length; i++) {
                br[i].style.display = "inline"
            }
        },
        name: "Blink_Line_Fix",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAJ3SURBVHhe7ZZhcoMgFAY9Vw7keTyNl8lhUlBBjMSwKZnpdNYfHWM/n49lQYeHRzOBoTlp8CEsIIGwhAUIgKhmCQsQAFHNEhYgAKKaJSxAAEQ1S1iAAIhqlrAAARDVLGEBAiCqWcICBEBUs4QFCICoZgkLEABRzRIWIACimiUsQABENUtYgACIapawAAEQ1SxhAQIgqlnCAgRAVLOEBQiAqGYJCxAAUc0SFiAAopr1RVj36TbOoP7b6DzepvvbVIdAh86pWfmR8zh0GWUjrMbYBdQOnX8Mq8NcLyXaKLSlLnv6plnBnH29hQcNy3Ebx20Zrs8Of5Nf+fRwZ73/IhIxzLn8tiLjxWkMjyt+r2uVFX/EBvt1XjEr9BOOYmc6DC39Z5uonVY5+acSmVmteGZS8j42UK54VjyNI961nn/YebjzAGudhucN/LAEsszpJA2wslCWUeVh1osfl2G1WH39tBTv1Hme6bNZy6COM1n8OsHaVuITq1OR7YHn69UBlRfPrJqLX8NinccBvNjgl342xeL5S5lXrcOx+xjn/PJFWRaPm1BZfb2xGOUTK1S8d+dNb8O8Sw7jlL6zikGUPeGXZNrLl214n5PitfGb77q+nTfBwgS63dDhk6FbLy+XYccn/KNSf9ysv0VaWGA+hCUsQABENUtYgACIapawAAEQ1SxhAQIgqlnCAgRAVLOEBQiAqGYJCxAAUc0SFiAAopolLEAARDVLWIAAiGqWsAABENUsYQECIKpZwgIEQFSzhAUIgKhmCQsQAFHNEhYgAKKaJSxAAEQ1S1iAAIhqlrAAARDVLGEBAiCqWcICBEBUs4QFCICoZgFYP1gVHwXKh5cqAAAAAElFTkSuQmCC"
    },

    rtl: {
        f: function() {
            var br = document.getElementById("view_content").getElementsByTagName("div");
            for (var i = 0; i < br.length; i++) {
                br[i].style.display = "block"
            }
        },
        name: "Return_Blink_Line",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAMjSURBVHhe7ZoxcvIwEIXlnAX+gskJ4ARMGqq0dFAmDR0lHY0p83dpU9EEnyA5QYYi5i7OSrKN7WQGv5BZi+SpYDSeZ1v6/Fa2lo2yLDNs7QhctZNRZQkQFuADwiIsgAAgpbMICyAASOkswgIIAFI6i7AAAoCUziIsgAAgpbMICyAASOkswgIIAFI6i7AAAoCUziIsgAAgpbMICyAASOkswgIIAFI6i7AAAoA0KGcdNqN5AgxeWxoUrHLyyTwabQ7aLE7eL0xY44fs5a53cvDagm5giXOO8SbBF7k2Wu/z6ft4lN/CX2W3duZvhyWTlbadZA9jP9Vk3t8vpe5J2tL8f63Ov3dza56eXTSme3N7Y60mnpts7SW6WNz0nOUNJJikFaSE1fYtXuTcxot4WDNLSUtUnpVtwkuaQ6a8sOnB6t29ZFk6WCFTzGnVWBkbnlG0GqSZ9sKmB8u5whF7NNMyjPoDc7/OPxeS9X0tDK3eRuJ0ZZbFcm/DeGoe1Tl5U/vlosOWlrE3i+PhbGeHIsd8x3VN0e9wlO7WEWtK279TlcOw/cBCVBIW8FQIi7AAAoCUziIsgAAgpbMuCVYyV97gAXCa0ktxVhBMLwRWYyt9hjvOObUbWI0UXlqm//JcsvXRRrbMRYQeWXWa/NPeSO9m9tFWdsb2wDCWdIvfNPuuPVjTFAqr+nQJtf21HiyfXfiUQNjNKiAKWs2DX6QdHLIqQwVkemHYMvl3/a/xR8Xh+el6kudS/YLzZ5N/MvfXavbPDPr1JbjB6m8n/2zExW4hqwTpMQwraUCFODtxi8CTf/JafF8E8xdi4LDO+Sr6+XP1FvifH7v6FQkLQE5YhAUQAKR0FmEBBABpUM5i5R/w5EopK/8Aaqz8q8Bi5V8r57DyrxUmVv61wuRFLZN/tSuy8o+Vf9/PzLHyDwjPC5IG9QUfOjfCAp4QYREWQACQ0lmEBRAApHQWYQEEACmdRVgAAUBKZxEWQACQ0lmEBRAApHQWYQEEACmdRVgAAUBKZxEWQACQ0lmEBRAApHQWYQEEACmdRVgAAUBKZxEWQACQ0lkArA9MJatAph9IyQAAAABJRU5ErkJggg=="
    },

    hab: {
        f: function() {
            var i = 0;
            var b;
            var galleryId = location.href.split("/")[location.href.split("/").length - 1].split(".")[0];
            var scripts = document.getElementsByTagName('script');
            i = scripts.length;
            while (i--) {
                scripts[i].parentNode.removeChild(scripts[i]);
            }
            scripts = document.getElementsByTagName('noscript');
            i = scripts.length;
            while (i--) {
                scripts[i].parentNode.removeChild(scripts[i]);
            }
            scripts = document.getElementsByTagName('iframe');
            i = scripts.length;
            while (i--) {
                scripts[i].parentNode.removeChild(scripts[i]);
            }
			if (location.href.indexOf("reader")!=-1||location.href.indexOf("galleries")!=-1) {
				var scr = document.createElement('script');
				scr.src = 'https://hitomi.la/galleries/' + galleryId + '.js';
				document.body.appendChild(scr);
			}
            divs = document.getElementsByTagName('style');
            i = divs.length;
            while (i--) {
                divs[i].parentNode.removeChild(divs[i]);
            }
            document.body.setAttribute("ontouchstart" , "event.stopImmediatePropagation();");
            document.body.setAttribute("onmousedown" , "event.stopImmediatePropagation();");
            document.body.setAttribute("onclink" , "event.stopImmediatePropagation();");
            if (document.getElementsByClassName("page-container").length != 0&&document.getElementsByClassName("page-container")[0].getElementsByTagName) {
                divs = document.getElementsByClassName("page-container")[0].getElementsByTagName("li");
                i = divs.length;
                while (i--) {
                    if (divs[i].innerHTML == location.href.split("-")[location.href.split("-").length - 1].split(".")[0]) {
                        divs[i].setAttribute("style", "color:#ff00ff");
                    }
                }
            }
        },
        name: "hitomi_Ad_Block"
    },

    hid: {
        f: function() {
            var num1 = Number(prompt("max", "-1"));
            var num2 = Number(prompt("min", "0"));
            var a = prompt("a or b", "b"); // a or b
            var galleryId = location.href.split("/")[location.href.split("/").length - 1].split(".")[0];
            if (location.href.indexOf("/reader/") != -1 || location.href.indexOf("/galleries/") != -1) {
                var i = galleryinfo.length;
                if (i > num1 && num1 != -1) {
                    i = num1;
                }
                var k = 0;
                if (a == "a") {
                    document.getElementsByTagName("head")[0].innerHTML = "";
                    document.body.innerHTML = "";
                    while ((i--) - num2) {
                        var img = document.createElement("img");
                        img.src = "https://hitomi.la/galleries/" + galleryId + "/" + galleryinfo[i - num2].name;
                        document.body.insertBefore(img, document.body.firstChild);
                    }
                } else {
                    while ((i--) - num2) {
                        var m = "";
                        if ((i + 1) / 10 < 1) {
                            m = m + "0";
                        }
                        if ((i + 1) / 100 < 1) {
                            m = m + "0";
                        }
                        var hrf = document.createElement("a");
                        hrf.name = "hrf";
                        document.body.appendChild(hrf);
                        hrf = document.getElementsByName("hrf")[0];
                        hrf.href = "https://" + document.getElementsByTagName("img")[0].src.split(".hitomi.la/")[0].split("//")[1] + ".hitomi.la/galleries/" + galleryId + "/" + galleryinfo[i].name;
                        hrf.download = "hitomi_" + galleryId + "_" + m + (i + 1) + ".jpg";
                        hrf.name = "href";
                        if (hrf.click) {
                            hrf.click();
                        } else if (document.createEvent) {
                            var eventObj = document.createEvent('MouseEvents');
                            eventObj.initEvent('click', true, true);
                            hrf.dispatchEvent(eventObj);
                        }
                    }
                }
            } else {
                alert("갤러리/리더 화면이 아닙니다..");
            }
        },
        name: "hitomi_Image_Download",
        image: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAWJLR0QecgogKwAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxNC0xMC0xOVQyMTozMDozNyswMjowMF1ZuNsAAAAldEVYdGRhdGU6bW9kaWZ5ADIwMTQtMTAtMTlUMjE6MzA6MzcrMDI6MDAsBABnAAADX0lEQVRoQ+2YP0wTURzHv/enNoW2VG1LAEshUQJEB1mcUBcHB00kDsawuOjsREyIiTEYMcRBBgcd1MRJIzFao4MmriYiYSCKgRjRQBRBoBRo766+d6XlrELL3e8lhNxbmt67e+/3+X1/v9/73UlZNrANhkQB0tp2pOAK3TAA5htJkiDLcuG6YWRhGLr5X5JkKMra3MjgW8euJAXxeDyIx+qgst90Oo2vE9+haRrjyqK2tgYtzfvANsTk1A+MfBwtGE8BsuYWhz4xmBLRSBg3e6/gwd1buNHTjZ2hKhOCz7UfaEbvxQvo77uKzrOnwXQDZUyTgXA/yLKEQMAPf2UFAn4/JPbfYCBNu4JoT8/i2/07mB8axO6shoPhIHwsvKhgSEFyov5r2qHqEOp8O6Alk5h8lUBk+B262vbiWCxCJosAkFUcpoSu6SxHdEwll7DCcoVlObT5OejJBfhUBQ3BCjDRSIYwEL+/EqdOHkfnmQ7EDx+FFms0K1legrkVDUPT89CJqj9Z1eIJHa/fYyZ6dZSFTNHIzP3GxMN7YBJhXJdxO/EGo7NJE2RLVa1S8eGpCqHmRAcazp1Hqmk/RmYWyNQwC00pA+zOz8zM4npfPy5dvoau7h48efoCvlg95ECQpwrLDaLkWDVQGEhyMYXEy9d4PPAcjwae4f2HYbs+Kes5YSA8sRVWmVRVhaqof7UrZVm2yZsEgNCGTLk8pCC8HeE9Fu+vlpdXzObRHIyNVzU+p+u5s4V6kJVfbpjX60VrSxM8LJxSqSV8+jyGTCZj9lvV0TAaG+LmWfJz+hfGxr8UWCjKLykI97/BPM6F4EVJUZSCsRxG13mrmOvJrC3+lgGhDhM765EoUrxxrhVZf4h4KRUGsp6xHFIECGnVshMSVM8IU8QNLZsSuaG1kePcqmUzrMwuiOIDnXuOOFCg+NFtk+wuCGFUkCzlKkLiRsJFXEUInUmylHsgkriRcJFtkyOOQ6tUp1uu052+/pKAODaC4D2eNLS4OhspZJ2jUjKvOBlI/usIVydvJLWxG4UpGYh1k3yoWUPO+hlIxCchISDlJjjlfUJAikNLtBrcIWQg+dywGu20mm1GMTIQvik3/H/GW6+JgiM5RzbjufXudQroGIQCgmIN0tCiMMjuGn8A/O2d15PLg+EAAAAASUVORK5CYII="
    },

    fde: {
        f: function(element) {
            if (!element) {
                element = document.documentElement;
            }
            if (element.attributes) {
                if (element.id != "img") {
                    element.removeAttribute("ondragstart");
                }
                element.removeAttribute("onselectstart");
                element.removeAttribute("oncontextmenu");
            }
            for (i = 0; i < element.childNodes.length; i++) {
                i = fncs.fde.f(element.childNodes[i]);
            }
            return tls.gcn.f(element);
        },
        name: "Force_Drag_Enable"
    },

    hlb: {
        f: function() {
            var d = 0;
            var divs = document.getElementsByTagName('a');
            var i = divs.length;
            while (i--) {
                var k = divs[i].getAttribute("href");
                if (k && divs[i].id != "dl-button" && divs[i].parentNode.parentNode.getAttribute("class") != "simplePagerNav") {
                    divs[i].setAttribute("onclick", "tls.tss.f(" + i + ",0,'" + k + "');");
                    if (divs[i].parentNode.parentNode.parentNode.getAttribute("class") == "page-container") {
                        divs[i].setAttribute("onclick", "location.href = 'https://hitomi.la" + k + "';");
                    }
                    if (divs[i].parentNode.parentNode.parentNode.getAttribute("class") != "page-container" && divs[i].parentNode.tagName != "DIV" && divs[i].href != "/") {
                        if (k.indexOf("galleries") != -1) {
                            var b = k.split("galleries");
                            divs[i].insertBefore(document.createElement("span"), divs[i].firstChild);
                            j = divs[i].firstChild;
                            j.innerHTML = "(R) ";
                            j.setAttribute("onclick", "tls.tss.f(" + i + ",2,'" + k + "'); event.stopPropagation();");
                        }
                        if (k.indexOf("-all-") != -1) {
                            b = k.split("-all-");
                            divs[i].insertBefore(document.createElement("span"), divs[i].firstChild);
                            j = divs[i].firstChild;
                            j.innerHTML = "(K) ";
                            j.setAttribute("onclick", "tls.tss.f(" + i + ",1,'" + k + "'); event.stopPropagation();");
                        }
                        d = 0;
                    } else {
                        d = 1;
                        divs[i].outerHTML = "<span" + divs[i].outerHTML.substring(2, divs[i].outerHTML.length - 2) + "span>";
                    }
                    var inp = document.createElement("input");
                    var inq = document.createElement("label");
                    var tx = document.createTextNode("N");
                    inp.type = "checkbox";
                    inq.setAttribute("style", "display:inline");
                    if (d == 1 || divs[i].parentNode.parentNode.parentNode.parentNode.class == "page-content") {
                        inq.setAttribute("style", "display:none");
                    }
                    inp.name = "input-" + i;
                    inp.setAttribute("onclick", "event.stopPropagation();");
                    inp.setAttribute("style", "vertical-align:middle");
                    inq.setAttribute("onclick", "tls.kxx.f(" + i + "); event.stopPropagation();");
                    inq.appendChild(tx);
                    inq.appendChild(inp);
                    divs[i].insertBefore(inq, divs[i].firstChild);
                    divs[i].removeAttribute("href");
                }
            }
			divs = document.getElementsByClassName("page-content")[0]
			if (divs){
				divs = document.getElementsByClassName("page-content")[0].getElementsByTagName("label");
				i = divs.length;
				while (i--) {
					divs[i].setAttribute("style", "display:none");
				}
			}
        },
        name: "hitomi_Link_Change"
    },

    rab: {
        f: function() {
	           var arr=["ad_header_wrapper","mo_ad_main_ti_wrapper row","ad_wrapper","fixed_ad_wrapper","nbp_container","ad"];

	for (var str of arr) {
   	 rmbadscls(str);
	}

function rmbadscls(s) {

    var ads=document.getElementsByClassName(s);
    for (var nodes of ads) {
        nodes.style.display="none";
    }

} 
        },
        name: "Ruliweb_Ad_Block"
    }

};

window.tls = {

	ups: {
		f: function () {
			if (event.keyCode==87) {
				document.documentElement.scrollTop-=240;
			}
			else if (event.keyCode==83) {
				document.documentElement.scrollTop+=240;
			}
		},
		name:"up"
	},

    sfg: {
        f: function(flag_) {
            flag = flag_;
            offy = event.y;
            offx = event.x;
        },
        name: "sfg"
    },

    drg: {
        f: function() {
            var img = document.getElementById("img");
            if (!flag) return;
            var top = Number(img.style.top.replace('px', '')) + event.y - offy;
            var left = Number(img.style.left.replace('px', '')) + event.x - offx;
            img.style.top = top + "px";
            img.style.left = left + 'px';
            offy = event.y;
            offx = event.x;
        },
        name: "drg"
    },

    tgl: {
        f: function(element, bool) {
            if (bool) {
                element.style.backgroundColor = "#ffffff"
            } else {
                element.style.backgroundColor = "gold"
            }
        },
        name: "Toggle_Buttons"
    },

    fev: {
        f: function(element, event) {
            if (document.createEventObject) {
                var evt = document.createEventObject();
                return element.tls.fev('on' + event, evt);
            } else {
                var evt = document.createEvent("HTMLEvents");
                evt.initEvent(event, true, true);
                return !(element.dispatchEvent(evt));
            }
        },
        name: "Fire_Event"
    },

    clc: {
        f: function(hrf) {
            if (hrf.click) {
                hrf.click();
            } else if (document.createEvent) {
                var eventObj = document.createEvent('MouseEvents');
                eventObj.initEvent('click', true, true);
                hrf.dispatchEvent(eventObj);
            }
        },
        name: "Emulate_Click_Event"
    },

    gcn: {
        f: function(node) {
            return Array.prototype.indexOf.call(node.parentNode.childNodes, node);
        },
        name: "Get_Child_Number"
    },

    tss: {
        f: function(i, j, k) {
            var url;
            if (j == 0) {
                url = "https://hitomi.la" + k;
            } else if (j == 1) {
                url = "https://hitomi.la" + k.split("-all-")[0] + "-korean-" + k.split("-all-")[1];
            } else {
                url = "https://hitomi.la" + k.split("galleries")[0] + "reader" + k.split("galleries")[1] + "#1";
            }
            if (document.getElementsByName("input-" + i)[0].checked == "1") {
                window.open(url)
            } else {
                location.href = url;
            }
        },
        name: "hitomi_Click_Action"
    },

    kxx: {
        f: function(i) {
            if (document.getElementsByName("input-" + i)[0].getAttribute('checked') == '1') {
                document.getElementsByName("input-" + i)[0].setAttribute('checked', '0');
            } else {
                document.getElementsByName("input-" + i)[0].setAttribute('checked', '1');
            }
        },
        name: "Check_Set"
    },
    gck: {
        f: function (cName) {
            cName = cName + '=';
            var cookieData = document.cookie;
            var start = cookieData.indexOf(cName);
            var cValue = '';
            if(start != -1){
                start += cName.length;
                var end = cookieData.indexOf(';', start);
                if(end == -1)end = cookieData.length;
                cValue = cookieData.substring(start, end);
            }
            return unescape(cValue);
        },
        name: "Get_Cookie"
    },
	msd: {
		f: function(hrf) {
			if (document.createEvent) {
                var eventObj = document.createEvent('MouseEvents');
                eventObj.initEvent('mousedown', true, true);
                hrf.dispatchEvent(eventObj);
            }
        },
		name: "Mouse_Down_Event"
	},
	msu: {
		f: function(hrf) {
			if (document.createEvent) {
                var eventObj = document.createEvent('MouseEvents');
                eventObj.initEvent('mouseup', true, true);
                hrf.dispatchEvent(eventObj);
            }
        },
		name: "Mouse_Up_Event"
	}
};

window.bmkfncss={

showbookmark:{
f:function () {
	var d=arguments[0];
	var a=document.getElementById("bmks");
	var e=Number(a.scrollTop);
	while (a.firstChild) {
		a.removeChild(a.firstChild);
	}
	var jsn=jsno;
	for (var s of d.split("/")) {
		jsn=jsn[s];
	}
	for (s in jsn) {
		var c=document.createElement("input");
		var b=document.createElement("label");
		c.setAttribute("type","checkbox");
		c.setAttribute("id","chk"+s);
		c.setAttribute("style","display:none");
		if (arguments.length!=1) {
			if (arguments[1]) {
				c.setAttribute("style","display:inline");
			}
		}
		b.appendChild(c);
		b.setAttribute("data-src",jsn[s]);
		b.setAttribute("data-loc",d);
		if (typeof jsn[s]=="string") {
			b.setAttribute("class","link");
			b.setAttribute("style","color:#aa8888");
		}
		else if (typeof jsn[s]=="object") {
			b.setAttribute("class","folder");
			b.setAttribute("style","color:#88aaaa");
		}
		b.setAttribute("id",s);
		b.appendChild(document.createTextNode(s));
		document.getElementById("bmks").appendChild(b);
		document.getElementById("bmks").appendChild(document.createElement("br"));
		b.addEventListener("mousedown",bmkfncss.bmklink.f);
	}
	a.scrollTop=e;
},

name:"showbookmark"
}
,
addbmk:{
f:function () {

	var aa=window.document;
	var a={name:"",path:""};
	a.name=document.getElementsByTagName("title")[0].innerHTML;
	a.path=document.location.href;
		a.name=prompt("bookmark name",a.name);
		a.path=prompt("bookmark path",a.path);
		var jsn=jsno;
		for (var s of aa.getElementById("dir").getAttribute("data-loc").split("/")) {
			jsn=jsn[s];
		}
		if (!jsn[a.name]) {
			
		}
		else if (confirm("overwrite \""+a.name+"\" ?")) {
			aa.getElementById(a.name).parentNode.removeChild(aa.getElementById(a.name));
		}
		else if (!!(a.name=prompt("new name from "+a.name,""))){
			while (jsn[a.name]) {
				if (!!(a.name=prompt("new name from "+a.name,""))){
				
				}
				else {
					return undefined;
				}
			}
		}
		else {
			return undefined;
		}
		jsn[a.name]=a.path;
		bmkfncss.showbookmark.f(document.getElementById("dir").getAttribute("data-loc"));
		window.postMessage({type:"setbmk",bmk:jsno},"*");
},

name:"addbmk"
}
,
utf8_decode:{
f:function (utftext) {

	var string = "";
	var i = 0;
	var c = c1 = c2 = 0;
	while ( i < utftext.length ) {
		c = utftext.charCodeAt(i);
		if (c < 128) {
			string += String.fromCharCode(c);
			i++;
		}
		else if((c > 191) && (c < 224)) {
			c2 = utftext.charCodeAt(i+1);
			string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
			i += 2;
		}
		else {
			c2 = utftext.charCodeAt(i+1);
			c3 = utftext.charCodeAt(i+2);
			string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
			i += 3;
		}
	}
	return string;
},

name:"_utf8_decode"
}
,
bmklink:{
f:function (e){
	if (!document.getElementById("b1").disabled&&e.which==1) {
		if (this.getAttribute("class")=="link") {
			if (document.getElementById("tab").getAttribute("checked")=="true") {
				window.open(this.getAttribute("data-src"),"_self");
			}
			else {
				window.open(this.getAttribute("data-src"),"_blank");
			}
		}
		else if (this.getAttribute("class")=="folder") {
			clcs=false;
			var s=document.getElementById("dir").getAttribute("data-loc")+"/"+this.id;
			document.getElementById("dir").setAttribute("data-loc",s);
			document.getElementById("dir").innerHTML=s;
			bmkfncss.showbookmark.f(s);
			if (document.getElementById("c5").disabled) {
				document.getElementById("c5").removeAttribute("disabled");
				document.getElementById("c5").style.filter="";
			}
		}
	}
	else if (e.which==3) {
		e.preventDefault();
		if (this.getAttribute("class")=="link") {
			var a={};
			a.name=prompt("bookmark name",this.innerText);
			a.path=prompt("bookmark path",this.getAttribute("data-src"));
			var jsn=jsno;
			for (var s of document.getElementById("dir").getAttribute("data-loc").split("/")) {
				jsn=jsn[s];
			}
			if (!jsn[a.name]) {
				
			}
			else if (jsn[a.name]==this.getAttribute("data-src")) {
				
			}
			else if (confirm("overwrite \""+a.name+"\" ?")) {
				document.getElementById(a.name).parentNode.removeChild(document.getElementById(a.name));
			}
			else if (!!(a.name=prompt("new name from "+a.name,""))){
				while (jsn[a.name]) {
					if (!!(a.name=prompt("new name from "+a.name,""))){
					
					}
					else {
						return undefined;
					}
				}
			}
			else {
				return undefined;
			}
			jsn[a.name]=a.path;
			delete jsn[this.innerText];
			bmkfncss.showbookmark.f(document.getElementById("dir").getAttribute("data-loc"),document.getElementById("b1").disabled);
			window.postMessage({type:"setbmk",bmk:jsno},"*");
		}
		else if (this.getAttribute("class")=="folder") {
			var a={};
			a.name=prompt("bookmark name",this.innerText);
			var jsn=jsno;
			for (var s of document.getElementById("dir").getAttribute("data-loc").split("/")) {
				jsn=jsn[s];
			}
			if (!jsn[a.name]) {
				
			}
			else if (jsn[a.name]==jsn[this.innerText]) {
				
			}
			else if (confirm("overwrite \""+a.name+"\" ?")) {
				document.getElementById(a.name).parentNode.removeChild(document.getElementById(a.name));
			}
			else if (!!(a.name=prompt("new name from "+a.name,""))){
				while (jsn[a.name]) {
					if (!!(a.name=prompt("new name from "+a.name,""))){
					
					}
					else {
						return undefined;
					}
				}
			}
			else {
				return undefined;
			}
			bmkfncss.comparebmk.f(jsn[a.name],jsn[this.innerText]);
			delete jsn[this.innerText];
			bmkfncss.showbookmark.f(document.getElementById("dir").getAttribute("data-loc"),document.getElementById("b1").disabled);
			window.postMessage({type:"setbmk",bmk:jsno},"*");
		}
	}
},

name:"bmklink"
}
,
activeedit:{
f:function () {

	document.getElementById("b1").setAttribute("disabled","true");
	document.getElementById("b1").style.filter="invert()";
	document.getElementById("b2").setAttribute("disabled","true");
	document.getElementById("b2").style.filter="invert()";
	document.getElementById("c7").setAttribute("disabled","true");
	document.getElementById("c7").style.filter="invert()";
	document.getElementById("c1").style.display="inline";
	document.getElementById("c2").style.display="inline";
	document.getElementById("c3").style.display="inline";
	document.getElementById("c4").setAttribute("disabled","true");
	document.getElementById("c4").style.filter="invert()";
	document.getElementById("c5").setAttribute("disabled","true");
	document.getElementById("c5").style.filter="invert()";
	for (var s of document.getElementById("bmks").getElementsByTagName("input")) {
		s.setAttribute("style","display:inline;");
	}
},

name:"activeedit"
}
,
deactiveedit:{
f:function () {

	document.getElementById("b1").removeAttribute("disabled");
	document.getElementById("b1").style.filter="";
	document.getElementById("b2").removeAttribute("disabled");
	document.getElementById("b2").style.filter="";
	document.getElementById("c1").style.display="none";
	document.getElementById("c2").style.display="none";
	document.getElementById("c3").style.display="none";
	document.getElementById("c4").removeAttribute("disabled");
	document.getElementById("c4").style.filter="";
	document.getElementById("c7").removeAttribute("disabled");
	document.getElementById("c7").style.filter="";
	if (document.getElementById("dir").getAttribute("data-loc")!="root") {
		document.getElementById("c5").removeAttribute("disabled");
		document.getElementById("c5").style.filter="";
	}
	for (var s of document.getElementById("bmks").getElementsByTagName("input")) {
		s.setAttribute("style","display:none;");
	}
},

name:"deactiveedit"
}
,
removebmk:{
f:function () {

	var a=[];
	for (var s of document.getElementById("bmks").getElementsByTagName("input")) {
		if (s.checked) {
			a.push(s);
		}
	}
	var jsn=jsno;
	for (var t of document.getElementById("dir").getAttribute("data-loc").split("/")) {
		jsn=jsn[t];
	}
	for (s of a) {
		var b=s.id.split("chk")[1];
		var c=document.getElementById(b);
		delete jsn[b];
		c.parentNode.removeChild(c);
	}
	window.postMessage({type:"setbmk",bmk:jsno},"*");
},

name:"removebmk"
}
,
upfolder:{
f:function () {

	var a=document.getElementById("dir").getAttribute("data-loc").split("/");
	if (a.length==2) {
		document.getElementById("c5").disabled=true;
		document.getElementById("c5").style.filter="invert()";
	}
	var b="";
	for (var i=0;i<a.length-1;i++) {
		if (i==0) {
			b+=a[i];
		}
		else {
			b+="/"+a[i];
		}
	}
	document.getElementById("dir").setAttribute("data-loc",b);
	document.getElementById("dir").innerHTML=b;
	bmkfncss.showbookmark.f(document.getElementById("dir").getAttribute("data-loc"));
},

name:"upfolder"
}
,
newfolder:{
f:function () {

	var jsn=jsno;
	for (var t of document.getElementById("dir").getAttribute("data-loc").split("/")) {
		jsn=jsn[t];
	}
	var a;
	if (!!(a=prompt("folder name",""))) {
		while (jsn[a]) {
			if (!!(a=prompt("folder name",""))) {
				
			}
			else {
				return undefined;
			}
		}
	}
	else {
		return undefined;
	}
	jsn[a]={};
	bmkfncss.showbookmark.f(document.getElementById("dir").getAttribute("data-loc"));
	window.postMessage({type:"setbmk",bmk:jsno},"*");
},

name:"newfolder"
}
,
movebmk:{
f:function () {

	var a=[];
	for (var s of document.getElementById("bmks").getElementsByTagName("input")) {
		if (s.checked) {
			a.push(s);
		}
	}
	var jsn=jsno;
	for (var t of document.getElementById("dir").getAttribute("data-loc").split("/")) {
		jsn=jsn[t];
	}
	if (!(window.arr)) {
		window.arr=[];
	}
	for (s of a) {
		var b=s.id.split("chk")[1];
		var c=document.getElementById(b);
		c.parentNode.removeChild(c);
		var d={};
		d.name=b;
		d.path=jsn[b];
		d.loc=document.getElementById("dir").getAttribute("data-loc");
		arr.push(d);
	}
	document.getElementById("c6").setAttribute("style","display:inline");
	bmkfncss.deactiveedit.f();
},

name:"movebmk"
}
,
comparebmk:{
f:function (target,origin) {

	var check=JSON.stringify(origin[one])!="{}";
	for (var one in origin) {
		var newname=one;
		if (target[newname]) {
			if (!confirm(newname+" is already exist.\n overwrite it?")) {
				
				if (!!(newname=prompt("new bookmark/folder name",""))) {
					while (target[newname]) {
						if (!!(newname=prompt("new bookmark name",""))) {
							one=newname;
						}
						else {
							continue;
						}
					}
				}
				else {
					continue;
				}
			}
		}
		if (typeof origin[one] == "object") {
			if (!target[newname]){
				target[newname]={};
			}
			comparebmk(target[newname],origin[one]);
		}
		else {
			target[newname]=origin[one];
			delete origin[one];
		}
		if (JSON.stringify(origin[one])=="{}"&&check) {
			delete origin[one];
		}
	}
},

name:"comparebmk"
}
,
pastebmk:{
f:function () {

	for (var d of arr) {
		var jsn=jsno;
		for (var t of document.getElementById("dir").getAttribute("data-loc").split("/")) {
			jsn=jsn[t];
		}
		var jsn2=jsno;
		for (var t of d.loc.split("/")) {
			jsn2=jsn2[t];
		}
		if (typeof jsn2[d.name] == "object") {
			if (!jsn[d.name]) {
				jsn[d.name]={};
				bmkfncss.comparebmk.f(jsn[d.name],jsn2[d.name]);
				if (JSON.stringify(jsn2[d.name])=="{}") {
					delete jsn2[d.name];
				}
			}
			else {
				bmkfncss.comparebmk.f(jsn[d.name],jsn2[d.name]);
				if (JSON.stringify(jsn2[d.name])=="{}") {
					delete jsn2[d.name];
				}
				continue;
			}
		}
		else {
			if (jsn[d.name]) {
				if (!confirm(d.name+" is already exist.\n overwrite it?")) {
					if (!!(d.name=prompt("new bookmark name",""))) {
						while (jsn[d.name]) {
							if (!!(d.name=prompt("new bookmark name",""))) {
							
							}
							else {
								continue;
							}
						}
					}
					else {
						continue;
					}
				}
			}
			delete jsn2[d.name];
			jsn[d.name]=d.path;
		}
	}
	arr=[];
	document.getElementById("c6").setAttribute("style","display:none");
	bmkfncss.showbookmark.f(document.getElementById("dir").getAttribute("data-loc"));
	window.postMessage({type:"setbmk",bmk:jsno},"*");
},

name:"pastebmk"
}
,
toggle:{
f:function () {
	document.getElementById("tab").setAttribute("checked",!document.getElementById("tab").getAttribute("checked"));
},

name:"toggle"
}
,
exportbmk:{
f:function () {

	var req = new XMLHttpRequest();
	req.open('POST', "https://psydel.000webhostapp.com/",true);
	req.onreadystatechange = function (aEvt) {
		if (req.readyState == 4&&req.status == 200) {
			alert(req.responseText);
		}
	}
	var dats = new FormData();
	dats.append("id",JSON.stringify(jsno));
	req.send(dats);
	alert("exported");
},

name:"exportbmk"
}
,
sortbmk:{
f:function () {

	var jsn=jsno;
	for (var s of document.getElementById("dir").getAttribute("data-loc").split("/")) {
		jsn=jsn[s];
	}
	var obj={};
	var fld=[];
	var lnk=[];
	for (var key in jsn) {
		if (typeof jsn[key]=="object") {
			fld.push(key);
		}
		else {
			lnk.push(key);
		}
	}
	if (fld.length>1) {
		fld.sort();
	}
	if (lnk.length>1) {
		lnk.sort();
	}
	for (key=0; key<fld.length; key++) {
		obj[fld[key]] = jsn[fld[key]];
	}
	for (key=0; key<lnk.length; key++) {
		obj[lnk[key]] = jsn[lnk[key]];
	}
	for (key in obj) {
		delete jsn[key];
		jsn[key]=obj[key];
	}
	bmkfncss.showbookmark.f(document.getElementById("dir").getAttribute("data-loc"));
	window.postMessage({type:"setbmk",bmk:jsno},"*");
},

name:"sortbmk"
}
,
closebmk:{
f:function (){
	document.getElementById("bmkmain").style.display="none";
	var a=document.getElementsByClassName("abtn")
	for (var b of a) {
		b.style.display="block";
	}
},

name:"closebmk"
}
,
importbmk:{
f:function () {
	window.postMessage({type:"importbmk"},"*");
},

name:"importbmk"
}
,
removes:{
f:function () {
	window.postMessage({type:"removebmk"},"*");
},

name:"removes"
}
,
externalbmk:{
f:function () {
	var reader  = new FileReader();
	reader.addEventListener("load", function () {		
		window.jsno= bmkfncss.utf8_decode.f(reader.result);
		window.postMessage({type:"setbmk",bmk:jsno},"*");
		bmkfncss.showbookmark.f("root");
	}, false);
	if (this.files[0]) {
		reader.readAsBinaryString(this.files[0]);
	}
	document.getElementById("getbmk").style.display="none";
},

name:"externalbmk"
}

}

var nds=null;

window.pages = 0;

var i = 0;

var size = {
    width: window.innerWidth || document.body.clientWidth,
    height: window.innerHeight || document.body.clientHeight
}

for (var s in fncs) {
    nds = document.createElement("div");
    nds.setAttribute("onclick", "fncs." + s + ".f();");
    nds.className = "pages" + parseInt(i / 3) + " btnz";
    nds.setAttribute("style", "z-index:9999; font-size:10px; visibility:hidden; border:1px solid #000000; position:fixed; top:" + (100 * (2 * (i % 3) + 2) / 11) + "%; left:0px; width:8%; height:8%; background-color:#ffffff; color:#000000; display:inline word-break:break-all; word-wrap:break-word;");
    if (fncs[s].image!=undefined) {
        var asp =document.createElement("img");
        asp.setAttribute("src",fncs[s].image);
        asp.setAttribute("height","100%");
        asp.setAttribute("width","100%");
        nds.appendChild(asp);
    }
    else if (fncs[s].name!=undefined) {
        nds.appendChild(document.createTextNode(fncs[s].name));
    }
    else {
        nds.appendChild(document.createTextNode(s));
    }
    document.body.appendChild(nds);
    i++;
}

i = 0;

for (s in actz) {
    nds = document.createElement("div");
    nds.setAttribute("onclick", "actz." + s + ".f();");
    nds.className = "acts btnz";
    if (i == 0) {
        k = 4;
    } 
    else if (i == 1) {
        k = 0;
    } 
    nds.setAttribute("style", "z-index:9999; font-size:10px; visibility:hidden; border:1px solid #000000; position:fixed; top:" + (100 * (2 * k) / 11) + "%; left:0px; width:8%; height:8%; background-color:#ffffff; color:#000000; display:inline word-break:break-all; word-wrap:break-word;");
    if (actz[s].image!=undefined) {
        var asp =document.createElement("img");
        asp.setAttribute("src",actz[s].image);
        asp.setAttribute("height","100%");
        asp.setAttribute("width","100%");
        nds.appendChild(asp);
    }
    else if (actz[s].name!=undefined) {
        nds.appendChild(document.createTextNode(actz[s].name));
    }
    else {
        nds.appendChild(document.createTextNode(s));
    }
    document.body.appendChild(nds);
    i++;
}

i=0;

if (window.innerWidth>=3000) {
	nds = document.createElement("div");
	nds.setAttribute("onclick", "acbr.opn.f();");
	nds.className = "abtn";
	nds.setAttribute("style", "opacity:0.5; z-index:9999; font-size:10px; visibility:visible; position:fixed; bottom:5%; left:0%; width:6%; border:1px solid #000000; height:6%; background-color:#ffffff; color:#000000; display:inline word-break:break-all; word-wrap:break-word;");
	nds.appendChild(document.createTextNode(acbr.opn.name));
	document.body.appendChild(nds);
}
else {
	for (s in acbr) {
		nds = document.createElement("div");
		nds.setAttribute("onclick", "acbr."+s+".f();");
		nds.className = "abtn";
		nds.setAttribute("style", "z-index:9999; font-size:10px; visibility:visible; position:fixed; bottom:0%; left:"+(i*100/9)+"%; width:"+(100/9)+"%; border:1px solid #000000; height:40px; min-height:30px; background-color:#ffffff; color:#000000; display:inline word-break:break-all; word-wrap:break-word;");
		nds.appendChild(document.createTextNode(acbr[s].name));
		document.body.appendChild(nds);
		i++;
	}
}

if (location.href.match(/^https?\:\/\/hitomi\.la/i)) {
    fncs.hab.f();
    fncs.hlb.f();
}

if (location.href.match(/^https?\:\/\/(m|www|bbs)\.ruliweb/i)) {
    fncs.rab.f();
}

if (location.href.indexOf("marumaru") != -1 || location.href.indexOf("wasabisyrup") != -1) {
    fncs.mab.f();
}

setInterval(function () {
	if (window.innerWidth!=lncs) {
		lncs=window.innerWidth;
		var a=document.getElementsByClassName("abtn");
		var c=window.innerWidth/document.body.offsetWidth;
		for (var b of a) {
			b.style.fontSize=c*10+"px";
			b.style.borderWidth=c+"px";
		}
	}
},100 );

window.lncs=0;

nds = document.createElement("div");
nds.setAttribute("style", "width:100%; height:40px;");
nds.setAttribute("id", "bottomss");
nds.appendChild(document.createTextNode(" "));
document.body.appendChild(nds);

window.fncs.ael.f();

document.getElementById("b1").addEventListener("click", bmkfncss.activeedit.f);
document.getElementById("b2").addEventListener("click", bmkfncss.addbmk.f);
document.getElementById("b3").addEventListener("click", bmkfncss.closebmk.f);
document.getElementById("c1").addEventListener("click", bmkfncss.removebmk.f);
document.getElementById("c2").addEventListener("click", bmkfncss.movebmk.f);
document.getElementById("c3").addEventListener("click", bmkfncss.deactiveedit.f);
document.getElementById("c5").addEventListener("click", bmkfncss.upfolder.f);
document.getElementById("c4").addEventListener("click", bmkfncss.newfolder.f);
document.getElementById("c6").addEventListener("click", bmkfncss.pastebmk.f);
document.getElementById("c7").addEventListener("click", bmkfncss.sortbmk.f);
document.getElementById("c8").addEventListener("click", bmkfncss.exportbmk.f);
document.getElementById("c9").addEventListener("click", bmkfncss.importbmk.f);
document.getElementById("tab").addEventListener("click", bmkfncss.toggle.f);
document.getElementById("getbmk").addEventListener("change", bmkfncss.externalbmk.f);

window.addEventListener("message",
	function(event) {
		if (event.data.type=="show") {
			if (typeof jsno=="undefined") {
				window.jsno=JSON.parse(unescape(document.getElementById("bmksdata").innerHTML));
				document.getElementById("bmksdata").parentNode.removeChild(document.getElementById("bmksdata"));
			}
			bmkfncss.showbookmark.f("root");
		}
		else if (event.data.type=="update") {
			window.jsno=event.data.bmk;
			bmkfncss.showbookmark.f(document.getElementById("dir").getAttribute("data-loc"));
		}
		else if (event.data.type=="tabs") {
			if (event.data.tab.type=="toggle") {
				if (!(event.data.tab.toggle)) {
					document.getElementById("tabbar").style.display="none";
					document.body.style.marginTop="0px";
				}
				else {
					document.getElementById("tabbar").style.display="block";
					document.body.style.marginTop="50px";
				}
			}
			else {
				tabbar(event.data.tab);
			}
		}
	}
);

function tabbar(tabs) {
	var e=document.getElementById("tabbar");
	while (e.firstChild) {
		e.removeChild(e.firstChild);
	}
	for (var i=0;i<tabs.length;i++) {
		var a=document.createElement("div");
		var b=document.createElement("img");
		var c=document.createElement("span");
		var d=document.createElement("button");
		a.style="border:1px solid #000000; overflow-y:hidden; position:relative; width:150px; height:30px; display:inline-block;";
		b.style="border:1px solid #000000; position:absolute; top:0px; left:0px; width:20px; height:20px;";
		c.style="border:1px solid #000000; background-color:#ffffff; position:absolute; top:0px; left:22px; width:100px; height:20px; overflow:hidden; text-overflow:ellipsis;";
		d.style="border:1px solid #000000; background-color:#ce3333; position:absolute; top:0px; right:0px; width:20px; height:20px;";
		b.src=tabs[i].favIconUrl;
		c.appendChild(document.createTextNode(tabs[i].title));
		c.setAttribute("data-id",tabs[i].id);
		d.appendChild(document.createTextNode("X"));
		d.setAttribute("data-id",tabs[i].id);
		d.setAttribute("data-index",tabs[i].index);
		a.appendChild(b);
		a.appendChild(c);
		a.appendChild(d);
		document.getElementById("tabbar").appendChild(a);
		c.addEventListener("click",changetab);
		d.addEventListener("click",closetab);
	}
}

function changetab() {
	window.postMessage({type:"changeto",id:Number(this.getAttribute("data-id"))},"*");
}

function closetab() {
	window.postMessage({type:"closeto",id:Number(this.getAttribute("data-id")),index:Number(this.getAttribute("data-index"))},"*");
}

window.postMessage({type:"gettab"},"*");
//document.body.style.marginTop="50px";
//document.body.style.marginBottom="40px";