/*if (!alljs&&!(parent&&parent!=this)) {
    var __scr=document.createElement("script");
    __scr.setAttribute("type","text/javascript");
    //__scr.setAttribute("src","https://rawgit.com/sylee0424/psydel/master/all.js");
    __scr.setAttribute("src",chrome.runtime.getURL("all2.js"));
    document.head.appendChild(__scr);
    var alljs=1;
}*/

var wind=chrome.extension.getBackgroundPage();

var d=wind.document;

wind.location.href="https://namu.wiki/login";

if ( d.readyState === "complete" || (d.readyState !== "loading" && !d.documentElement.doScroll) ) {
  namu();
}
else {
  document.addEventListener("DOMContentLoaded", namu);
}

wind.location.href="http://www.typemoon.net/bbs/login.php";

if ( d.readyState === "complete" || (d.readyState !== "loading" && !d.documentElement.doScroll) ) {
  typemoon();
}
else {
  document.addEventListener("DOMContentLoaded", typemoon);
}

function namu() {
var d=wind.document
var a=d.getElementById("usernameInput");
var b=d.getElementById("passwordInput");
var c=d.getElementsByClassName("login-form")[0];
a.value="sylee0424";
b.value="lsy0307";
c.submit();
}

function icomu() {
var d=wind.document
var a=d.getElementsByName("mb_id")[0];
var b=d.getElementsByName("mb_password")[0];
var c=d.getElementsByName("flogin")[0];
a.value="sylee0424";
b.value="lsy0307";
c.submit();
}

function typemoon() {
var d=wind.document
var a=d.getElementsByName("mb_id")[0];
var b=d.getElementsByName("mb_password")[0];
var c=d.getElementsByName("flogin")[0];
a.value="sylee0424";
b.value="lsy0307";
c.submit();
}

function github() {
var d=wind.document
var a=d.getElementById("login_field");
var b=d.getElementById("password");
var c=d.document.getElementsByTagName("form")[0];
a.value="sylee0424";
b.value="lsy0307";
c.submit();
}