if (!browser) {
	var browser=chrome;
}

var div= document.createElement("div");
div.style="border:1px solid #000000; background-color:#ffffff; display:none; position:fixed; top:20px; left:20px; width:320px; height:0px; z-index:9999; overflow:auto; font-size:10px;";
div.id="bmkmain";
document.body.appendChild(div);

div=document.createElement("button");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="b1";
div.appendChild(document.createTextNode("edit"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="b2";
div.appendChild(document.createTextNode("add"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c7";
div.appendChild(document.createTextNode("sort"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c4";
div.appendChild(document.createTextNode("new"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c5";
div.disabled=true;
div.appendChild(document.createTextNode("up"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="display:none; border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c6";
div.appendChild(document.createTextNode("paste"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="b3";
div.appendChild(document.createTextNode("close"));
document.getElementById("bmkmain").appendChild(div);
document.getElementById("bmkmain").appendChild(document.createElement("br"));

var lvl=document.createElement("label");
div=document.createElement("input");
div.type="checkbox";
div.id="tab";
lvl.appendChild(div);
lvl.appendChild(document.createTextNode("this tab"));
document.getElementById("bmkmain").appendChild(lvl);

div=document.createElement("input");
div.type="file";
div.style="display:none";
div.id="getbmk";
div.name="ffbookmark";
div.accept=".json";
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c9";
div.appendChild(document.createTextNode("import"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c8";
div.appendChild(document.createTextNode("export"));
document.getElementById("bmkmain").appendChild(div);
document.getElementById("bmkmain").appendChild(document.createElement("br"));

div=document.createElement("div");
div.setAttribute("data-loc","root");
div.id="dir";
div.appendChild(document.createTextNode("root"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="display:none; border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c1";
div.appendChild(document.createTextNode("remove"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="display:none; border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c2";
div.appendChild(document.createTextNode("move"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="display:none; border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c3";
div.appendChild(document.createTextNode("end"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("div");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="bmks";
div.appendChild(document.createTextNode("loading..."));
document.getElementById("bmkmain").appendChild(div);

window.addEventListener("message",
	function(event) {
		if (event.data.type=="getbmk") {
			chrome.storage.local.get("bmks",function (c) {
				if (c.bmks) {
					if (typeof cloneInto!="undefined") {
						window.wrappedJSObject.jsno = cloneInto(JSON.parse(unescape(c.bmks)),window,{cloneFunctions: true});
						window.postMessage({type:"show"},location.href);
					}
					else {
						div=document.createElement("div");
						div.style="display:none";
						div.id="bmksdata";
						document.body.appendChild(div);
						div.innerHTML=c.bmks;
						window.postMessage({type:"show"},location.href);
					}
				}
				else {
					alert("nobmk!");
				}
			});
		}
		else if (event.data.type=="setbmk") {
			chrome.storage.local.set({"bmks":escape(JSON.stringify(event.data.bmk))});
		}
		else if (event.data.type=="removebmk") {
			chrome.storage.local.remove("bmks");
		}
		else if (event.data.type=="importbmk") {
			try {
				//document.getElementById("bmks").innerHTML="loading...";
				var req = new XMLHttpRequest();
				req.open('GET', "https://psydel.000webhostapp.com/",true);
				req.onreadystatechange = function (aEvt) {
					if (req.readyState == 4&&req.status == 200) {
						chrome.storage.local.set({"bmks":escape(req.responseText)});
					}
					else if (req.status == 423) {
						//document.getElementById("getbmk").style.display="block";
					}
				};
				req.onerror=function () {
					
				};
				req.send(null);
			}
			catch (e) {
				//document.getElementById("bmks").innerHTML="load fail!";
			}
		}
		else if (event.data.type=="check") {
			chrome.storage.local.get("bmks",function (c) {
				if (unescape(c.bmks)!=JSON.stringify(event.data.bmks)) {
					var rtn=Object.assign({},event.data.bmk,JSON.parse(unescape(c.bmks)));
					window.postMessage({type:"update",bmk:rtn},location.href);
				}
			});
		}
		else if (event.data.type=="gettabs") {
			chrome.runtime.sendMessage(chrome.runtime.id,{"type":"gettabs"});
		}
		else if (event.data.type=="test") {
			alert("test message");
		}
});

chrome.runtime.onMessage.addListener(gettabsf);

function gettabsf(message,sender,sendResponse) {
	window.postMessage({type:"tabs",tab:message},location.href);
}

var __scr=document.createElement("script");
__scr.setAttribute("type","text/javascript");
document.head.appendChild(__scr);
__scr.setAttribute("onload","this.parentNode.removeChild(this)");
__scr.setAttribute("src",chrome.runtime.getURL("all2.js"));
