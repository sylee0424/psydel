if (!browser) {
	var browser=chrome;
}
if (!chrome) {
	var chrome=browser;
}

chrome.storage.local.get("bmks",function (c) {
	if (c.bmks) {
		
	}
	else {
		importbmk();
	}
});

function importbmk() {
	try {
		//document.getElementById("bmks").innerHTML="loading...";
		var req = new XMLHttpRequest();
		req.open('GET', "https://psydel.000webhostapp.com/",true);
		req.onreadystatechange = function (aEvt) {
			if (req.readyState == 4&&req.status == 200) {
				chrome.storage.local.set({"bmks":escape(req.responseText)});
			}
			else if (req.status == 423) {
				//document.getElementById("getbmk").style.display="block";
			}
		};
		req.onerror=function () {
			
		};
		req.send(null);
	}
	catch (e) {
		//document.getElementById("bmks").innerHTML="load fail!";
	}
}

browser.windows.onRemoved.addListener(listener)

function listener (){
	chrome.storage.local.get("bmks",function (c) {
		if (c.bmks) {
			var req = new XMLHttpRequest();
			req.open('POST', "https://psydel.000webhostapp.com/",true);
			var dats = new FormData();
			dats.append("id",unescape(c.bmks));
			req.send(dats);	
		}
	});
}

chrome.runtime.onMessage.addListener(gettabsf);
chrome.tabs.onRemoved.addListener(updatetabs);
chrome.tabs.onUpdated.addListener(updatetabs);
chrome.tabs.onMoved.addListener(updatetabs);
chrome.tabs.onReplaced.addListener(updatetabs);
chrome.tabs.onCreated.addListener(updatetabs);

function gettabsf(message,sender,sendResponse) {
	if (message.type=="gettab") {
		if (navigator.userAgent.toLowerCase().indexOf("firefox")!=-1) {
			chrome.tabs.query({}).then(function (a) {
				chrome.tabs.sendMessage(sender.tab.id,a);
			},function (){});
		}
		else {
		chrome.tabs.query({},function (a) {
				chrome.tabs.sendMessage(sender.tab.id,a);
			});
		}
	}
	else if (message.type=="changeto") {
		chrome.tabs.update(message.id, {active: true});
	}
	else if (message.type=="moveto") {
		chrome.tabs.move(message.id,{index:message.index});
	}
	else if (message.type=="closeto") {
		chrome.tabs.remove(message.id);
	}
	else if (message.type=="tabbartoggle") {
		if (navigator.userAgent.toLowerCase().indexOf("firefox")!=-1) {
			chrome.tabs.query({}).then(function (a) {
				for (var i=0;i<a.length;i++) {
					if (sender.tab.id!=a[i].id) {
						chrome.tabs.sendMessage(a[i].id,{type:"toggle",toggle:message.toggle});
					}
				}
			},function (){});
		}
		else {
		chrome.tabs.query({},function (a) {
				for (var i=0;i<a.length;i++) {
					if (sender.tab.id!=a[i].id) {
						chrome.tabs.sendMessage(a[i].id,{type:"toggle",toggle:message.toggle});
					}
				}
			});
		}
	}
	else if (message.type=="test") {
		
	}
}

function updatetabs() {
	chrome.storage.local.get("favicon",function (c) {
		console.log(c);
		if (!(c.favicon)) {
			c.favicon="{}";
		}
		console.log(c);
		var e=JSON.parse(unescape(c.favicon));
		if (window.localStorage.getItem("favicon")) {
			e=JSON.parse(unescape(window.localStorage.getItem("favicon")));
			chrome.storage.local.set({"favicon":escape(JSON.stringify(e))});
		}
		if (navigator.userAgent.toLowerCase().indexOf("firefox")!=-1) {
			chrome.tabs.query({}).then(function (a) {
				var d=[];
				var b="";
				for (var i=0;i<a.length;i++) {
					d[i]={};
					d[i].id=Number(a[i].id);
					d[i].index=Number(a[i].index);
					d[i].title=String(a[i].title);
					b=a[i].favIconUrl;
					console.log(b);
					console.log(e);
					console.log(d);
					if (!b||b=="undefined"||b==""||typeof b=="undefined") {
						console.log("a");
						d[i].favIconUrl="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAIAAADYYG7QAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABDSURBVFhH7c4xAQAwDASh+jf9lcCa4VDA2zGFpJAUkkJSSApJISkkhaSQFJJCUkgKSSEpJIWkkBSSQlJICkkhORbaPoBi5ofwSUznAAAAAElFTkSuQmCC";
					}
					else if (e[b]) {
						console.log("b");
						d[i].favIconUrl=e[b];
					}
					else {
						console.log("c");
						getDataUri(b, function(dataUri) {
							console.log(b+" is loaded");
							e=JSON.parse(unescape(window.localStorage.getItem("favicon")))
							e[b]=dataUri;
							window.localStorage.setItem("favicon",escape(JSON.stringify(e)));
						});
						d[i].favIconUrl=a[i].favIconUrl;
					}
				}
				for (var i=0;i<a.length;i++) {
					chrome.tabs.sendMessage(a[i].id,a);
				}
			},function (){});
		}
		else {
			chrome.tabs.query({},function (a) {
				var d=[];
				var b="";
				for (var i=0;i<a.length;i++) {
					d[i]={};
					d[i].id=Number(a[i].id);
					d[i].index=Number(a[i].index);
					d[i].title=String(a[i].title);
					b=a[i].favIconUrl;
					console.log(b);
					console.log(e);
					console.log(d);
					if (!b||b=="undefined"||b==""||typeof b=="undefined") {
						console.log("a");
						d[i].favIconUrl="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAIAAADYYG7QAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABDSURBVFhH7c4xAQAwDASh+jf9lcCa4VDA2zGFpJAUkkJSSApJISkkhaSQFJJCUkgKSSEpJIWkkBSSQlJICkkhORbaPoBi5ofwSUznAAAAAElFTkSuQmCC";
					}
					else if (e[b]) {
						console.log("b");
						d[i].favIconUrl=e[b];
					}
					else {
						console.log("c");
						getDataUri(b, function(dataUri) {
							console.log(b+" is loaded");
							e[b]=dataUri;
							chrome.storage.local.set({"favicon":escape(JSON.stringify(e))});
						});
						d[i].favIconUrl=a[i].favIconUrl;
					}
				}
				for (var i=0;i<a.length;i++) {
					chrome.tabs.sendMessage(a[i].id,d);
				}
			});
		}
	});
}

function getDataUri(url, callback) {
    var image = new Image();
    image.onload = function () {
		console.log(image);
        var canvas = document.createElement('canvas');
        canvas.width = this.naturalWidth;
        canvas.height = this.naturalHeight;
        canvas.getContext('2d').drawImage(this, 0, 0);
		console.log(canvas.toDataURL('image/png'));
        callback(canvas.toDataURL('image/png'));
    };
    image.src = url;
}
