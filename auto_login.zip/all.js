﻿function nload() {

var req = new XMLHttpRequest();
req.open('GET', 'https://github.com/login', false);
req.send(null);
var sss = req.responseText.split('<input name="authenticity_token" type="hidden" value="')[1].split('">')[0];
document.getElementsByName("authenticity_token")[0].value=sss;

}

document.addEventListener("load",function () { document.getElementsByName("commit")[0].onclick="nload();"; } );