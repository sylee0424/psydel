var extension=(!!chrome)?chrome:browser;

extension.storage.local.get("bmks",function (c) {
	if (c.bmks) {
		
	}
	else {
		importbmk();
	}
});

function importbmk() {
	try {
		//document.getElementById("bmks").innerHTML="loading...";
		var req = new XMLHttpRequest();
		req.open('GET', "https://psydel.000webhostapp.com/",true);
		req.onreadystatechange = function (aEvt) {
			if (req.readyState == 4&&req.status == 200) {
				extension.storage.local.set({"bmks":escape(req.responseText)});
			}
			else if (req.status == 423) {
				//document.getElementById("getbmk").style.display="block";
			}
		};
		req.onerror=function () {
			
		};
		req.send(null);
	}
	catch (e) {
		//document.getElementById("bmks").innerHTML="load fail!";
	}
}

extension.windows.onRemoved.addListener(listener)

function listener (){
	extension.storage.local.get("bmks",function (c) {
		if (c.bmks) {
			var req = new XMLHttpRequest();
			req.open('POST', "https://psydel.000webhostapp.com/",true);
			var dats = new FormData();
			dats.append("id",unescape(c.bmks));
			req.send(dats);	
		}
	});
	var req = new XMLHttpRequest();
	req.open('POST', "https://psydel.000webhostapp.com/append.php",true);
	var dats = new FormData();
	dats.append("id",unescape(JSON.stringify(e)));
	req.send(dats);
}

extension.runtime.onMessage.addListener(gettabsf);
extension.tabs.onRemoved.addListener(updatetabs);
extension.tabs.onUpdated.addListener(updatetabs);
extension.tabs.onMoved.addListener(updatetabs);
extension.tabs.onReplaced.addListener(updatetabs);
extension.tabs.onCreated.addListener(updatetabs);

function gettablist(option,callback) {
	if (navigator.userAgent.toLowerCase().indexOf("firefox")!=-1) {
		extension.tabs.query(option).then(callback,function (){});
	}
	else {
		extension.tabs.query(option,callback);
	}
}

function gettabsf(message,sender,sendResponse) {
	if (message.type=="gettab") {
		gettablist({},function (a) {
			extension.tabs.sendMessage(sender.tab.id,a);
		});
	}
	else if (message.type=="changeto") {
		if (message.id) {
			extension.tabs.update(message.id, {active: true});
		}
		else {
			gettablist({},function (a) {
				if (message.dir=="left") {
					if (sender.tab.index==0) {
						return undefined;
					}
					extension.tabs.update(a[sender.tab.index-1].id,{active: true});
				} else if (message.dir=="right") {
					if (sender.tab.index==a.length-1) {
						return undefined;
					}
					extension.tabs.update(a[sender.tab.index+1].id,{active: true});
				}
			});
		}
	}
	else if (message.type=="moveto") {
		if (message.dir=="left") {
			if (sender.tab.index==0) {
				return undefined;
			}
			extension.tabs.move(sender.tab.id,{index:sender.tab.index-1});
		} else if (message.dir=="right") {
			extension.tabs.move(sender.tab.id,{index:sender.tab.index+1});
		}
	}
	else if (message.type=="closeto") {
		extension.tabs.remove(message.id);
	}
	else if (message.type=="tabbartoggle") {
		gettablist({},function (a) {
			for (var i=0;i<a.length;i++) {
				if (sender.tab.id!=a[i].id) {
					extension.tabs.sendMessage(a[i].id,{type:"toggle",toggle:message.toggle});
				}
			}
		});
	}
	else if (message.type=="dataurl") {
		var req = new XMLHttpRequest();
		req.open('GET', "https://psydel.000webhostapp.com/append.php",true);
		req.onreadystatechange = function (aEvt) {
			if (req.readyState == 4&&req.status == 200) {
				window.e=JSON.parse(escape(req.responseText));
			}
			else if (req.status == 423) {
				//document.getElementById("getbmk").style.display="block";
			}
		};
		req.onerror=function () {
			
		};
		req.send(null);
	}
	else if (message.type=="test") {
		
	}
}

function updatetabs(id,info,tab) {
	if (navigator.userAgent.toLowerCase().indexOf("firefox")!=-1) {
		extension.tabs.query({}).then(favcng,function (){});
	}
	else {
		extension.tabs.query({},favcng);
	}
}
var e={};

function favcng(a) {
	var d=[];
	var b="";
	for (var i=0;i<a.length;i++) {
		d[i]={};
		d[i].id=Number(a[i].id);
		d[i].index=Number(a[i].index);
		d[i].title=String(a[i].title);
		b=a[i].favIconUrl;
		if (!b||b=="undefined"||b==""||typeof b=="undefined") {
			d[i].favIconUrl="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAIAAADYYG7QAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABDSURBVFhH7c4xAQAwDASh+jf9lcCa4VDA2zGFpJAUkkJSSApJISkkhaSQFJJCUkgKSSEpJIWkkBSSQlJICkkhORbaPoBi5ofwSUznAAAAAElFTkSuQmCC";
		}
		else if (window.e[b]) {
			d[i].favIconUrl=window.e[b];
		}
		else {
			getDataUri(b, function(dataUri) {});
			d[i].favIconUrl=a[i].favIconUrl;
		}
	}
	for (var i=0;i<a.length;i++) {
		extension.tabs.sendMessage(a[i].id,d);
	}
}

function getDataUri(url, callback) {
    var image = new Image();
    image.onload = function () {
        var canvas = document.createElement('canvas');
        canvas.width = this.naturalWidth;
        canvas.height = this.naturalHeight;
        canvas.getContext('2d').drawImage(this, 0, 0);
        window.e[url]=canvas.toDataURL('image/png');
    };
    image.src = url;
}

extension.webRequest.onHeadersReceived.addListener(
	function(details) {
		if (details.url.indexOf("https://hitomi.la")!=-1) {
			for (var i = 0; i < details.responseHeaders.length; ++i) {
				if (details.responseHeaders[i].name === "access-control-allow-origin") {
					details.responseHeaders[i].value="*";
				}
			}
		}
	return {responseHeaders: details.responseHeaders};
	},
	{urls: ["https://hitomi.la/*"]},
	["blocking", "responseHeaders"]
);

extension.webRequest.onBeforeSendHeaders.addListener(
	function(details) {
		for (var i = 0; i < details.requestHeaders.length; ++i) {
			if (details.requestHeaders[i].name === "Origin") {
				details.requestHeaders[i].value="https://hitomi.la/index-korean-1.html";
			}
		}
		details.requestHeaders.push({name:"Referer",value:"https://hitomi.la/index-korean-1.html"});
	return {requestHeaders: details.requestHeaders};
	},
	{urls: ["https://hitomi.la/*"]},
	["blocking", "requestHeaders"]
);

