window.Button_Tab_Page = 0;

Extension_Tool_Functions.Add_Extension_Interface.f();

if (location.href.match(/^https?\:\/\/hitomi\.la/i)) {
	Extension_User_Functions.hab.f();
	Extension_User_Functions.hlb.f();
}

if (location.href.match(/^https?\:\/\/(m|www|bbs)\.ruliweb/i)) {
	Extension_User_Functions.rab.f();
}

if (location.href.indexOf("marumaru") != -1 || location.href.indexOf("wasabisyrup") != -1) {
	Extension_User_Functions.mab.f();
}

window.postMessage({
	type: "gettab",
	des: "back"
}, "*");

window.postMessage({
	type: "check",
	bmk: {}
}, "*");

window.addEventListener("mousedown",Extension_Tool_Functions.Fake_Scroll_Event.f);
window.addEventListener("mouseup",Extension_Tool_Functions.Fake_Scroll_Event_End.f);
window.addEventListener("message",Extension_Tool_Functions.On_Message.f);

setInterval(Extension_User_Functions.ael.f,40);

document.onmousedown=function () {};
