if (!browser) {
	var browser=chrome;
}

var __scr=document.createElement("script");
__scr.setAttribute("type","text/javascript");
document.head.appendChild(__scr);
__scr.setAttribute("onload","this.parentNode.removeChild(this)");
__scr.setAttribute("src",browser.runtime.getURL("all2.js"));