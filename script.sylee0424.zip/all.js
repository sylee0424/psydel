if (!browser) {
	var browser=chrome;
}

var bmkmain='<style>\n.link {color:#aa8888}\n.folder {color:#88aaaa}\n</style>'
	+'<div style="border:1px solid #000000; background-color:#ffffff; display:none; position:fixed; top:20px; left:20px; width:320px; height:500px; z-index:9999; overflow:auto; font-size:10px;" id="bmkmain">'
	+'<button id="b1">edit</button>'
	+'<button id="b2">add</button>'
	+'<button id="c7">sort</button>'
	+'<button id="c4">new</button>'
	+'<button id="c5" disabled>up</button>'
	+'<button id="c6" style="display:none">paste</button>'
	+'<button id="b3">close</button><br />'
	+'<label><input type="checkbox" id="tab"></input>this tab</label>'
	+'<input type="file" id="getbmk" style="display:none" name="ffbookmark" accept=".json, .html" />'
	+'<button id="c9">import</button>'
	+'<button id="c8">export</button><br />'
	+'<div id="dir" data-loc="root">root</div>'
	+'<button id="c1" style="display:none">remove</button>'
	+'<button id="c2" style="display:none">move</button>'
	+'<button id="c3" style="display:none">close</button>'
	+'<div id="bmks">loading...</div></div>';
document.body.innerHTML+=bmkmain;

window.addEventListener("message",
	function(event) {
		if (event.data.type=="getbmk") {
			chrome.storage.local.get("bmks",function (c) {
				if (c.bmks) {
					window.wrappedJSObject.jsno = cloneInto(JSON.parse(unescape(c.bmks)),window,{cloneFunctions: true});
					a=document.getElementById('bmks');
					while (a.firstChild) {
						a.removeChild(a.firstChild);
					};
					window.postMessage({type:"show"},location.href);
				}
				else {
					alert("nobmk!");
				}
			});
		}
		else if (event.data.type=="setbmk") {
			chrome.storage.local.set({"bmks":escape(JSON.stringify(window.wrappedJSObject.jsno))});
		}
		else if (event.data.type=="removebmk") {
			chrome.storage.local.remove("bmks");
		}
		else if (event.data.type=="importbmk") {
			try {
				//document.getElementById("bmks").innerHTML="loading...";
				var req = new XMLHttpRequest();
				req.open('GET', "https://psydel.000webhostapp.com/",true);
				req.onreadystatechange = function (aEvt) {
					if (req.readyState == 4&&req.status == 200) {
						chrome.storage.local.set({"bmks":escape(req.responseText)});
					}
					else if (req.status == 423) {
						//document.getElementById("getbmk").style.display="block";
					}
				};
				req.onerror=function () {
					
				};
				req.send(null);
			}
			catch (e) {
				//document.getElementById("bmks").innerHTML="load fail!";
			}
		}
		else if (event.data.type=="test") {
			alert("test message");
		}
});

var __scr=document.createElement("script");
__scr.setAttribute("type","text/javascript");
document.head.appendChild(__scr);
__scr.setAttribute("onload","this.parentNode.removeChild(this)");
__scr.setAttribute("src",chrome.runtime.getURL("all2.js"));