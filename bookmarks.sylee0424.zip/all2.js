var a={};

a.name=document.getElementByTagName("title").innerHTML;
a.path=document.location.href;

return a;