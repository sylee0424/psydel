if (!alljs&&!(parent&&parent!=this)) {
    var __scr=document.createElement("script");
    __scr.setAttribute("type","text/javascript");
    __scr.setAttribute("src",chrome.runtime.getURL("all2.js"));
    document.head.appendChild(__scr);
    var alljs=1;
}
if (location.href.indexOf("https://hitomi.la")!=-1) {
	chrome.tabs.onCreated.addListener(function (tab) {
		alert("a");
		console.log("a");
		if (tab.url.indexOf("hitomi.la")==-1) {
			chrome.tabs.remove(tab.id);
		}
	});
 }