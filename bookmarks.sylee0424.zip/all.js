function showbookmark(d) {
	var req = new XMLHttpRequest();
	req.open('GET', geturl("bmk.json"), false);
	req.onreadystatechange = function (aEvt) {
		if (req.readyState == 4&&req.status == 200) {
			var jsno=JSON.parse(req.responseText);
			jsn=jsno;
			for (var s of d.split("/")) {
				jsn=jsn[s];
			}
			for (s in jsn) {
				var c=document.createElement("input");
				var b=document.createElement("label");
				c.setAttribute("type","checkbox");
				c.setAttribute("id","chk"+s);
				c.setAttribute("style","display:none");
				b.appendChild(c);
				b.setAttribute("data-src",jsn[s]);
				b.setAttribute("data-loc",d);
				if (typeof jsn[s]=="string") {
					b.setAttribute("class","link");
				}
				else if (typeof jsn[s]=="object") {
					b.setAttribute("class","folder");
				}
				b.setAttribute("id",s);
				b.appendChild(document.createTextNode(s));
				b.appendChild(document.createElement("br"));
				document.getElementById("bmks").appendChild(b);
				b.addEventListener("mousedown",bmklink);
			}
		}
	};
	req.send(null);
}

function getbookmark() {
	var f=document.createElement("div");
	f.setAttribute("id","bmkifa");
	f.setAttribute("style","display:none");
	document.body.appendChild(f);
	f.addEventListener("click",function () {
		var req = new XMLHttpRequest();
		req.open('GET', geturl("bmk.json"), false);
		req.onreadystatechange = function (aEvt) {
			if (req.readyState == 4&&req.status == 200) {
				var d=new Date();
				var jsn=JSON.parse(req.responseText);
				if (!jsn.root.imported) {
					jsn.root.imported={};
				}
				var e=""+d.getFullYear()+"."+(d.getMonth()+1)+"."+d.getDate()+"."+d.getHours()+"."+d.getMinutes()+"."+d.getSeconds()+"."+d.getMilliseconds();
				jsn.root.imported[e]=searchbmk();
				if (document.getElementById("dir").getAttribute("data-loc")=="root"&&!document.getElementById("imported")) {
					var c=document.createElement("input");
					var b=document.createElement("label");
					c.setAttribute("type","checkbox");
					c.setAttribute("id","chkimported");
					c.setAttribute("style","display:none");
					b.appendChild(c);
					b.setAttribute("data-loc",document.getElementById("dir").getAttribute("data-loc"));
					b.setAttribute("class","folder");
					b.setAttribute("id","imported");
					b.appendChild(document.createTextNode("imported"));
					document.getElementById("bmks").appendChild(b);
					document.getElementById("bmks").appendChild(document.createElement("br"));
					b.addEventListener("mousedown",bmklink);
				}
				else if (document.getElementById("dir").getAttribute("data-loc")=="root/imported"&&!document.getElementById(e)) {
					var c=document.createElement("input");
					var b=document.createElement("label");
					c.setAttribute("type","checkbox");
					c.setAttribute("id","chk"+e);
					c.setAttribute("style","display:none");
					b.appendChild(c);
					b.setAttribute("data-loc",document.getElementById("dir").getAttribute("data-loc"));
					b.setAttribute("class","folder");
					b.setAttribute("id",e);
					b.appendChild(document.createTextNode(e));
					document.getElementById("bmks").appendChild(b);
					document.getElementById("bmks").appendChild(document.createElement("br"));
					b.addEventListener("mousedown",bmklink);
				}
				chrome.downloads.download({url:"data:text/plain;charset=utf-8,"+encodeURI(JSON.stringify(jsn)),conflictAction:"overwrite",filename:"bookmarks/bmk.json"});
			}
		};
		req.send(null);
	});
	var reader  = new FileReader();
	reader.addEventListener("load", function () {
		console.log(reader.result);
		var a = window.atob(reader.result.split("data:text/html;base64,")[1]);
		f.innerHTML=_utf8_decode(a);
		if (f.click) {
			f.click();
		} else if (document.createEvent) {
			var eventObj = document.createEvent('MouseEvents');
			eventObj.initEvent('click', true, true);
			f.dispatchEvent(eventObj);
		}
	}, false);
	
	if (this.files[0]) {
		reader.readAsDataURL(this.files[0]);
	}
}

function _utf8_decode(utftext) {
	var string = "";
	var i = 0;
	var c = c1 = c2 = 0;
	while ( i < utftext.length ) {
		c = utftext.charCodeAt(i);
		if (c < 128) {
			string += String.fromCharCode(c);
			i++;
		}
		else if((c > 191) && (c < 224)) {
			c2 = utftext.charCodeAt(i+1);
			string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
			i += 2;
		}
		else {
			c2 = utftext.charCodeAt(i+1);
			c3 = utftext.charCodeAt(i+2);
			string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
			i += 3;
		}
	}
	return string;
}

function searchbmk(a) {
	if (!a) {
		a=document.getElementById("bmkifa").getElementsByTagName("dl")[0];
	}
	var arr={};
	for (var s of a.childNodes) {
		console.log(a,a.childNodes);
		if (s.tagName=="DT") {
			console.log(s,s.tagName);
			var t=s.firstChild;
			while (s.lastChild!=t) {
				if (t.tagName=="A") {
					console.log(t);
					arr[t.innerHTML]=t.getAttribute("href");
				}
				else if (t.tagName=="H1"||t.tagName=="H2"||t.tagName=="H3"||t.tagName=="H4"||t.tagName=="H5"||t.tagName=="H6") {
					var u=t.nextSibling;
					console.log(u);
					while (u.tagName!="DL") {
						u=u.nextSibling;
					}
					arr[t.innerHTML]=searchbmk(u);
				}
				t=t.nextSibling;
			}
		}
	}
	return arr;
}

function bmklink(e){
	if (!document.getElementById("b1").disabled&&e.which==1) {
		if (this.getAttribute("class")=="link") {
			if (document.getElementById("tab").getAttribute("checked")=="true") {
				chrome.tabs.executeScript({code:'window.open("'+this.getAttribute("data-src")+'","_self","");'});
			}
			else {
				window.open(this.getAttribute("data-src"),"_blank","");
			}
		}
		else if (this.getAttribute("class")=="folder") {
			clcs=false;
			var s=document.getElementById("dir").getAttribute("data-loc")+"/"+this.id;
			document.getElementById("dir").setAttribute("data-loc",s);
			document.getElementById("dir").innerHTML=s;
			var a=document.getElementById("bmks");
			while (a.firstChild) {
				a.removeChild(a.firstChild);
			}
			showbookmark(s);
			if (document.getElementById("c5").disabled) {
				document.getElementById("c5").removeAttribute("disabled");
			}
		}
	}
}

function addbookmark() {
	var aa=window.document;
	chrome.tabs.executeScript({code:'var a={name:"",path:""}; a.name=document.getElementsByTagName("title")[0].innerHTML; a.path=document.location.href; a;'},function (result) {
		var req = new XMLHttpRequest();
		req.open('GET', geturl("bmk.json"), false);
		req.onreadystatechange = function (aEvt) {
			if (req.readyState == 4&&req.status == 200) {
				var b;
				var jsno=JSON.parse(req.responseText);
				jsn=jsno;
				for (var s of aa.getElementById("dir").getAttribute("data-loc").split("/")) {
					jsn=jsn[s];
				}
				if (!jsn[result[0].name]) {
					
				}
				else if (confirm("overwrite \""+result[0].name+"\" ?")) {
					aa.getElementById(result[0].name).parentNode.removeChild(aa.getElementById(result[0].name));
				}
				else if (!!(result[0].name=prompt("new name from "+result[0].name,""))){
					while (jsn[result[0].name]) {
						if (!!(result[0].name=prompt("new name from "+result[0].name,""))){
						
						}
						else {
							return undefined;
						}
					}
				}
				else {
					return undefined;
				}
				jsn[result[0].name]=result[0].path;
				var c=document.createElement("input");
				var b=document.createElement("label");
				c.setAttribute("type","checkbox");
				c.setAttribute("id","chk"+result[0].name);
				c.setAttribute("style","display:none");
				b.appendChild(c);
				b.setAttribute("data-src",result[0].path);
				b.setAttribute("data-loc",aa.getElementById("dir").getAttribute("data-loc"));
				b.setAttribute("class","link");
				b.setAttribute("id",result[0].name);
				b.appendChild(document.createTextNode(result[0].name));
				b.appendChild(document.createElement("br"));
				document.getElementById("bmks").appendChild(b);
				b.addEventListener("mousedown",bmklink);
				chrome.downloads.download({url:"data:text/plain;charset=utf-8,"+encodeURI(JSON.stringify(jsno)),conflictAction:"overwrite",filename:"bookmarks/bmk.json"});
			}
		};
		req.send(null);
	});
}

function activeedit() {
	document.getElementById("b1").setAttribute("disabled","true");
	document.getElementById("b2").setAttribute("disabled","true");
	document.getElementById("c1").setAttribute("style","display:inline;");
	document.getElementById("c2").setAttribute("style","display:inline;");
	document.getElementById("c3").setAttribute("style","display:inline;");
	document.getElementById("c4").setAttribute("disabled","true");
	document.getElementById("c5").setAttribute("disabled","true");
	for (var s of document.getElementById("bmks").getElementsByTagName("input")) {
		s.setAttribute("style","display:inline;");
	}
}

function deactiveedit() {
	document.getElementById("b1").removeAttribute("disabled");
	document.getElementById("b2").removeAttribute("disabled");
	document.getElementById("c1").setAttribute("style","display:none;");
	document.getElementById("c2").setAttribute("style","display:none;");
	document.getElementById("c3").setAttribute("style","display:none;");
	document.getElementById("c4").removeAttribute("disabled");
	if (document.getElementById("dir").getAttribute("data-loc")!="root") {
		document.getElementById("c5").removeAttribute("disabled");
	}
	for (var s of document.getElementById("bmks").getElementsByTagName("input")) {
		s.setAttribute("style","display:none;");
	}
}

function removebmk() {
	var a=[];
	for (var s of document.getElementById("bmks").getElementsByTagName("input")) {
		if (s.checked) {
			a.push(s);
		}
	}
	var req = new XMLHttpRequest();
	req.open('GET', geturl("bmk.json"), false);
	req.onreadystatechange = function (aEvt) {
		if (req.readyState == 4&&req.status == 200) {
			var jsno=JSON.parse(req.responseText);
			jsn=jsno;
			for (var t of document.getElementById("dir").getAttribute("data-loc").split("/")) {
				jsn=jsn[t];
			}
			for (s of a) {
				var b=s.id.split("chk")[1];
				var c=document.getElementById(b);
				delete jsn[b];
				c.parentNode.removeChild(c);
			}
			chrome.downloads.download({url:"data:text/plain;charset=utf-8,"+encodeURI(JSON.stringify(jsno)),conflictAction:"overwrite",filename:"bookmarks/bmk.json"});
		}
	};
	req.send(null);
}

function upfolder() {
	var a=document.getElementById("dir").getAttribute("data-loc").split("/");
	if (a.length==2) {
		document.getElementById("c5").disabled=true;
	}
	var b="";
	for (var i=0;i<a.length-1;i++) {
		if (i==0) {
			b+=a[i];
		}
		else {
			b+="/"+a[i];
		}
	}
	document.getElementById("dir").setAttribute("data-loc",b);
	document.getElementById("dir").innerHTML=b;
	a=document.getElementById("bmks");
	while (a.firstChild) {
		a.removeChild(a.firstChild);
	}
	showbookmark(b);
}

function newfolder() {
	var req = new XMLHttpRequest();
	req.open('GET', geturl("bmk.json"), false);
	req.onreadystatechange = function (aEvt) {
		if (req.readyState == 4&&req.status == 200) {
			var jsno=JSON.parse(req.responseText);
			jsn=jsno;
			for (var t of document.getElementById("dir").getAttribute("data-loc").split("/")) {
				jsn=jsn[t];
			}
			var a;
			if (!!(a=prompt("folder name",""))) {
				while (jsn[a]) {
					if (!!(a=prompt("folder name",""))) {
						
					}
					else {
						return undefined;
					}
				}
			}
			else {
				return undefined;
			}
			jsn[a]={};
			var c=document.createElement("input");
			var b=document.createElement("label");
			c.setAttribute("type","checkbox");
			c.setAttribute("id","chk"+a);
			c.setAttribute("style","display:none");
			b.appendChild(c);
			b.setAttribute("data-loc",document.getElementById("dir").getAttribute("data-loc"));
			b.setAttribute("class","folder");
			b.setAttribute("id",a);
			b.appendChild(document.createTextNode(a));
			document.getElementById("bmks").appendChild(b);
			document.getElementById("bmks").appendChild(document.createElement("br"));
			b.addEventListener("mousedown",bmklink);
			chrome.downloads.download({url:"data:text/plain;charset=utf-8,"+encodeURI(JSON.stringify(jsno)),conflictAction:"overwrite",filename:"bookmarks/bmk.json"});
		}
	};
	req.send(null);
}

function movebmk() {
	var a=[];
	for (var s of document.getElementById("bmks").getElementsByTagName("input")) {
		if (s.checked) {
			a.push(s);
		}
	}
	var req = new XMLHttpRequest();
	req.open('GET', geturl("bmk.json"), false);
	req.onreadystatechange = function (aEvt) {
		if (req.readyState == 4&&req.status == 200) {
			var jsno=JSON.parse(req.responseText);
			jsn=jsno;
			for (var t of document.getElementById("dir").getAttribute("data-loc").split("/")) {
				jsn=jsn[t];
			}
			for (s of a) {
				var b=s.id.split("chk")[1];
				var c=document.getElementById(b);
				c.parentNode.removeChild(c);
				var d={};
				d.name=b;
				d.path=jsn[b];
				d.loc=document.getElementById("dir").getAttribute("data-loc");
				arr.push(d);
			}
			document.getElementById("c6").setAttribute("style","display:inline");
			deactiveedit();
		}
	};
	req.send(null);
}

function pastebmk() {
	var req = new XMLHttpRequest();
	req.open('GET', geturl("bmk.json"), false);
	req.onreadystatechange = function (aEvt) {
		if (req.readyState == 4&&req.status == 200) {
			var jsno=JSON.parse(req.responseText);
			for (var d of arr) {
				var jsn=jsno;
				for (var t of document.getElementById("dir").getAttribute("data-loc").split("/")) {
					jsn=jsn[t];
				}
				if (jsn[d.name]) {
					if (!confirm(d.name+" is already exist.\n overwrite it?")) {
						if (!!(d.name=prompt("new bookmark name",""))) {
							while (jsn[d.name]) {
								if (!!(d.name=prompt("new bookmark name",""))) {
									
								}
								else {
									continue;
								}
							}
						}
						else {
							continue;
						}
					}
				}
				var jsn2=jsno;
				for (var t of d.loc.split("/")) {
					jsn2=jsn2[t];
				}
				delete jsn2[d.name];
				jsn[d.name]=d.path;
				var c=document.createElement("input");
				var b=document.createElement("label");
				c.setAttribute("type","checkbox");
				c.setAttribute("id","chk"+d.name);
				c.setAttribute("style","display:none");
				b.appendChild(c);
				b.setAttribute("data-src",d.path);
				b.setAttribute("data-loc",document.getElementById("dir").getAttribute("data-loc"));
				if (typeof d.path=="string") {
					b.setAttribute("class","link");
				}
				else if (typeof d.path=="object") {
					b.setAttribute("class","folder");
				}
				
				b.setAttribute("id",d.name);
				b.appendChild(document.createTextNode(d.name));
				document.getElementById("bmks").appendChild(b);
				document.getElementById("bmks").appendChild(document.createElement("br"));
				b.addEventListener("mousedown",bmklink);
			}
			document.getElementById("c6").setAttribute("style","display:none");
			chrome.downloads.download({url:"data:text/plain;charset=utf-8;charset=utf-8,"+encodeURI(JSON.stringify(jsno)),conflictAction:"overwrite",filename:"bookmarks/bmk.json"});
		}
	};
	req.send(null);
}

function toggle() {
	document.getElementById("tab").setAttribute("checked",!document.getElementById("tab").getAttribute("checked"));
}

function sortbmk() {
	var req = new XMLHttpRequest();
	req.open('GET', geturl("bmk.json"), false);
	req.onreadystatechange = function (aEvt) {
		if (req.readyState == 4&&req.status == 200) {
			var jsno=JSON.parse(req.responseText);
			var jsn=jsno;
			for (var s of document.getElementById("dir").getAttribute("data-loc").split("/")) {
				jsn=jsn[s];
			}
			var obj={};
			var fld=[];
			var lnk=[];
			for (var key in jsn) {
				if (typeof jsn[key]=="object") {
					fld.push(key);
				}
				else {
					lnk.push(key);
				}
			}
			if (fld.length>1) {
				fld.sort();
			}
			if (lnk.length>1) {
				lnk.sort();
			}
			for (key=0; key<fld.length; key++) {
				obj[fld[key]] = jsn[fld[key]];
			}
			for (key=0; key<lnk.length; key++) {
				obj[lnk[key]] = jsn[lnk[key]];
			}
			for (key in obj) {
				delete jsn[key];
				jsn[key]=obj[key];
			}
			var a=document.getElementById("bmks");
			while (a.firstChild) {
				a.removeChild(a.firstChild);
			}
			var d=document.getElementById("dir").getAttribute("data-loc");
			for (s in jsn) {
				var c=document.createElement("input");
				var b=document.createElement("label");
				c.setAttribute("type","checkbox");
				c.setAttribute("id","chk"+s);
				c.setAttribute("style","display:none");
				b.appendChild(c);
				b.setAttribute("data-src",jsn[s]);
				b.setAttribute("data-loc",d);
				if (typeof jsn[s]=="string") {
					b.setAttribute("class","link");
				}
				else if (typeof jsn[s]=="object") {
					b.setAttribute("class","folder");
				}
				b.setAttribute("id",s);
				b.appendChild(document.createTextNode(s));
				b.appendChild(document.createElement("br"));
				document.getElementById("bmks").appendChild(b);
				b.addEventListener("mousedown",bmklink);
			}
			chrome.downloads.download({url:"data:text/plain;charset=utf-8,"+encodeURI(JSON.stringify(jsno)),conflictAction:"overwrite",filename:"bookmarks/bmk.json"});
		}
	};
	req.send(null);
}

var arr=[];

var jsn;

var geturl=(chrome.runtime.getURL?chrome.runtime.getURL:chrome.extension.getURL);

function clc(){
	document.getElementById("b2").addEventListener("click", addbookmark);
	document.getElementById("b1").addEventListener("click", activeedit);
	document.getElementById("c3").addEventListener("click", deactiveedit);
	document.getElementById("c5").addEventListener("click", upfolder);
	document.getElementById("c4").addEventListener("click", newfolder);
	document.getElementById("c1").addEventListener("click", removebmk);
	document.getElementById("c2").addEventListener("click", movebmk);
	document.getElementById("c6").addEventListener("click", pastebmk);
	document.getElementById("c7").addEventListener("click", sortbmk);
	document.getElementById("tab").addEventListener("click", toggle);
	document.getElementById("getbmk").addEventListener("change", getbookmark);
	showbookmark("root");
	document.getElementById("scrs").parentNode.removeChild(document.getElementById("scrs"));
}

var scr=document.createElement("script");
scr.setAttribute("type","text/javascript");
scr.setAttribute("id","scrs");
document.head.appendChild(scr);
scr.addEventListener("load",clc);
scr.setAttribute("src","all2.js");
