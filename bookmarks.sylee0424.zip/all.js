function setbookmark() {
	var req = new XMLHttpRequest();
	req.open('GET', geturl("bmk.json"), false);
	req.onreadystatechange = function (aEvt) {
		if (req.readyState == 4&&req.status == 200) {
			jsn=JSON.parse(req.responseText);
			for (var s in jsn) {
				chrome.bookmarks.create({'parentId': bookmarkBar.id,'title': jsn[s].name,'url': jsn[s].path});
			}
		}
	};
	req.send(null);
}

function addbookmark() {
	var tabids;
	chrome.tabs.query(
		{ currentWindow: true, active: true },
		function (a) { tabids=a[0].id; }
	);
	chrome.tabs.executeScript(tabids,{code:'console.log("a"); var a={name:"",path:""}; a.name=document.getElementsByTagName("title")[0].innerHTML; a.path=document.location.href; a;'},function (result) {
		var req = new XMLHttpRequest();
		req.open('GET', geturl("bmk.json"), false);
		req.onreadystatechange = function (aEvt) {
			if (req.readyState == 4&&req.status == 200) {
				jsn=JSON.parse(req.responseText);
				jsn[""+Object.keys(jsn).length]=result[0];
				chrome.downloads.download({url:"data:text/plain,"+encodeURI(JSON.stringify(jsn)),conflictAction:"overwrite",filename:"bookmarks/bmk.json"});
			}
		};
		req.send(null);
	});
}
var jsn;
var geturl=(chrome.runtime.getURL?chrome.runtime.getURL:chrome.extension.getURL);

function clc(){
	if (!alls) {
		var alls=true;
		document.getElementById("b1").addEventListener("click", function(){setbookmark()});
		document.getElementById("b2").addEventListener("click", function(){addbookmark()});
		document.removeEventListener("mouseover",clc );
	}
}

document.addEventListener("mouseover",clc );
