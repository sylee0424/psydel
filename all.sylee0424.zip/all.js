if (!browser) {
	var browser=chrome;
}

window.arr=[];
window.arr2=[];

function movefixed(element) {
	if (!element) {
		element = document.documentElement;
	}
	if (element.nodeName != "#text" && element.tagName && element.nodeName != "#comment") {
		if (element.hasAttribute("src")||element.hasAttribute("href")) {
			arr[arr.length]=element;
			arr2[arr2.length]=false;
		}
	}
	console.log(element.childNodes);
	for (var i=0;i<element.childNodes.length;i++) {
		movefixed(element.childNodes[i]);
	}
	if (element==document.documentElement) {
		getdatauri();
	}
}

function getdatauri(){
	for (var i=0;i<arr.length;i++) {
		if (arr[i].hasAttribute("src")) {
			var url=element.getAttribute("src");
		}
		else {
			var url=element.getAttribute("href");
		}
		getDataUri(arr[i].hasAttribute("src"),url,i)
	}
}

function getDataUri(has,url,index) {
    var req = new XMLHttpRequest();
	req.open('GET',url,true);
	req.onreadystatechange = function (aEvt) {
		if (req.readyState == 4&&req.status == 200) {
			if (has) {
				var a="src";
			}
			else {
				var a="href";
			}
			if (window.arr[index].tagName=="image") {
				var b="data:image/png;base64,"
			}
			else {
				var b="data:text/html;base64,"
			}
			window.arr[index].setAttribute(a,b+btoa(req.responseText));
			window.arr2[index].shift();
			if (window.arr2.length==0) {
				
			}
		}
	};
	req.send(null);
}
//movefixed();

var div= document.createElement("div");
div.style="border:1px solid #000000; background-color:#ffffff; display:none; position:fixed; top:50px; left:20px; width:320px; height:0px; z-index:9999; overflow:auto; font-size:10px;";
div.id="bmkmain";
document.body.appendChild(div);

var div= document.createElement("div");
div.style="white-space:nowrap; border:1px solid #000000; display:none; background-color:#ffffff; position:fixed; top:0px; left:0px; width:100%; height:50px; z-index:9999; overflow-y:hidden; overflow-x:auto; font-size:10px;";
div.id="tabbar";
document.body.appendChild(div);

div=document.createElement("button");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="b1";
div.appendChild(document.createTextNode("edit"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="b2";
div.appendChild(document.createTextNode("add"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c7";
div.appendChild(document.createTextNode("sort"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c4";
div.appendChild(document.createTextNode("new"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="filter:invert(); border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c5";
div.disabled=true;
div.appendChild(document.createTextNode("up"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="display:none; border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c6";
div.appendChild(document.createTextNode("paste"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="b3";
div.appendChild(document.createTextNode("close"));
document.getElementById("bmkmain").appendChild(div);
document.getElementById("bmkmain").appendChild(document.createElement("br"));

var lvl=document.createElement("label");
div=document.createElement("input");
div.type="checkbox";
div.id="tab";
lvl.appendChild(div);
lvl.appendChild(document.createTextNode("this tab"));
document.getElementById("bmkmain").appendChild(lvl);

div=document.createElement("input");
div.type="file";
div.style="display:none";
div.id="getbmk";
div.name="ffbookmark";
div.accept=".json";
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c9";
div.appendChild(document.createTextNode("import"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="white-space:nowrap; border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px; overflow-y:hidden; overflow-x:auto;";
div.id="c8";
div.appendChild(document.createTextNode("export"));
document.getElementById("bmkmain").appendChild(div);
document.getElementById("bmkmain").appendChild(document.createElement("br"));

div=document.createElement("div");
div.setAttribute("data-loc","root");
div.id="dir";
div.appendChild(document.createTextNode("root"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="display:none; border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c1";
div.appendChild(document.createTextNode("remove"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="display:none; border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c2";
div.appendChild(document.createTextNode("move"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("button");
div.style="display:none; border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="c3";
div.appendChild(document.createTextNode("end"));
document.getElementById("bmkmain").appendChild(div);

div=document.createElement("div");
div.style="border:1px solid #000000; background-color:#ffffff; margin:1px; padding:1px; font-size:10px;";
div.id="bmks";
div.appendChild(document.createTextNode("loading..."));
document.getElementById("bmkmain").appendChild(div);

window.addEventListener("message",
	function(event) {
		if (event.data.type=="getbmk") {
			chrome.storage.local.get("bmks",function (c) {
				if (c.bmks) {
					if (typeof cloneInto!="undefined") {
						window.wrappedJSObject.jsno = cloneInto(JSON.parse(unescape(c.bmks)),window,{cloneFunctions: true});
						window.postMessage({type:"show"},location.href);
					}
					else {
						div=document.createElement("div");
						div.style="display:none";
						div.id="bmksdata";
						document.body.appendChild(div);
						div.innerHTML=c.bmks;
						window.postMessage({type:"show"},location.href);
					}
				}
				else {
					alert("nobmk!");
				}
			});
		}
		else if (event.data.type=="setbmk") {
			chrome.storage.local.set({"bmks":escape(JSON.stringify(event.data.bmk))});
		}
		else if (event.data.type=="removebmk") {
			chrome.storage.local.remove("bmks");
		}
		else if (event.data.type=="importbmk") {
			try {
				//document.getElementById("bmks").innerHTML="loading...";
				var req = new XMLHttpRequest();
				req.open('GET', "https://psydel.000webhostapp.com/",true);
				req.onreadystatechange = function (aEvt) {
					if (req.readyState == 4&&req.status == 200) {
						chrome.storage.local.set({"bmks":escape(req.responseText)});
					}
					else if (req.status == 423) {
						//document.getElementById("getbmk").style.display="block";
					}
				};
				req.onerror=function () {
					
				};
				req.send(null);
			}
			catch (e) {
				//document.getElementById("bmks").innerHTML="load fail!";
			}
		}
		else if (event.data.type=="check") {
			chrome.storage.local.get("bmks",function (c) {
				if (unescape(c.bmks)!=JSON.stringify(event.data.bmks)) {
					var rtn=Object.assign({},event.data.bmk,JSON.parse(unescape(c.bmks)));
					window.postMessage({type:"update",bmk:rtn},location.href);
				}
			});
		}
		else if (event.data.type=="gettab") {
			chrome.runtime.sendMessage(chrome.runtime.id,event.data);
		}
		else if (event.data.type=="changeto") {
			chrome.runtime.sendMessage(chrome.runtime.id,event.data);
		}
		else if (event.data.type=="moveto") {
			chrome.runtime.sendMessage(chrome.runtime.id,event.data);
		}
		else if (event.data.type=="closeto") {
			chrome.runtime.sendMessage(chrome.runtime.id,event.data);
		}
		else if (event.data.type=="tabbartoggle") {
			chrome.runtime.sendMessage(chrome.runtime.id,event.data);
		}
		else if (event.data.des=="back") {
			chrome.runtime.sendMessage(chrome.runtime.id,event.data);
		}
		else if (event.data.type=="test") {
			alert("test message");
		}
});

chrome.runtime.onMessage.addListener(gettabsf);

function gettabsf(message,sender,sendResponse) {
	window.postMessage({type:"tabs",tab:message},location.href);
}

var __scr=document.createElement("script");
__scr.setAttribute("type","text/javascript");
document.head.appendChild(__scr);
__scr.setAttribute("onload","this.parentNode.removeChild(this)");
__scr.setAttribute("src",chrome.runtime.getURL("all2.js"));
