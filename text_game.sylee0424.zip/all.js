// function tab {

function Equipment()
{
	var req = new Object();
	var i=0;
	req.id="000001";
	req.type="sword";
	req.limit={ };
	req.damage=1;
	req.effect={ };
	req.descrption="normal sword";
	req.value=100;
	if (arguments[0]&&eqs[arguments[0]])
	{
		req=eqs[arguments[0]];
	}
	for (var s in req)
	{
		if (i<arguments.length&&arguments[i])
		{
			req[s]=arguments[i];
			i++;
		}
	}
    return req;
}

function OpenDG(map)
{
	var a,b=-1;
	map.width=dg[map.id].width;
	map.height=dg[map.id].height;
	map.align=dg[map.id].align;
	map.data=dg[map.id].data;
	map.cells=createCells(Number(map.width),Number(map.height));
	map.loc.x=Math.floor(Math.random()*map.width);
	map.loc.y=Math.floor(Math.random()*map.height);
	if (map.data.tile.upstair)
	{
		map.cells[(a=Math.floor(Math.random()*map.width))][(b=Math.floor(Math.random()*map.height))].status+="us";
		if (map.align=="down")
		{
			map.loc.x=a;
			map.loc.y=b
		}
	}
	if (map.data.tile.downstair)
	{
		if (a!=-1) {
			map.cells[(a=(a+1+Math.floor(Math.random()*(map.width-2)))%map.width)][(b=(b+1+Math.floor(Math.random()*(map.height-2)))%map.height)].status+="ds";
		}
		else {
			map.cells[(a=Math.floor(Math.random()*map.width))][(b=Math.floor(Math.random()*map.height))].status+="ds";
		}
		if (map.align=="up") {
			map.loc.x=a;
			map.loc.y=b
		}
	}
	viewmap();
	for (var s in map.cells[map.loc.x][map.loc.y].around)
	{
		if (map.cells[map.loc.x][map.loc.y].connected[s]) {
			document.getElementById(""+(map.loc.x-(s=="left")+(s=="right")+""+(map.loc.y-(s=="down")+(s=="up")))).setAttribute("onclick","go_to('"+s+"');");
		}
	}
}

/*
7 �� �� �� �� �� �� �� �� �� ��
6 �� �� �� �� �� �� �� �� �� ��
5 �� �� �� �� �� �� �� �� �� ��
4 �� �� �� �� �� �� �� �� �� ��
3 �� �� �� �� �� �� �� �� �� ��
2 �� �� �� �� �� �� �� �� �� ��
1 �� �� �� �� �� �� �� �� �� ��
0 �� �� �� �� �� �� �� �� �� ��
ij0 1 2 3 4 5 6 7 8 9
*/

function viewmap()
{
	var a=document.getElementById("maptable");
	a.removeChild(a.firstChild);
	var b=document.createElement("tbody");
	b.appendChild(document.createTextNode(" "));
	for (var i=0;i<map.height;i++)
	{
		var c=document.createElement("tr");
		c.style="height:30px";
		for (var j=0;j<map.width;j++)
		{
			var d=document.createElement("td");
			d.style="text-align:center; width:30px; border-collapse:collapse; border-spacing:0px; border-top:"+Number(!(map.cells[j][i].connected.up))+"px solid black;"+"border-bottom:"+Number(!(map.cells[j][i].connected.down))+"px solid black;"+"border-left:"+Number(!(map.cells[j][i].connected.left))+"px solid black;"+"border-right:"+Number(!(map.cells[j][i].connected.right))+"px solid black;";
			d.id=""+j+""+i;
			c.appendChild(d);
		}
		b.insertBefore(c,b.firstChild);
	}
	b.removeChild(b.lastChild);
	a.appendChild(b);
	document.body.appendChild(a);
	for (var i=0;i<map.height;i++)
	{
		for (var j=0;j<map.width;j++)
		{
			mapstat(j,i);
		}
	}
}

function createCells(width,height)
{
	var a=new Array(width);
	for (var i=0;i<width;i++)
	{
		a[i]=new Array(height);
		for (var j=0;j<height;j++)
		{
			a[i][j]=acell();
		}
	}
	for (i=0;i<width;i++)
	{
		for (var j=0;j<height;j++)
		{
			if (j!=height-1)
			{
				a[i][j].around.up=a[i][j+1];
			}
			if (j!=0)
			{
				a[i][j].around.down=a[i][j-1];
			}
			if (i!=0)
			{
				a[i][j].around.left=a[i-1][j];
			}
			if (i!=width-1)
			{
				a[i][j].around.right=a[i+1][j];
			}
			a[i][j].loc.x=i;
			a[i][j].loc.y=j;
		}
	}
	var b=a[Math.floor(Math.random()*width)][Math.floor(Math.random()*height)];
	var c=new Array();
	var d=new Array();
	for (var s in b.around)
	{
		if (b.around[s].connected.up==false&&b.around[s].connected.down==false&&b.around[s].connected.left==false&&b.around[s].connected.right==false)
		{
			c.push(b.around[s]);
			d.push(s);
		}
	}
	i=width*height-1;
	while (i--)
	{
		var j=Math.floor(Math.random()*c.length);
		c[j].around[inv(d[j])].connected[d[j]]=true;
		c[j].connected[inv(d[j])]=true;
		for (s in c[j].around)
		{
			if (c[j].around[s].connected.up==false&&c[j].around[s].connected.down==false&&c[j].around[s].connected.left==false&&c[j].around[s].connected.right==false)
			{
				c.push(c[j].around[s]);
				d.push(s);
			}
		}
		var k=a[Number(c[j].loc.x)][Number(c[j].loc.y)];
		j=c.length;
		while (j--)
		{
			if (c[j]==k)
			{
				c.splice(j,1);
				d.splice(j,1);
			}
		}
	}
	return a;
}

function inv(s)
{
	if (s=="up")
	{
		s="down";
	}
	else if (s=="down")
	{
		s="up";
	}
	else if (s=="left")
	{
		s="right";
	}
	else if (s=="right")
	{
		s="left";
	}
	return s;
}

function acell()
{
	var cell={
		around:{},
		connected:{up:false,down:false,left:false,right:false},
		status:"",
		loc:{x:-1,y:-1}
	}
	return cell;
}

function go_to(s)
{
	if (dg[s]) {
		map.id=s;
		OpenDG(map);
	}
	else if (world[s]) {
		
	}
	else if (map.loc.x!=-1) {
		if (map.cells[map.loc.x][map.loc.y].connected[s]) {
			for (var t in map.cells[map.loc.x][map.loc.y].around) {
				console.log(""+(map.loc.x-(t.indexOf("left")!=-1)+(t.indexOf("right")!=-1))+""+(map.loc.y-(t.indexOf("down")!=-1)+(t.indexOf("up")!=-1)));
				document.getElementById(""+(map.loc.x-(t.indexOf("left")!=-1)+(t.indexOf("right")!=-1))+""+(map.loc.y-(t.indexOf("down")!=-1)+(t.indexOf("up")!=-1))).removeAttribute("onclick");
			}
			var a=map.cells[map.loc.x][map.loc.y].around[s].loc.x;
			map.loc.y=map.cells[map.loc.x][map.loc.y].around[s].loc.y;
			map.loc.x=a;
			viewmap();
			for (var s in map.cells[map.loc.x][map.loc.y].around)
			{
				if (map.cells[map.loc.x][map.loc.y].connected[s]) {
					console.log(""+(map.loc.x-(s=="left")+(s=="right")+""+(map.loc.y-(s=="down")+(s=="up"))));
					document.getElementById(""+(map.loc.x-(s=="left")+(s=="right")+""+(map.loc.y-(s=="down")+(s=="up")))).setAttribute("onclick","go_to('"+s+"');");
				}
			}
		}
	}
}

function mapstat(x,y) {
	if (x==map.loc.x&&y==map.loc.y) {
		document.getElementById(""+x+""+y).appendChild(document.createTextNode("@"));
	}
	else if (map.cells[x][y].status.indexOf("us")!=-1) {
		document.getElementById(""+x+""+y).appendChild(document.createTextNode("u"));
	}
	else if (map.cells[x][y].status.indexOf("ds")!=-1) {
		document.getElementById(""+x+""+y).appendChild(document.createTextNode("d"));
	}
}

// } object tab
var map = {
	width:0,
	height:0,
	floor:0,
	id:"none",
	cells:[],
	align:"none",
	data:{},
	loc:{x:-1,y:-1}
};

var dg = {
	none: {
		width:9,
		height:9,
		align:"up",
		data: {
			max:3,
			type:[1,2,3],
			tile:{upstair:1,downstair:1,monster:1}
		}
	}
};

var eqs = {
	"000001": {
		id:"000001",
		type:"sword",
		limit: {},
		damage:1,
		effect: {},
		description: "normal sword",
		value:100
	}
};

var world = {
	home: {
		dg: {
			none:true
		}
	}
}