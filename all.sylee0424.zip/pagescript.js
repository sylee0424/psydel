var nds = null;

window.Button_Tab_Page = 0;

var size = {
	width: window.innerWidth || document.body.clientWidth,
	height: window.innerHeight || document.body.clientHeight
}

if (location.href.match(/^https?\:\/\/hitomi\.la/i)) {
	Extension_User_Functions.hab.f();
	Extension_User_Functions.hlb.f();
}

if (location.href.match(/^https?\:\/\/(m|www|bbs)\.ruliweb/i)) {
	Extension_User_Functions.rab.f();
}

if (location.href.indexOf("marumaru") != -1 || location.href.indexOf("wasabisyrup") != -1) {
	Extension_User_Functions.mab.f();
}

setInterval(function() {
	if (window.innerWidth != lncs) {
		lncs = window.innerWidth;
		var a = document.getElementsByClassName("abtn");
		var c = window.innerWidth / document.body.offsetWidth;
		for (var b of a) {
			b.style.fontSize = c * 10 + "px";
			b.style.borderWidth = c + "px";
		}
	}
}, 100);

window.lncs = 0;

window.addEventListener("mousedown",Extension_Tool_Functions.Fake_Scroll_Event.f);
window.addEventListener("mouseup",Extension_Tool_Functions.Fake_Scroll_Event_End.f);

setInterval(Extension_User_Functions.ael.f,40);

Extension_Tool_Functions.Add_Extension_Interface.f();

document.getElementById("b1").addEventListener("click", Bookmark_User_Functions.Activate_Bookmark_Edit.f);
document.getElementById("b2").addEventListener("click", Bookmark_User_Functions.Add_Bookmark.f);
document.getElementById("b3").addEventListener("click", Bookmark_User_Functions.Hide_Bookmark.f);
document.getElementById("c1").addEventListener("click", Bookmark_User_Functions.Remove_Bookmark.f);
document.getElementById("c2").addEventListener("click", Bookmark_User_Functions.Move_Bookmarks.f);
document.getElementById("c3").addEventListener("click", Bookmark_User_Functions.Deactivate_Bookmark_Edit.f);
document.getElementById("c5").addEventListener("click", Bookmark_User_Functions.Go_To_Upper_Bookmark_Folder.f);
document.getElementById("c4").addEventListener("click", Bookmark_User_Functions.Create_Bookmark_Folder.f);
document.getElementById("c6").addEventListener("click", Bookmark_User_Functions.Paste_Bookmark.f);
document.getElementById("c7").addEventListener("click", Bookmark_User_Functions.sortbmk.f);
document.getElementById("c8").addEventListener("click", Bookmark_User_Functions.exportbmk.f);
document.getElementById("c9").addEventListener("click", Bookmark_User_Functions.importbmk.f);
document.getElementById("tab").addEventListener("click", Bookmark_User_Functions.toggle.f);
document.getElementById("getbmk").addEventListener("change", Bookmark_User_Functions.externalbmk.f);

window.addEventListener("message",
	function(event) {
		if (event.data.type == "show") {
			if (typeof Bookmark_Original == "undefined") {
				window.Bookmark_Original = JSON.parse(unescape(document.getElementById("bmksdata").innerHTML));
				document.getElementById("bmksdata").parentNode.removeChild(document.getElementById("bmksdata"));
			}
			Bookmark_User_Functions.Show_Bookmark.f("root");
		} else if (event.data.type == "update") {
			window.Bookmark_Original = event.data.bmk;
			Bookmark_User_Functions.Show_Bookmark.f(document.getElementById("dir").dataset.loc);
		} else if (event.data.type == "tabs") {
			if (event.data.tab.type == "toggle") {
				if (!(event.data.tab.toggle)) {
					document.getElementById("tabbar").style.display = "none";
					document.body.style.marginTop = "0px";
				} else {
					document.getElementById("tabbar").style.display = "block";
					document.body.style.marginTop = "50px";
				}
			} else {
				tabbar(event.data.tab);
			}
		}
	}
);

function tabbar(tabs) {
	var e = document.getElementById("tabbar");
	while (e.firstChild) {
		e.removeChild(e.firstChild);
	}
	for (var i = 0; i < tabs.length; i++) {
		var a = document.createElement("div");
		var b = document.createElement("img");
		var c = document.createElement("span");
		var d = document.createElement("button");
		a.style = "border:1px solid #000000; overflow-y:hidden; position:relative; width:150px; height:30px; display:inline-block;";
		b.style = "border:1px solid #000000; position:absolute; top:0px; left:0px; width:20px; height:20px;";
		c.style = "border:1px solid #000000; background-color:#ffffff; position:absolute; top:0px; left:22px; width:100px; height:20px; overflow:hidden; text-overflow:ellipsis;";
		d.style = "border:1px solid #000000; background-color:#ce3333; position:absolute; top:0px; right:0px; width:20px; height:20px;";
		if (!(tabs[i].favIconUrl)) {
			b.src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAIAAADYYG7QAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAABDSURBVFhH7c4xAQAwDASh+jf9lcCa4VDA2zGFpJAUkkJSSApJISkkhaSQFJJCUkgKSSEpJIWkkBSSQlJICkkhORbaPoBi5ofwSUznAAAAAElFTkSuQmCC";
		}
		else {
			b.src = tabs[i].favIconUrl;
		}
		c.appendChild(document.createTextNode(tabs[i].title));
		c.setAttribute("data-id", tabs[i].id);
		d.appendChild(document.createTextNode("X"));
		d.setAttribute("data-id", tabs[i].id);
		d.setAttribute("data-index", tabs[i].index);
		a.appendChild(b);
		a.appendChild(c);
		a.appendChild(d);
		document.getElementById("tabbar").appendChild(a);
		c.addEventListener("click", changetab);
		d.addEventListener("click", closetab);
	}
}

function changetab() {
	window.postMessage({
		type: "changeto",
		id: Number(this.dataset.id),
		des: "back"
	}, "*");
}

function closetab() {
	window.postMessage({
		type: "closeto",
		id: Number(this.dataset.id),
		index: Number(this.dataset.index),
		des: "back"
	}, "*");
}

document.onmousedown=function () {};

window.postMessage({
	type: "gettab",
	des: "back"
}, "*");

window.postMessage({
	type: "check",
	bmk: {}
}, "*");