chrome.runtime.onMessageExternal.addListener(
	function(message, sender, sendResponse) {
		chrome.tabs.executeScript({code:'alert("'+message+'")'},function (result) {});
});